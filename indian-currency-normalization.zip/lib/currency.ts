/**
 * Currency Utility for Indian Market
 * ALL prices displayed in INR (₹) only
 * Real-time conversion for foreign assets
 */

// Real-time exchange rates (these would be fetched from API in production)
const EXCHANGE_RATES = {
  USD_TO_INR: 83.25,
  EUR_TO_INR: 90.15,
  GBP_TO_INR: 105.40,
  JPY_TO_INR: 0.56,
  AUD_TO_INR: 54.20,
  CAD_TO_INR: 61.30,
};

export type AssetCategory = 'stocks' | 'crypto' | 'forex' | 'commodities' | 'indices';

/**
 * Format price in Indian Rupee format
 * Uses Indian numbering system (lakhs/crores)
 */
export function formatINR(
  amount: number,
  options: {
    minimumFractionDigits?: number;
    maximumFractionDigits?: number;
    compact?: boolean;
  } = {}
): string {
  const { minimumFractionDigits = 2, maximumFractionDigits = 2, compact = false } = options;

  if (compact && amount >= 10000000) {
    // Crores
    return `₹${(amount / 10000000).toFixed(2)}Cr`;
  } else if (compact && amount >= 100000) {
    // Lakhs
    return `₹${(amount / 100000).toFixed(2)}L`;
  }

  // Standard Indian format with commas
  return `₹${amount.toLocaleString('en-IN', {
    minimumFractionDigits,
    maximumFractionDigits,
  })}`;
}

/**
 * Convert USD to INR with real-time rate
 */
export function convertUSDToINR(usdAmount: number): number {
  const inrAmount = usdAmount * EXCHANGE_RATES.USD_TO_INR;
  
  // Debug logging to verify conversion is happening
  if (typeof window !== 'undefined' && Math.random() < 0.05) {
    console.log(`[v0] USD→INR Conversion: $${usdAmount.toFixed(2)} × ${EXCHANGE_RATES.USD_TO_INR} = ₹${inrAmount.toFixed(2)}`);
  }
  
  return inrAmount;
}

/**
 * Convert any currency to INR
 */
export function convertToINR(amount: number, fromCurrency: string): number {
  const currency = fromCurrency.toUpperCase();

  switch (currency) {
    case 'USD':
      return amount * EXCHANGE_RATES.USD_TO_INR;
    case 'EUR':
      return amount * EXCHANGE_RATES.EUR_TO_INR;
    case 'GBP':
      return amount * EXCHANGE_RATES.GBP_TO_INR;
    case 'JPY':
      return amount * EXCHANGE_RATES.JPY_TO_INR;
    case 'AUD':
      return amount * EXCHANGE_RATES.AUD_TO_INR;
    case 'CAD':
      return amount * EXCHANGE_RATES.CAD_TO_INR;
    case 'INR':
      return amount;
    default:
      // For crypto and commodities priced in USD, convert to INR
      return amount * EXCHANGE_RATES.USD_TO_INR;
  }
}

/**
 * Format price based on asset category - ALL IN INR
 */
export function formatPrice(price: number, category: AssetCategory): string {
  // Convert crypto (USD-based) to INR
  if (category === 'crypto') {
    const inrPrice = convertUSDToINR(price);
    if (inrPrice < 100) {
      return formatINR(inrPrice, { maximumFractionDigits: 4 });
    }
    return formatINR(inrPrice);
  }

  // Convert commodities (USD-based) to INR
  if (category === 'commodities') {
    const inrPrice = convertUSDToINR(price);
    return formatINR(inrPrice);
  }

  // Forex pairs - show relative value in INR context
  if (category === 'forex') {
    // For forex pairs, we show the rate multiplied by Indian rupee equivalent
    // e.g., EUR/USD 1.08 becomes the INR value
    return formatINR(price, { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  }

  // Indian stocks and indices - already in INR
  if (category === 'stocks' || category === 'indices') {
    return formatINR(price);
  }

  // Default: format as INR
  return formatINR(price);
}

/**
 * Format price with compact notation for large volumes
 */
export function formatVolumeINR(volume: number): string {
  if (volume >= 10000000) {
    return `₹${(volume / 10000000).toFixed(2)}Cr`;
  } else if (volume >= 100000) {
    return `₹${(volume / 100000).toFixed(2)}L`;
  } else if (volume >= 1000) {
    return `₹${(volume / 1000).toFixed(2)}K`;
  }
  return formatINR(volume);
}

/**
 * Get appropriate decimal places for a category
 */
export function getPrecision(category: AssetCategory, price: number): number {
  if (category === 'forex') return 4;
  if (category === 'crypto' && price < 100) return 4;
  if (category === 'indices' || price > 10000) return 2;
  return 2;
}

/**
 * Round price to appropriate precision for category
 */
export function roundPrice(price: number, category: AssetCategory): number {
  const precision = getPrecision(category, price);
  return Math.round(price * Math.pow(10, precision)) / Math.pow(10, precision);
}

/**
 * Fetch real-time exchange rates (placeholder - would call actual API)
 */
export async function fetchExchangeRates(): Promise<typeof EXCHANGE_RATES> {
  // In production, this would fetch from a real API like:
  // - Reserve Bank of India API
  // - exchangerate-api.com
  // - fixer.io
  // - currencyapi.com
  
  // For now, return static rates
  // In real implementation: const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
  return EXCHANGE_RATES;
}

/**
 * Update exchange rates periodically
 */
let cachedRates = EXCHANGE_RATES;
let lastUpdate = Date.now();

export async function getLatestRates(): Promise<typeof EXCHANGE_RATES> {
  const now = Date.now();
  const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  if (now - lastUpdate > CACHE_DURATION) {
    try {
      cachedRates = await fetchExchangeRates();
      lastUpdate = now;
    } catch (error) {
      console.error('[v0] Failed to fetch exchange rates:', error);
      // Keep using cached rates on error
    }
  }

  return cachedRates;
}

/**
 * Format change/difference in INR
 */
export function formatChange(change: number, category: AssetCategory): string {
  const prefix = change >= 0 ? '+' : '';
  
  if (category === 'crypto' || category === 'commodities') {
    const inrChange = convertUSDToINR(change);
    return `${prefix}${formatINR(inrChange)}`;
  }
  
  return `${prefix}${formatINR(change)}`;
}

/**
 * Check if market data is available
 */
export function isPriceAvailable(price: number): boolean {
  return price > 0 && isFinite(price);
}

/**
 * Get display text when price is unavailable
 */
export function getUnavailableText(): string {
  return 'Live price unavailable';
}
