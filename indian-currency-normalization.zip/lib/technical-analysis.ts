// Comprehensive Technical Analysis Engine
// Includes RSI, MACD, Bollinger Bands, Moving Averages, and more

import type { CandleData } from './trading-types';

// Technical Indicator Types
export interface RSIResult {
  value: number;
  signal: 'overbought' | 'oversold' | 'neutral';
  strength: number;
}

export interface MACDResult {
  macd: number;
  signal: number;
  histogram: number;
  trend: 'bullish' | 'bearish' | 'neutral';
  crossover: 'bullish_cross' | 'bearish_cross' | 'none';
}

export interface BollingerBandsResult {
  upper: number;
  middle: number;
  lower: number;
  bandwidth: number;
  percentB: number;
  signal: 'overbought' | 'oversold' | 'squeeze' | 'expansion' | 'neutral';
}

export interface MovingAveragesResult {
  sma20: number;
  sma50: number;
  sma200: number;
  ema12: number;
  ema26: number;
  trend: 'strong_bullish' | 'bullish' | 'neutral' | 'bearish' | 'strong_bearish';
  goldenCross: boolean;
  deathCross: boolean;
}

export interface StochasticResult {
  k: number;
  d: number;
  signal: 'overbought' | 'oversold' | 'neutral';
}

export interface ATRResult {
  value: number;
  percentATR: number;
  volatilityLevel: 'low' | 'medium' | 'high' | 'extreme';
}

export interface SupportResistanceResult {
  supports: number[];
  resistances: number[];
  pivotPoint: number;
  r1: number;
  r2: number;
  r3: number;
  s1: number;
  s2: number;
  s3: number;
}

export interface VolumeAnalysisResult {
  averageVolume: number;
  volumeRatio: number;
  trend: 'accumulation' | 'distribution' | 'neutral';
  obv: number;
}

export interface TechnicalSignal {
  indicator: string;
  signal: 'buy' | 'sell' | 'hold';
  strength: number;
  reason: string;
}

export interface ComprehensiveTechnicalAnalysis {
  rsi: RSIResult;
  macd: MACDResult;
  bollingerBands: BollingerBandsResult;
  movingAverages: MovingAveragesResult;
  stochastic: StochasticResult;
  atr: ATRResult;
  supportResistance: SupportResistanceResult;
  volumeAnalysis: VolumeAnalysisResult;
  signals: TechnicalSignal[];
  overallSentiment: 'strong_buy' | 'buy' | 'neutral' | 'sell' | 'strong_sell';
  confidenceScore: number;
  suggestedAction: {
    action: 'buy' | 'sell' | 'hold';
    entry: number;
    stopLoss: number;
    target1: number;
    target2: number;
    target3: number;
    riskRewardRatio: number;
  };
}

// Helper: Calculate Simple Moving Average
export function calculateSMA(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1] || 0;
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

// Helper: Calculate Exponential Moving Average
export function calculateEMA(prices: number[], period: number): number {
  if (prices.length < period) return calculateSMA(prices, prices.length);
  
  const multiplier = 2 / (period + 1);
  let ema = calculateSMA(prices.slice(0, period), period);
  
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
  }
  
  return ema;
}

// Calculate RSI (Relative Strength Index)
export function calculateRSI(candles: CandleData[], period = 14): RSIResult {
  if (candles.length < period + 1) {
    return { value: 50, signal: 'neutral', strength: 0 };
  }
  
  const closes = candles.map(c => c.close);
  const gains: number[] = [];
  const losses: number[] = [];
  
  for (let i = 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? Math.abs(change) : 0);
  }
  
  const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period;
  const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period;
  
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  
  let signal: RSIResult['signal'] = 'neutral';
  let strength = 0;
  
  if (rsi >= 70) {
    signal = 'overbought';
    strength = Math.min(100, (rsi - 70) * 3.33);
  } else if (rsi <= 30) {
    signal = 'oversold';
    strength = Math.min(100, (30 - rsi) * 3.33);
  } else {
    strength = Math.abs(50 - rsi) * 2;
  }
  
  return { value: Math.round(rsi * 100) / 100, signal, strength: Math.round(strength) };
}

// Calculate MACD (Moving Average Convergence Divergence)
export function calculateMACD(candles: CandleData[], fastPeriod = 12, slowPeriod = 26, signalPeriod = 9): MACDResult {
  const closes = candles.map(c => c.close);
  
  if (closes.length < slowPeriod + signalPeriod) {
    return { macd: 0, signal: 0, histogram: 0, trend: 'neutral', crossover: 'none' };
  }
  
  const ema12 = calculateEMA(closes, fastPeriod);
  const ema26 = calculateEMA(closes, slowPeriod);
  const macdLine = ema12 - ema26;
  
  // Calculate signal line (EMA of MACD)
  const macdValues: number[] = [];
  for (let i = slowPeriod; i < closes.length; i++) {
    const ema12Temp = calculateEMA(closes.slice(0, i + 1), fastPeriod);
    const ema26Temp = calculateEMA(closes.slice(0, i + 1), slowPeriod);
    macdValues.push(ema12Temp - ema26Temp);
  }
  
  const signalLine = calculateEMA(macdValues, signalPeriod);
  const histogram = macdLine - signalLine;
  
  // Determine trend and crossover
  let trend: MACDResult['trend'] = 'neutral';
  let crossover: MACDResult['crossover'] = 'none';
  
  if (histogram > 0) {
    trend = 'bullish';
  } else if (histogram < 0) {
    trend = 'bearish';
  }
  
  // Check for crossover (compare with previous values)
  if (macdValues.length >= 2) {
    const prevMACD = macdValues[macdValues.length - 2];
    const prevSignal = calculateEMA(macdValues.slice(0, -1), signalPeriod);
    
    if (prevMACD < prevSignal && macdLine > signalLine) {
      crossover = 'bullish_cross';
    } else if (prevMACD > prevSignal && macdLine < signalLine) {
      crossover = 'bearish_cross';
    }
  }
  
  return {
    macd: Math.round(macdLine * 10000) / 10000,
    signal: Math.round(signalLine * 10000) / 10000,
    histogram: Math.round(histogram * 10000) / 10000,
    trend,
    crossover,
  };
}

// Calculate Bollinger Bands
export function calculateBollingerBands(candles: CandleData[], period = 20, stdDev = 2): BollingerBandsResult {
  const closes = candles.map(c => c.close);
  
  if (closes.length < period) {
    const price = closes[closes.length - 1] || 0;
    return { upper: price, middle: price, lower: price, bandwidth: 0, percentB: 50, signal: 'neutral' };
  }
  
  const sma = calculateSMA(closes, period);
  const recentCloses = closes.slice(-period);
  
  // Calculate standard deviation
  const squaredDiffs = recentCloses.map(c => Math.pow(c - sma, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / period;
  const standardDeviation = Math.sqrt(variance);
  
  const upper = sma + (stdDev * standardDeviation);
  const lower = sma - (stdDev * standardDeviation);
  const bandwidth = ((upper - lower) / sma) * 100;
  
  const currentPrice = closes[closes.length - 1];
  const percentB = ((currentPrice - lower) / (upper - lower)) * 100;
  
  let signal: BollingerBandsResult['signal'] = 'neutral';
  if (percentB >= 100) signal = 'overbought';
  else if (percentB <= 0) signal = 'oversold';
  else if (bandwidth < 5) signal = 'squeeze';
  else if (bandwidth > 20) signal = 'expansion';
  
  return {
    upper: Math.round(upper * 100) / 100,
    middle: Math.round(sma * 100) / 100,
    lower: Math.round(lower * 100) / 100,
    bandwidth: Math.round(bandwidth * 100) / 100,
    percentB: Math.round(percentB * 100) / 100,
    signal,
  };
}

// Calculate Moving Averages
export function calculateMovingAverages(candles: CandleData[]): MovingAveragesResult {
  const closes = candles.map(c => c.close);
  const price = closes[closes.length - 1] || 0;
  
  const sma20 = calculateSMA(closes, 20);
  const sma50 = calculateSMA(closes, 50);
  const sma200 = calculateSMA(closes, 200) || sma50; // Fallback if not enough data
  const ema12 = calculateEMA(closes, 12);
  const ema26 = calculateEMA(closes, 26);
  
  // Determine trend
  let trend: MovingAveragesResult['trend'] = 'neutral';
  const bullishSignals = [
    price > sma20,
    price > sma50,
    price > sma200,
    sma20 > sma50,
    sma50 > sma200,
    ema12 > ema26,
  ].filter(Boolean).length;
  
  if (bullishSignals >= 5) trend = 'strong_bullish';
  else if (bullishSignals >= 4) trend = 'bullish';
  else if (bullishSignals <= 1) trend = 'strong_bearish';
  else if (bullishSignals <= 2) trend = 'bearish';
  
  // Check for golden/death cross
  const prevSMA50 = closes.length > 51 ? calculateSMA(closes.slice(0, -1), 50) : sma50;
  const prevSMA200 = closes.length > 201 ? calculateSMA(closes.slice(0, -1), 200) : sma200;
  
  const goldenCross = prevSMA50 < prevSMA200 && sma50 > sma200;
  const deathCross = prevSMA50 > prevSMA200 && sma50 < sma200;
  
  return {
    sma20: Math.round(sma20 * 100) / 100,
    sma50: Math.round(sma50 * 100) / 100,
    sma200: Math.round(sma200 * 100) / 100,
    ema12: Math.round(ema12 * 100) / 100,
    ema26: Math.round(ema26 * 100) / 100,
    trend,
    goldenCross,
    deathCross,
  };
}

// Calculate Stochastic Oscillator
export function calculateStochastic(candles: CandleData[], kPeriod = 14, dPeriod = 3): StochasticResult {
  if (candles.length < kPeriod) {
    return { k: 50, d: 50, signal: 'neutral' };
  }
  
  const recentCandles = candles.slice(-kPeriod);
  const currentClose = candles[candles.length - 1].close;
  const highestHigh = Math.max(...recentCandles.map(c => c.high));
  const lowestLow = Math.min(...recentCandles.map(c => c.low));
  
  const k = highestHigh === lowestLow ? 50 : ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
  
  // Calculate %D (SMA of %K)
  const kValues: number[] = [];
  for (let i = kPeriod; i <= candles.length; i++) {
    const slice = candles.slice(i - kPeriod, i);
    const close = slice[slice.length - 1].close;
    const high = Math.max(...slice.map(c => c.high));
    const low = Math.min(...slice.map(c => c.low));
    kValues.push(high === low ? 50 : ((close - low) / (high - low)) * 100);
  }
  
  const d = calculateSMA(kValues, dPeriod);
  
  let signal: StochasticResult['signal'] = 'neutral';
  if (k >= 80) signal = 'overbought';
  else if (k <= 20) signal = 'oversold';
  
  return {
    k: Math.round(k * 100) / 100,
    d: Math.round(d * 100) / 100,
    signal,
  };
}

// Calculate ATR (Average True Range)
export function calculateATR(candles: CandleData[], period = 14): ATRResult {
  if (candles.length < period + 1) {
    return { value: 0, percentATR: 0, volatilityLevel: 'low' };
  }
  
  const trueRanges: number[] = [];
  
  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const previous = candles[i - 1];
    
    const tr = Math.max(
      current.high - current.low,
      Math.abs(current.high - previous.close),
      Math.abs(current.low - previous.close)
    );
    trueRanges.push(tr);
  }
  
  const atr = calculateSMA(trueRanges.slice(-period), period);
  const currentPrice = candles[candles.length - 1].close;
  const percentATR = (atr / currentPrice) * 100;
  
  let volatilityLevel: ATRResult['volatilityLevel'] = 'low';
  if (percentATR > 5) volatilityLevel = 'extreme';
  else if (percentATR > 3) volatilityLevel = 'high';
  else if (percentATR > 1.5) volatilityLevel = 'medium';
  
  return {
    value: Math.round(atr * 10000) / 10000,
    percentATR: Math.round(percentATR * 100) / 100,
    volatilityLevel,
  };
}

// Calculate Support and Resistance Levels
export function calculateSupportResistance(candles: CandleData[]): SupportResistanceResult {
  if (candles.length < 2) {
    const price = candles[0]?.close || 0;
    return {
      supports: [price * 0.95, price * 0.9, price * 0.85],
      resistances: [price * 1.05, price * 1.1, price * 1.15],
      pivotPoint: price,
      r1: price * 1.02, r2: price * 1.04, r3: price * 1.06,
      s1: price * 0.98, s2: price * 0.96, s3: price * 0.94,
    };
  }
  
  const lastCandle = candles[candles.length - 1];
  const high = lastCandle.high;
  const low = lastCandle.low;
  const close = lastCandle.close;
  
  // Pivot Point calculation (Standard)
  const pivotPoint = (high + low + close) / 3;
  
  // Resistance levels
  const r1 = (2 * pivotPoint) - low;
  const r2 = pivotPoint + (high - low);
  const r3 = high + 2 * (pivotPoint - low);
  
  // Support levels
  const s1 = (2 * pivotPoint) - high;
  const s2 = pivotPoint - (high - low);
  const s3 = low - 2 * (high - pivotPoint);
  
  // Find key support/resistance from price action
  const highs = candles.map(c => c.high).sort((a, b) => b - a);
  const lows = candles.map(c => c.low).sort((a, b) => a - b);
  
  const supports = [s1, s2, s3].map(v => Math.round(v * 100) / 100);
  const resistances = [r1, r2, r3].map(v => Math.round(v * 100) / 100);
  
  return {
    supports,
    resistances,
    pivotPoint: Math.round(pivotPoint * 100) / 100,
    r1: Math.round(r1 * 100) / 100,
    r2: Math.round(r2 * 100) / 100,
    r3: Math.round(r3 * 100) / 100,
    s1: Math.round(s1 * 100) / 100,
    s2: Math.round(s2 * 100) / 100,
    s3: Math.round(s3 * 100) / 100,
  };
}

// Calculate Volume Analysis
export function calculateVolumeAnalysis(candles: CandleData[]): VolumeAnalysisResult {
  if (candles.length < 20) {
    return { averageVolume: 0, volumeRatio: 1, trend: 'neutral', obv: 0 };
  }
  
  const volumes = candles.map(c => c.volume || 0);
  const averageVolume = calculateSMA(volumes.slice(-20), 20);
  const currentVolume = volumes[volumes.length - 1];
  const volumeRatio = averageVolume > 0 ? currentVolume / averageVolume : 1;
  
  // Calculate OBV (On-Balance Volume)
  let obv = 0;
  for (let i = 1; i < candles.length; i++) {
    const currentClose = candles[i].close;
    const prevClose = candles[i - 1].close;
    const volume = candles[i].volume || 0;
    
    if (currentClose > prevClose) obv += volume;
    else if (currentClose < prevClose) obv -= volume;
  }
  
  // Determine volume trend
  const recentPriceChanges = candles.slice(-10).map((c, i, arr) => {
    if (i === 0) return 0;
    return c.close - arr[i - 1].close;
  });
  const avgPriceChange = recentPriceChanges.reduce((a, b) => a + b, 0) / recentPriceChanges.length;
  
  let trend: VolumeAnalysisResult['trend'] = 'neutral';
  if (avgPriceChange > 0 && volumeRatio > 1.2) trend = 'accumulation';
  else if (avgPriceChange < 0 && volumeRatio > 1.2) trend = 'distribution';
  
  return {
    averageVolume: Math.round(averageVolume),
    volumeRatio: Math.round(volumeRatio * 100) / 100,
    trend,
    obv: Math.round(obv),
  };
}

// Generate trading signals from indicators
function generateSignals(
  rsi: RSIResult,
  macd: MACDResult,
  bb: BollingerBandsResult,
  ma: MovingAveragesResult,
  stoch: StochasticResult
): TechnicalSignal[] {
  const signals: TechnicalSignal[] = [];
  
  // RSI signals
  if (rsi.signal === 'oversold') {
    signals.push({ indicator: 'RSI', signal: 'buy', strength: rsi.strength, reason: `RSI oversold at ${rsi.value}` });
  } else if (rsi.signal === 'overbought') {
    signals.push({ indicator: 'RSI', signal: 'sell', strength: rsi.strength, reason: `RSI overbought at ${rsi.value}` });
  } else {
    signals.push({ indicator: 'RSI', signal: 'hold', strength: 50, reason: `RSI neutral at ${rsi.value}` });
  }
  
  // MACD signals
  if (macd.crossover === 'bullish_cross') {
    signals.push({ indicator: 'MACD', signal: 'buy', strength: 80, reason: 'Bullish MACD crossover' });
  } else if (macd.crossover === 'bearish_cross') {
    signals.push({ indicator: 'MACD', signal: 'sell', strength: 80, reason: 'Bearish MACD crossover' });
  } else if (macd.trend === 'bullish') {
    signals.push({ indicator: 'MACD', signal: 'buy', strength: 60, reason: 'Positive MACD histogram' });
  } else if (macd.trend === 'bearish') {
    signals.push({ indicator: 'MACD', signal: 'sell', strength: 60, reason: 'Negative MACD histogram' });
  } else {
    signals.push({ indicator: 'MACD', signal: 'hold', strength: 50, reason: 'MACD neutral' });
  }
  
  // Bollinger Bands signals
  if (bb.signal === 'oversold') {
    signals.push({ indicator: 'Bollinger Bands', signal: 'buy', strength: 75, reason: 'Price below lower band' });
  } else if (bb.signal === 'overbought') {
    signals.push({ indicator: 'Bollinger Bands', signal: 'sell', strength: 75, reason: 'Price above upper band' });
  } else if (bb.signal === 'squeeze') {
    signals.push({ indicator: 'Bollinger Bands', signal: 'hold', strength: 40, reason: 'Bollinger squeeze - breakout expected' });
  } else {
    signals.push({ indicator: 'Bollinger Bands', signal: 'hold', strength: 50, reason: 'Price within bands' });
  }
  
  // Moving Average signals
  if (ma.goldenCross) {
    signals.push({ indicator: 'Moving Averages', signal: 'buy', strength: 90, reason: 'Golden cross detected' });
  } else if (ma.deathCross) {
    signals.push({ indicator: 'Moving Averages', signal: 'sell', strength: 90, reason: 'Death cross detected' });
  } else if (ma.trend === 'strong_bullish' || ma.trend === 'bullish') {
    signals.push({ indicator: 'Moving Averages', signal: 'buy', strength: 65, reason: `${ma.trend.replace('_', ' ')} trend` });
  } else if (ma.trend === 'strong_bearish' || ma.trend === 'bearish') {
    signals.push({ indicator: 'Moving Averages', signal: 'sell', strength: 65, reason: `${ma.trend.replace('_', ' ')} trend` });
  } else {
    signals.push({ indicator: 'Moving Averages', signal: 'hold', strength: 50, reason: 'Neutral trend' });
  }
  
  // Stochastic signals
  if (stoch.signal === 'oversold') {
    signals.push({ indicator: 'Stochastic', signal: 'buy', strength: 70, reason: `Stochastic oversold at ${stoch.k}` });
  } else if (stoch.signal === 'overbought') {
    signals.push({ indicator: 'Stochastic', signal: 'sell', strength: 70, reason: `Stochastic overbought at ${stoch.k}` });
  } else {
    signals.push({ indicator: 'Stochastic', signal: 'hold', strength: 50, reason: `Stochastic neutral at ${stoch.k}` });
  }
  
  return signals;
}

// Main comprehensive analysis function
export function performTechnicalAnalysis(candles: CandleData[]): ComprehensiveTechnicalAnalysis {
  const rsi = calculateRSI(candles);
  const macd = calculateMACD(candles);
  const bollingerBands = calculateBollingerBands(candles);
  const movingAverages = calculateMovingAverages(candles);
  const stochastic = calculateStochastic(candles);
  const atr = calculateATR(candles);
  const supportResistance = calculateSupportResistance(candles);
  const volumeAnalysis = calculateVolumeAnalysis(candles);
  const signals = generateSignals(rsi, macd, bollingerBands, movingAverages, stochastic);
  
  // Calculate overall sentiment
  const buySignals = signals.filter(s => s.signal === 'buy');
  const sellSignals = signals.filter(s => s.signal === 'sell');
  const avgBuyStrength = buySignals.reduce((a, b) => a + b.strength, 0) / (buySignals.length || 1);
  const avgSellStrength = sellSignals.reduce((a, b) => a + b.strength, 0) / (sellSignals.length || 1);
  
  let overallSentiment: ComprehensiveTechnicalAnalysis['overallSentiment'] = 'neutral';
  let confidenceScore = 50;
  
  const netBullish = buySignals.length - sellSignals.length;
  
  if (netBullish >= 3) {
    overallSentiment = 'strong_buy';
    confidenceScore = Math.min(95, 70 + avgBuyStrength * 0.25);
  } else if (netBullish >= 1) {
    overallSentiment = 'buy';
    confidenceScore = Math.min(80, 55 + avgBuyStrength * 0.25);
  } else if (netBullish <= -3) {
    overallSentiment = 'strong_sell';
    confidenceScore = Math.min(95, 70 + avgSellStrength * 0.25);
  } else if (netBullish <= -1) {
    overallSentiment = 'sell';
    confidenceScore = Math.min(80, 55 + avgSellStrength * 0.25);
  } else {
    overallSentiment = 'neutral';
    confidenceScore = 50;
  }
  
  // Generate suggested action
  const currentPrice = candles[candles.length - 1]?.close || 0;
  const isLong = overallSentiment === 'strong_buy' || overallSentiment === 'buy';
  
  let stopLoss: number;
  let entry: number;
  let target1: number;
  let target2: number;
  let target3: number;
  
  if (isLong) {
    entry = currentPrice;
    stopLoss = Math.max(supportResistance.s1, currentPrice - (atr.value * 2));
    target1 = supportResistance.r1;
    target2 = supportResistance.r2;
    target3 = supportResistance.r3;
  } else {
    entry = currentPrice;
    stopLoss = Math.min(supportResistance.r1, currentPrice + (atr.value * 2));
    target1 = supportResistance.s1;
    target2 = supportResistance.s2;
    target3 = supportResistance.s3;
  }
  
  const risk = Math.abs(entry - stopLoss);
  const reward = Math.abs(target1 - entry);
  const riskRewardRatio = risk > 0 ? reward / risk : 0;
  
  return {
    rsi,
    macd,
    bollingerBands,
    movingAverages,
    stochastic,
    atr,
    supportResistance,
    volumeAnalysis,
    signals,
    overallSentiment,
    confidenceScore: Math.round(confidenceScore),
    suggestedAction: {
      action: overallSentiment === 'neutral' ? 'hold' : isLong ? 'buy' : 'sell',
      entry: Math.round(entry * 100) / 100,
      stopLoss: Math.round(stopLoss * 100) / 100,
      target1: Math.round(target1 * 100) / 100,
      target2: Math.round(target2 * 100) / 100,
      target3: Math.round(target3 * 100) / 100,
      riskRewardRatio: Math.round(riskRewardRatio * 100) / 100,
    },
  };
}
