import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

/**
 * IMPORTANT: ALL PRICES IN THIS APPLICATION MUST BE DISPLAYED IN INR (₹)
 * 
 * Use the currency utilities from @/lib/currency for all price formatting:
 * - formatINR() - Format numbers in Indian Rupee format
 * - formatPrice() - Format based on asset category with automatic USD→INR conversion
 * - convertUSDToINR() - Convert USD prices to INR
 * 
 * NEVER use $, €, or other currency symbols in the UI.
 * Always show prices as ₹X,XXX.XX with Indian numbering system.
 */

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
