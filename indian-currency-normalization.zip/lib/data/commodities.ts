// Complete list of commodities including precious metals, energy, agriculture, and livestock

export interface CommodityInfo {
  symbol: string;
  name: string;
  category: 'precious_metals' | 'energy' | 'agriculture' | 'livestock' | 'industrial_metals' | 'softs';
  unit: string;
  exchange: string;
  tradingHours: string;
  description: string;
  factors: string[];
}

// Precious Metals
export const PRECIOUS_METALS: CommodityInfo[] = [
  { 
    symbol: "XAUUSD", 
    name: "Gold", 
    category: "precious_metals", 
    unit: "USD per troy ounce",
    exchange: "COMEX/LBMA",
    tradingHours: "24/5",
    description: "Safe-haven asset and inflation hedge",
    factors: ["USD strength", "Interest rates", "Inflation", "Geopolitical tensions"]
  },
  { 
    symbol: "XAGUSD", 
    name: "Silver", 
    category: "precious_metals", 
    unit: "USD per troy ounce",
    exchange: "COMEX/LBMA",
    tradingHours: "24/5",
    description: "Industrial and investment metal",
    factors: ["Industrial demand", "Gold prices", "Solar panel demand", "Electronics"]
  },
  { 
    symbol: "XPTUSD", 
    name: "Platinum", 
    category: "precious_metals", 
    unit: "USD per troy ounce",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "Catalytic converter and jewelry metal",
    factors: ["Auto industry", "Hydrogen fuel cells", "Mining supply", "Jewelry demand"]
  },
  { 
    symbol: "XPDUSD", 
    name: "Palladium", 
    category: "precious_metals", 
    unit: "USD per troy ounce",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "Automotive catalyst metal",
    factors: ["Gasoline car production", "Russian supply", "Recycling rates", "EV adoption"]
  },
  { 
    symbol: "XRHUSD", 
    name: "Rhodium", 
    category: "precious_metals", 
    unit: "USD per troy ounce",
    exchange: "OTC",
    tradingHours: "Limited",
    description: "Rarest precious metal for catalysts",
    factors: ["Auto emissions standards", "South African mining", "Limited supply"]
  },
];

// Energy Commodities
export const ENERGY_COMMODITIES: CommodityInfo[] = [
  { 
    symbol: "USOIL", 
    name: "WTI Crude Oil", 
    category: "energy", 
    unit: "USD per barrel",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "US benchmark crude oil",
    factors: ["OPEC decisions", "US production", "Global demand", "Inventories"]
  },
  { 
    symbol: "UKOIL", 
    name: "Brent Crude Oil", 
    category: "energy", 
    unit: "USD per barrel",
    exchange: "ICE",
    tradingHours: "24/5",
    description: "International benchmark crude oil",
    factors: ["OPEC+ output", "Geopolitics", "Shipping costs", "Demand trends"]
  },
  { 
    symbol: "NATGAS", 
    name: "Natural Gas", 
    category: "energy", 
    unit: "USD per MMBtu",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "Heating and power generation fuel",
    factors: ["Weather", "Storage levels", "LNG exports", "Renewable competition"]
  },
  { 
    symbol: "RBOB", 
    name: "Gasoline (RBOB)", 
    category: "energy", 
    unit: "USD per gallon",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "Reformulated gasoline blendstock",
    factors: ["Crude prices", "Refinery capacity", "Driving season", "RFS mandates"]
  },
  { 
    symbol: "HEATING", 
    name: "Heating Oil", 
    category: "energy", 
    unit: "USD per gallon",
    exchange: "NYMEX",
    tradingHours: "24/5",
    description: "Distillate fuel oil",
    factors: ["Crude prices", "Winter weather", "Diesel demand", "Inventory levels"]
  },
  { 
    symbol: "ETHANOL", 
    name: "Ethanol", 
    category: "energy", 
    unit: "USD per gallon",
    exchange: "CME",
    tradingHours: "CME Hours",
    description: "Corn-based biofuel",
    factors: ["Corn prices", "Gasoline prices", "EPA mandates", "Brazil exports"]
  },
  { 
    symbol: "COAL", 
    name: "Coal", 
    category: "energy", 
    unit: "USD per ton",
    exchange: "ICE",
    tradingHours: "24/5",
    description: "Thermal coal for power generation",
    factors: ["Natural gas prices", "China demand", "Clean energy policy", "Mining output"]
  },
  { 
    symbol: "URANIUM", 
    name: "Uranium", 
    category: "energy", 
    unit: "USD per pound",
    exchange: "OTC/Futures",
    tradingHours: "Limited",
    description: "Nuclear power fuel",
    factors: ["Nuclear plant construction", "Supply agreements", "Kazakhstan output", "Green energy"]
  },
];

// Industrial Metals
export const INDUSTRIAL_METALS: CommodityInfo[] = [
  { 
    symbol: "COPPER", 
    name: "Copper", 
    category: "industrial_metals", 
    unit: "USD per pound",
    exchange: "COMEX/LME",
    tradingHours: "24/5",
    description: "Industrial bellwether metal",
    factors: ["China construction", "EV demand", "Chile production", "Infrastructure spending"]
  },
  { 
    symbol: "ALUMINUM", 
    name: "Aluminum", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME",
    tradingHours: "24/5",
    description: "Lightweight industrial metal",
    factors: ["Energy costs", "China output", "Auto industry", "Packaging demand"]
  },
  { 
    symbol: "ZINC", 
    name: "Zinc", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME",
    tradingHours: "24/5",
    description: "Galvanizing metal",
    factors: ["Steel production", "Mining supply", "Infrastructure", "Smelter capacity"]
  },
  { 
    symbol: "NICKEL", 
    name: "Nickel", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME",
    tradingHours: "24/5",
    description: "Stainless steel and battery metal",
    factors: ["EV battery demand", "Indonesian supply", "Stainless steel", "Russian output"]
  },
  { 
    symbol: "LEAD", 
    name: "Lead", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME",
    tradingHours: "24/5",
    description: "Battery and industrial metal",
    factors: ["Battery demand", "Recycling rates", "Environmental regulations", "China demand"]
  },
  { 
    symbol: "TIN", 
    name: "Tin", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME",
    tradingHours: "24/5",
    description: "Electronics solder metal",
    factors: ["Electronics production", "Indonesian exports", "Semiconductor demand", "Supply disruptions"]
  },
  { 
    symbol: "STEEL", 
    name: "Steel", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "CME/LME",
    tradingHours: "Exchange hours",
    description: "Construction and manufacturing",
    factors: ["China production", "Iron ore prices", "Construction", "Trade tariffs"]
  },
  { 
    symbol: "IRON", 
    name: "Iron Ore", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "SGX/DCE",
    tradingHours: "Exchange hours",
    description: "Primary steel-making input",
    factors: ["China steel production", "Australia exports", "Brazil supply", "Port inventory"]
  },
  { 
    symbol: "LITHIUM", 
    name: "Lithium", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "CME/OTC",
    tradingHours: "Limited",
    description: "Key EV battery material",
    factors: ["EV sales", "Battery tech", "Chile/Australia production", "Recycling"]
  },
  { 
    symbol: "COBALT", 
    name: "Cobalt", 
    category: "industrial_metals", 
    unit: "USD per metric ton",
    exchange: "LME/OTC",
    tradingHours: "Limited",
    description: "Battery and aerospace metal",
    factors: ["EV demand", "DRC production", "Battery chemistry shifts", "ESG concerns"]
  },
];

// Agricultural Commodities
export const AGRICULTURAL_COMMODITIES: CommodityInfo[] = [
  { 
    symbol: "WHEAT", 
    name: "Wheat", 
    category: "agriculture", 
    unit: "USD per bushel",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Global food staple grain",
    factors: ["Weather", "Ukraine/Russia exports", "India policy", "Global demand"]
  },
  { 
    symbol: "CORN", 
    name: "Corn", 
    category: "agriculture", 
    unit: "USD per bushel",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Feed grain and ethanol source",
    factors: ["US weather", "Ethanol demand", "Feed demand", "Export competition"]
  },
  { 
    symbol: "SOYBEAN", 
    name: "Soybeans", 
    category: "agriculture", 
    unit: "USD per bushel",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Oilseed for food and feed",
    factors: ["China demand", "Brazil harvest", "Crush margins", "Weather"]
  },
  { 
    symbol: "RICE", 
    name: "Rice", 
    category: "agriculture", 
    unit: "USD per cwt",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Asian staple grain",
    factors: ["Asian weather", "India exports", "Thai production", "El Nino"]
  },
  { 
    symbol: "OATS", 
    name: "Oats", 
    category: "agriculture", 
    unit: "USD per bushel",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Cereal grain",
    factors: ["Canadian weather", "Health food demand", "Feed markets"]
  },
  { 
    symbol: "CANOLA", 
    name: "Canola", 
    category: "agriculture", 
    unit: "CAD per metric ton",
    exchange: "ICE Canada",
    tradingHours: "Exchange hours",
    description: "Oilseed for cooking oil",
    factors: ["Canadian weather", "Biofuel demand", "China relations", "Crush margins"]
  },
  { 
    symbol: "PALM", 
    name: "Palm Oil", 
    category: "agriculture", 
    unit: "MYR per metric ton",
    exchange: "BMD",
    tradingHours: "Exchange hours",
    description: "World's most used vegetable oil",
    factors: ["Indonesia/Malaysia production", "Biodiesel demand", "Weather", "ESG concerns"]
  },
  { 
    symbol: "SOYOIL", 
    name: "Soybean Oil", 
    category: "agriculture", 
    unit: "USD per pound",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "Cooking oil and biodiesel",
    factors: ["Soybean prices", "Biodiesel demand", "Palm oil prices", "Crush rates"]
  },
  { 
    symbol: "SOYMEAL", 
    name: "Soybean Meal", 
    category: "agriculture", 
    unit: "USD per ton",
    exchange: "CBOT",
    tradingHours: "CME Hours",
    description: "High-protein animal feed",
    factors: ["Soybean prices", "Livestock demand", "Crush rates", "Feed alternatives"]
  },
];

// Soft Commodities
export const SOFT_COMMODITIES: CommodityInfo[] = [
  { 
    symbol: "COFFEE", 
    name: "Coffee (Arabica)", 
    category: "softs", 
    unit: "USD per pound",
    exchange: "ICE",
    tradingHours: "ICE Hours",
    description: "Premium coffee beans",
    factors: ["Brazil weather", "Vietnam production", "Frost risk", "Consumption trends"]
  },
  { 
    symbol: "COCOA", 
    name: "Cocoa", 
    category: "softs", 
    unit: "USD per metric ton",
    exchange: "ICE",
    tradingHours: "ICE Hours",
    description: "Chocolate base commodity",
    factors: ["West Africa weather", "Disease", "Demand trends", "Grindings data"]
  },
  { 
    symbol: "SUGAR", 
    name: "Sugar #11", 
    category: "softs", 
    unit: "USD per pound",
    exchange: "ICE",
    tradingHours: "ICE Hours",
    description: "Raw cane sugar",
    factors: ["Brazil ethanol parity", "India exports", "Weather", "Global surplus/deficit"]
  },
  { 
    symbol: "COTTON", 
    name: "Cotton #2", 
    category: "softs", 
    unit: "USD per pound",
    exchange: "ICE",
    tradingHours: "ICE Hours",
    description: "Natural textile fiber",
    factors: ["US weather", "China demand", "Polyester prices", "Acreage"]
  },
  { 
    symbol: "OJ", 
    name: "Orange Juice", 
    category: "softs", 
    unit: "USD per pound",
    exchange: "ICE",
    tradingHours: "ICE Hours",
    description: "Frozen concentrated orange juice",
    factors: ["Florida weather", "Brazil production", "Disease", "Health trends"]
  },
  { 
    symbol: "LUMBER", 
    name: "Lumber", 
    category: "softs", 
    unit: "USD per 1000 board feet",
    exchange: "CME",
    tradingHours: "CME Hours",
    description: "Construction wood",
    factors: ["Housing starts", "Mill capacity", "Canadian beetle damage", "Import tariffs"]
  },
  { 
    symbol: "RUBBER", 
    name: "Natural Rubber", 
    category: "softs", 
    unit: "JPY per kg",
    exchange: "TOCOM/SGX",
    tradingHours: "Exchange hours",
    description: "Latex from rubber trees",
    factors: ["Thai/Indonesian supply", "Tire demand", "Auto production", "Weather"]
  },
];

// Livestock
export const LIVESTOCK_COMMODITIES: CommodityInfo[] = [
  { 
    symbol: "CATTLE", 
    name: "Live Cattle", 
    category: "livestock", 
    unit: "USD per pound",
    exchange: "CME",
    tradingHours: "CME Hours",
    description: "Beef cattle",
    factors: ["US herd size", "Feed costs", "Export demand", "Weather"]
  },
  { 
    symbol: "FCATTLE", 
    name: "Feeder Cattle", 
    category: "livestock", 
    unit: "USD per pound",
    exchange: "CME",
    tradingHours: "CME Hours",
    description: "Young cattle for feeding",
    factors: ["Corn prices", "Live cattle prices", "Weather", "Herd expansion"]
  },
  { 
    symbol: "HOGS", 
    name: "Lean Hogs", 
    category: "livestock", 
    unit: "USD per pound",
    exchange: "CME",
    tradingHours: "CME Hours",
    description: "Pork",
    factors: ["China demand", "ASF disease", "Feed costs", "Slaughter rates"]
  },
  { 
    symbol: "PORK", 
    name: "Pork Bellies", 
    category: "livestock", 
    unit: "USD per pound",
    exchange: "CME (delisted)",
    tradingHours: "N/A",
    description: "Bacon product",
    factors: ["Lean hog prices", "Cold storage", "Demand seasonality"]
  },
];

// Export all commodities
export const ALL_COMMODITIES = [
  ...PRECIOUS_METALS,
  ...ENERGY_COMMODITIES,
  ...INDUSTRIAL_METALS,
  ...AGRICULTURAL_COMMODITIES,
  ...SOFT_COMMODITIES,
  ...LIVESTOCK_COMMODITIES,
];

// Helper to get commodity by symbol
export function getCommodityBySymbol(symbol: string): CommodityInfo | undefined {
  return ALL_COMMODITIES.find(c => c.symbol === symbol);
}

// Get commodities by category
export function getCommoditiesByCategory(category: CommodityInfo['category']): CommodityInfo[] {
  return ALL_COMMODITIES.filter(c => c.category === category);
}
