// Complete list of global stock market indices

export interface IndexInfo {
  symbol: string;
  name: string;
  country: string;
  region: 'asia' | 'europe' | 'americas' | 'middle_east' | 'africa' | 'oceania';
  exchange: string;
  components: number;
  description: string;
  tradingHours: string;
}

// Indian Indices
export const INDIAN_INDICES: IndexInfo[] = [
  { symbol: "^NSEI", name: "NIFTY 50", country: "India", region: "asia", exchange: "NSE", components: 50, description: "Top 50 companies by market cap on NSE", tradingHours: "09:15-15:30 IST" },
  { symbol: "^BSESN", name: "SENSEX", country: "India", region: "asia", exchange: "BSE", components: 30, description: "Top 30 companies by market cap on BSE", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NSEBANK", name: "BANK NIFTY", country: "India", region: "asia", exchange: "NSE", components: 12, description: "Top banking sector stocks", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYIT", name: "NIFTY IT", country: "India", region: "asia", exchange: "NSE", components: 10, description: "Top IT sector stocks", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYFIN", name: "NIFTY Financial Services", country: "India", region: "asia", exchange: "NSE", components: 20, description: "Financial services sector", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYPHARMA", name: "NIFTY Pharma", country: "India", region: "asia", exchange: "NSE", components: 10, description: "Pharmaceutical sector", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYMETAL", name: "NIFTY Metal", country: "India", region: "asia", exchange: "NSE", components: 15, description: "Metal sector stocks", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYREALTY", name: "NIFTY Realty", country: "India", region: "asia", exchange: "NSE", components: 10, description: "Real estate sector", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYPSE", name: "NIFTY PSE", country: "India", region: "asia", exchange: "NSE", components: 20, description: "Public sector enterprises", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYAUTO", name: "NIFTY Auto", country: "India", region: "asia", exchange: "NSE", components: 15, description: "Automobile sector", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYMIDCAP", name: "NIFTY Midcap 100", country: "India", region: "asia", exchange: "NSE", components: 100, description: "Mid-cap companies", tradingHours: "09:15-15:30 IST" },
  { symbol: "^NIFTYSMALL", name: "NIFTY Smallcap 100", country: "India", region: "asia", exchange: "NSE", components: 100, description: "Small-cap companies", tradingHours: "09:15-15:30 IST" },
];

// US Indices
export const US_INDICES: IndexInfo[] = [
  { symbol: "^DJI", name: "Dow Jones Industrial Average", country: "USA", region: "americas", exchange: "NYSE", components: 30, description: "30 large US blue-chip companies", tradingHours: "09:30-16:00 EST" },
  { symbol: "^GSPC", name: "S&P 500", country: "USA", region: "americas", exchange: "NYSE", components: 500, description: "500 large-cap US companies", tradingHours: "09:30-16:00 EST" },
  { symbol: "^IXIC", name: "NASDAQ Composite", country: "USA", region: "americas", exchange: "NASDAQ", components: 3000, description: "All NASDAQ-listed stocks", tradingHours: "09:30-16:00 EST" },
  { symbol: "^NDX", name: "NASDAQ 100", country: "USA", region: "americas", exchange: "NASDAQ", components: 100, description: "100 largest non-financial NASDAQ companies", tradingHours: "09:30-16:00 EST" },
  { symbol: "^RUT", name: "Russell 2000", country: "USA", region: "americas", exchange: "NYSE", components: 2000, description: "Small-cap US companies", tradingHours: "09:30-16:00 EST" },
  { symbol: "^VIX", name: "CBOE Volatility Index", country: "USA", region: "americas", exchange: "CBOE", components: 0, description: "Fear index - S&P 500 volatility", tradingHours: "09:30-16:15 EST" },
  { symbol: "^SOX", name: "Philadelphia Semiconductor", country: "USA", region: "americas", exchange: "NASDAQ", components: 30, description: "Semiconductor companies", tradingHours: "09:30-16:00 EST" },
];

// European Indices
export const EUROPEAN_INDICES: IndexInfo[] = [
  { symbol: "^FTSE", name: "FTSE 100", country: "UK", region: "europe", exchange: "LSE", components: 100, description: "100 largest UK companies", tradingHours: "08:00-16:30 GMT" },
  { symbol: "^GDAXI", name: "DAX", country: "Germany", region: "europe", exchange: "XETRA", components: 40, description: "40 largest German companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^FCHI", name: "CAC 40", country: "France", region: "europe", exchange: "Euronext Paris", components: 40, description: "40 largest French companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^STOXX50E", name: "Euro Stoxx 50", country: "Eurozone", region: "europe", exchange: "Multiple", components: 50, description: "50 largest Eurozone companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^IBEX", name: "IBEX 35", country: "Spain", region: "europe", exchange: "BME", components: 35, description: "35 largest Spanish companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^AEX", name: "AEX", country: "Netherlands", region: "europe", exchange: "Euronext Amsterdam", components: 25, description: "25 largest Dutch companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^SSMI", name: "Swiss Market Index", country: "Switzerland", region: "europe", exchange: "SIX", components: 20, description: "20 largest Swiss companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^FTSEMIB", name: "FTSE MIB", country: "Italy", region: "europe", exchange: "Borsa Italiana", components: 40, description: "40 largest Italian companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^BFX", name: "BEL 20", country: "Belgium", region: "europe", exchange: "Euronext Brussels", components: 20, description: "20 largest Belgian companies", tradingHours: "09:00-17:30 CET" },
  { symbol: "^ATX", name: "Austrian Traded Index", country: "Austria", region: "europe", exchange: "Vienna Stock Exchange", components: 20, description: "20 most traded Austrian stocks", tradingHours: "09:00-17:30 CET" },
  { symbol: "^OMXS30", name: "OMX Stockholm 30", country: "Sweden", region: "europe", exchange: "NASDAQ Nordic", components: 30, description: "30 most traded Swedish stocks", tradingHours: "09:00-17:30 CET" },
  { symbol: "^OMXC25", name: "OMX Copenhagen 25", country: "Denmark", region: "europe", exchange: "NASDAQ Nordic", components: 25, description: "25 most traded Danish stocks", tradingHours: "09:00-17:00 CET" },
  { symbol: "^OMXH25", name: "OMX Helsinki 25", country: "Finland", region: "europe", exchange: "NASDAQ Nordic", components: 25, description: "25 most traded Finnish stocks", tradingHours: "10:00-18:30 EET" },
  { symbol: "^OSEAX", name: "Oslo All Share", country: "Norway", region: "europe", exchange: "Oslo Bors", components: 300, description: "All Oslo-listed stocks", tradingHours: "09:00-16:20 CET" },
  { symbol: "^PSI20", name: "PSI 20", country: "Portugal", region: "europe", exchange: "Euronext Lisbon", components: 20, description: "20 largest Portuguese companies", tradingHours: "08:00-16:30 WET" },
  { symbol: "^IMOEX", name: "MOEX Russia", country: "Russia", region: "europe", exchange: "MOEX", components: 50, description: "50 largest Russian companies", tradingHours: "10:00-18:50 MSK" },
  { symbol: "^WIG20", name: "WIG20", country: "Poland", region: "europe", exchange: "GPW", components: 20, description: "20 largest Polish companies", tradingHours: "09:00-17:00 CET" },
];

// Asian Indices
export const ASIAN_INDICES: IndexInfo[] = [
  { symbol: "^N225", name: "Nikkei 225", country: "Japan", region: "asia", exchange: "TSE", components: 225, description: "225 largest Japanese companies", tradingHours: "09:00-15:00 JST" },
  { symbol: "^TOPX", name: "TOPIX", country: "Japan", region: "asia", exchange: "TSE", components: 2200, description: "All First Section Tokyo stocks", tradingHours: "09:00-15:00 JST" },
  { symbol: "^HSI", name: "Hang Seng Index", country: "Hong Kong", region: "asia", exchange: "HKEX", components: 82, description: "82 largest Hong Kong companies", tradingHours: "09:30-16:00 HKT" },
  { symbol: "^HSCE", name: "Hang Seng China Enterprises", country: "Hong Kong", region: "asia", exchange: "HKEX", components: 50, description: "Chinese H-shares listed in HK", tradingHours: "09:30-16:00 HKT" },
  { symbol: "000001.SS", name: "Shanghai Composite", country: "China", region: "asia", exchange: "SSE", components: 2000, description: "All Shanghai-listed stocks", tradingHours: "09:30-15:00 CST" },
  { symbol: "399001.SZ", name: "Shenzhen Component", country: "China", region: "asia", exchange: "SZSE", components: 500, description: "500 Shenzhen-listed stocks", tradingHours: "09:30-15:00 CST" },
  { symbol: "000300.SS", name: "CSI 300", country: "China", region: "asia", exchange: "SSE/SZSE", components: 300, description: "300 largest A-shares", tradingHours: "09:30-15:00 CST" },
  { symbol: "^KS11", name: "KOSPI", country: "South Korea", region: "asia", exchange: "KRX", components: 800, description: "All Korea Exchange stocks", tradingHours: "09:00-15:30 KST" },
  { symbol: "^KOSDAQ", name: "KOSDAQ", country: "South Korea", region: "asia", exchange: "KRX", components: 1500, description: "Tech-heavy Korean index", tradingHours: "09:00-15:30 KST" },
  { symbol: "^TWII", name: "Taiwan Weighted", country: "Taiwan", region: "asia", exchange: "TWSE", components: 900, description: "All TWSE-listed stocks", tradingHours: "09:00-13:30 CST" },
  { symbol: "^STI", name: "Straits Times Index", country: "Singapore", region: "asia", exchange: "SGX", components: 30, description: "30 largest Singapore companies", tradingHours: "09:00-17:00 SGT" },
  { symbol: "^JKSE", name: "Jakarta Composite", country: "Indonesia", region: "asia", exchange: "IDX", components: 800, description: "All IDX-listed stocks", tradingHours: "09:00-16:00 WIB" },
  { symbol: "^KLSE", name: "FTSE Bursa Malaysia KLCI", country: "Malaysia", region: "asia", exchange: "Bursa Malaysia", components: 30, description: "30 largest Malaysian companies", tradingHours: "09:00-17:00 MYT" },
  { symbol: "^SET", name: "SET Index", country: "Thailand", region: "asia", exchange: "SET", components: 500, description: "All SET-listed stocks", tradingHours: "10:00-16:30 ICT" },
  { symbol: "^PSEi", name: "PSEi Composite", country: "Philippines", region: "asia", exchange: "PSE", components: 30, description: "30 largest Philippine companies", tradingHours: "09:30-15:30 PHT" },
  { symbol: "^VNINDEX", name: "VN-Index", country: "Vietnam", region: "asia", exchange: "HOSE", components: 400, description: "Ho Chi Minh Stock Exchange", tradingHours: "09:00-15:00 ICT" },
];

// Middle East Indices
export const MIDDLE_EAST_INDICES: IndexInfo[] = [
  { symbol: "^TASI", name: "Tadawul All Share", country: "Saudi Arabia", region: "middle_east", exchange: "Tadawul", components: 200, description: "Saudi Arabian stocks", tradingHours: "10:00-15:00 AST" },
  { symbol: "^DFMGI", name: "DFM General Index", country: "UAE", region: "middle_east", exchange: "DFM", components: 50, description: "Dubai Financial Market stocks", tradingHours: "10:00-14:00 GST" },
  { symbol: "^ADI", name: "Abu Dhabi Index", country: "UAE", region: "middle_east", exchange: "ADX", components: 70, description: "Abu Dhabi stocks", tradingHours: "10:00-14:00 GST" },
  { symbol: "^QSI", name: "Qatar Exchange Index", country: "Qatar", region: "middle_east", exchange: "QSE", components: 20, description: "Qatar stocks", tradingHours: "09:30-13:00 AST" },
  { symbol: "^TA35", name: "TA-35", country: "Israel", region: "middle_east", exchange: "TASE", components: 35, description: "35 largest Israeli companies", tradingHours: "09:59-17:14 IST" },
  { symbol: "^KWSE", name: "Kuwait All Share", country: "Kuwait", region: "middle_east", exchange: "Boursa Kuwait", components: 150, description: "All Kuwait stocks", tradingHours: "09:00-13:00 AST" },
  { symbol: "^BHSE", name: "Bahrain All Share", country: "Bahrain", region: "middle_east", exchange: "BHB", components: 40, description: "Bahrain stocks", tradingHours: "09:30-13:00 AST" },
  { symbol: "^MSM30", name: "Muscat Securities", country: "Oman", region: "middle_east", exchange: "MSX", components: 30, description: "Oman stocks", tradingHours: "10:00-13:00 GST" },
];

// Oceania Indices
export const OCEANIA_INDICES: IndexInfo[] = [
  { symbol: "^AXJO", name: "S&P/ASX 200", country: "Australia", region: "oceania", exchange: "ASX", components: 200, description: "200 largest Australian companies", tradingHours: "10:00-16:00 AEST" },
  { symbol: "^AORD", name: "All Ordinaries", country: "Australia", region: "oceania", exchange: "ASX", components: 500, description: "500 largest Australian stocks", tradingHours: "10:00-16:00 AEST" },
  { symbol: "^NZ50", name: "S&P/NZX 50", country: "New Zealand", region: "oceania", exchange: "NZX", components: 50, description: "50 largest NZ companies", tradingHours: "10:00-17:00 NZST" },
];

// Americas (Non-US) Indices
export const AMERICAS_INDICES: IndexInfo[] = [
  { symbol: "^GSPTSE", name: "S&P/TSX Composite", country: "Canada", region: "americas", exchange: "TSX", components: 250, description: "Canadian stock benchmark", tradingHours: "09:30-16:00 EST" },
  { symbol: "^BVSP", name: "Bovespa", country: "Brazil", region: "americas", exchange: "B3", components: 90, description: "90 most traded Brazilian stocks", tradingHours: "10:00-17:00 BRT" },
  { symbol: "^MXX", name: "IPC Mexico", country: "Mexico", region: "americas", exchange: "BMV", components: 35, description: "35 largest Mexican companies", tradingHours: "08:30-15:00 CST" },
  { symbol: "^MERV", name: "MERVAL", country: "Argentina", region: "americas", exchange: "BCBA", components: 20, description: "Leading Argentine stocks", tradingHours: "11:00-17:00 ART" },
  { symbol: "^IPSA", name: "IPSA", country: "Chile", region: "americas", exchange: "Santiago SE", components: 30, description: "30 most traded Chilean stocks", tradingHours: "09:30-16:00 CLT" },
  { symbol: "^COLCAP", name: "COLCAP", country: "Colombia", region: "americas", exchange: "BVC", components: 25, description: "25 most liquid Colombian stocks", tradingHours: "09:30-16:00 COT" },
  { symbol: "^SPBLPGPT", name: "S&P Lima General", country: "Peru", region: "americas", exchange: "BVL", components: 40, description: "Lima Stock Exchange", tradingHours: "09:00-16:00 PET" },
];

// Africa Indices
export const AFRICA_INDICES: IndexInfo[] = [
  { symbol: "^J203", name: "FTSE/JSE All Share", country: "South Africa", region: "africa", exchange: "JSE", components: 160, description: "JSE All Share Index", tradingHours: "09:00-17:00 SAST" },
  { symbol: "^J200", name: "FTSE/JSE Top 40", country: "South Africa", region: "africa", exchange: "JSE", components: 40, description: "40 largest JSE companies", tradingHours: "09:00-17:00 SAST" },
  { symbol: "^NGSE", name: "Nigerian All Share", country: "Nigeria", region: "africa", exchange: "NGX", components: 200, description: "Nigerian stocks", tradingHours: "10:00-14:30 WAT" },
  { symbol: "^EGX30", name: "EGX 30", country: "Egypt", region: "africa", exchange: "EGX", components: 30, description: "30 largest Egyptian companies", tradingHours: "10:00-14:30 EET" },
  { symbol: "^KNSMIDX", name: "NSE 20 Share", country: "Kenya", region: "africa", exchange: "NSE Kenya", components: 20, description: "Nairobi 20 Share Index", tradingHours: "09:30-15:00 EAT" },
  { symbol: "^MASI", name: "MASI", country: "Morocco", region: "africa", exchange: "Casablanca SE", components: 75, description: "Moroccan All Shares", tradingHours: "10:00-15:30 WET" },
];

// Export all indices
export const ALL_GLOBAL_INDICES = [
  ...INDIAN_INDICES,
  ...US_INDICES,
  ...EUROPEAN_INDICES,
  ...ASIAN_INDICES,
  ...MIDDLE_EAST_INDICES,
  ...OCEANIA_INDICES,
  ...AMERICAS_INDICES,
  ...AFRICA_INDICES,
];

// Helper to get index by symbol
export function getIndexBySymbol(symbol: string): IndexInfo | undefined {
  return ALL_GLOBAL_INDICES.find(i => i.symbol === symbol);
}

// Get indices by region
export function getIndicesByRegion(region: IndexInfo['region']): IndexInfo[] {
  return ALL_GLOBAL_INDICES.filter(i => i.region === region);
}

// Get indices by country
export function getIndicesByCountry(country: string): IndexInfo[] {
  return ALL_GLOBAL_INDICES.filter(i => i.country.toLowerCase() === country.toLowerCase());
}
