// Unified Asset Database with search functionality

import { NIFTY_50, NIFTY_NEXT_50, OTHER_NSE_STOCKS, type StockInfo } from './indian-stocks';
import { MAJOR_PAIRS, MINOR_PAIRS, EXOTIC_PAIRS, EMERGING_PAIRS, RARE_PAIRS, type ForexPair } from './forex-currencies';
import { ALL_CRYPTOS, type CryptoInfo } from './cryptocurrencies';
import { ALL_COMMODITIES, type CommodityInfo } from './commodities';
import { ALL_GLOBAL_INDICES, type IndexInfo } from './global-indices';
import type { AssetCategory } from '../trading-types';

// Unified Asset type for search results
export interface UnifiedAsset {
  id: string;
  symbol: string;
  name: string;
  category: AssetCategory;
  subcategory: string;
  description?: string;
  exchange?: string;
  sector?: string;
  launchDate?: string;
  tradingSymbol: string; // Symbol used for API calls
}

// Convert stocks to unified format
function convertStocks(stocks: StockInfo[]): UnifiedAsset[] {
  return stocks.map(stock => ({
    id: `stock_${stock.symbol}`,
    symbol: stock.symbol,
    name: stock.name,
    category: 'stocks' as AssetCategory,
    subcategory: stock.marketCap || 'Stock',
    description: `${stock.sector} - ${stock.industry}`,
    exchange: 'NSE/BSE',
    sector: stock.sector,
    launchDate: stock.listingDate,
    tradingSymbol: `${stock.symbol}.NS`, // NSE format for APIs
  }));
}

// Convert forex to unified format
function convertForex(pairs: ForexPair[]): UnifiedAsset[] {
  return pairs.map(pair => ({
    id: `forex_${pair.symbol.replace('/', '')}`,
    symbol: pair.symbol,
    name: pair.name,
    category: 'forex' as AssetCategory,
    subcategory: pair.category,
    description: `${pair.base}/${pair.quote} - ${pair.category} pair`,
    exchange: 'Forex',
    tradingSymbol: pair.symbol.replace('/', ''),
  }));
}

// Convert crypto to unified format
function convertCrypto(cryptos: CryptoInfo[]): UnifiedAsset[] {
  return cryptos.map(crypto => ({
    id: `crypto_${crypto.symbol}`,
    symbol: crypto.symbol.replace('USDT', ''),
    name: crypto.name,
    category: 'crypto' as AssetCategory,
    subcategory: crypto.category,
    description: crypto.description,
    exchange: 'Binance',
    launchDate: crypto.launchDate,
    tradingSymbol: crypto.symbol,
  }));
}

// Convert commodities to unified format
function convertCommodities(commodities: CommodityInfo[]): UnifiedAsset[] {
  return commodities.map(commodity => ({
    id: `commodity_${commodity.symbol}`,
    symbol: commodity.symbol,
    name: commodity.name,
    category: 'commodities' as AssetCategory,
    subcategory: commodity.category,
    description: commodity.description,
    exchange: commodity.exchange,
    tradingSymbol: commodity.symbol,
  }));
}

// Convert indices to unified format
function convertIndices(indices: IndexInfo[]): UnifiedAsset[] {
  return indices.map(index => ({
    id: `index_${index.symbol.replace('^', '')}`,
    symbol: getIndexDisplaySymbol(index.symbol, index.name),
    name: index.name,
    category: 'indices' as AssetCategory,
    subcategory: index.region,
    description: index.description,
    exchange: index.exchange,
    tradingSymbol: index.symbol,
  }));
}

// Map index symbols to common trading names
function getIndexDisplaySymbol(symbol: string, name: string): string {
  const symbolMap: Record<string, string> = {
    // Indian Indices
    '^NSEI': 'NIFTY',
    '^BSESN': 'SENSEX',
    '^NSEBANK': 'BANKNIFTY',
    '^NIFTYFIN': 'FINNIFTY',
    '^NIFTYMIDCAP': 'NIFTYMIDCAP',
    '^NIFTYSMALL': 'NIFTYSMALL',
    '^NIFTYIT': 'NIFTYIT',
    // US Indices
    '^GSPC': 'SPX',
    '^DJI': 'DJ30',
    '^IXIC': 'NASDAQ',
    '^NDX': 'NAS100',
    '^RUT': 'RUT2000',
    '^VIX': 'VIX',
    // European Indices
    '^FTSE': 'UK100',
    '^GDAXI': 'DAX40',
    '^FCHI': 'CAC40',
    // Asian Indices
    '^N225': 'JP225',
    '^HSI': 'HK50',
    '000001.SS': 'SSEC',
  };
  return symbolMap[symbol] || symbol.replace('^', '');
}

// Auto-correct common index name variations
export function resolveIndexSymbol(query: string): string {
  const normalized = query.toUpperCase().trim().replace(/\s+/g, '');
  const corrections: Record<string, string> = {
    // NIFTY variations
    'NIFTY': 'NIFTY',
    'NIFTY50': 'NIFTY',
    'NIFTY-50': 'NIFTY',
    'NSE': 'NIFTY',
    // BANK NIFTY variations
    'BANKNIFTY': 'BANKNIFTY',
    'BANK-NIFTY': 'BANKNIFTY',
    'BNIFTY': 'BANKNIFTY',
    'BN': 'BANKNIFTY',
    // FIN NIFTY variations
    'FINNIFTY': 'FINNIFTY',
    'FIN-NIFTY': 'FINNIFTY',
    'FNNIFTY': 'FINNIFTY',
    // SENSEX variations
    'SENSEX': 'SENSEX',
    'BSE': 'SENSEX',
    'BSE30': 'SENSEX',
    // US indices
    'S&P500': 'SPX',
    'SP500': 'SPX',
    'SPX500': 'SPX',
    'NASDAQ100': 'NAS100',
    'NDX': 'NAS100',
    'NASDAQ': 'NAS100',
    'DOW': 'DJ30',
    'DOWJONES': 'DJ30',
    'DOW30': 'DJ30',
    'DJIA': 'DJ30',
    'RUSSELL': 'RUT2000',
    'RUSSELL2000': 'RUT2000',
    // European
    'FTSE': 'UK100',
    'FTSE100': 'UK100',
    'DAX': 'DAX40',
    'DAX40': 'DAX40',
    'CAC': 'CAC40',
    'CAC40': 'CAC40',
    // Asian
    'NIKKEI': 'JP225',
    'NIKKEI225': 'JP225',
    'HANGSENG': 'HK50',
    'HSI': 'HK50',
    'SHANGHAI': 'SSEC',
  };
  return corrections[normalized] || normalized;
}

// All Indian Stocks
export const ALL_INDIAN_STOCKS = [...NIFTY_50, ...NIFTY_NEXT_50, ...OTHER_NSE_STOCKS];

// All Forex Pairs
export const ALL_FOREX_PAIRS = [...MAJOR_PAIRS, ...MINOR_PAIRS, ...EXOTIC_PAIRS, ...EMERGING_PAIRS, ...RARE_PAIRS];

// Build unified database
export const UNIFIED_ASSETS: UnifiedAsset[] = [
  ...convertStocks(ALL_INDIAN_STOCKS),
  ...convertForex(ALL_FOREX_PAIRS),
  ...convertCrypto(ALL_CRYPTOS),
  ...convertCommodities(ALL_COMMODITIES),
  ...convertIndices(ALL_GLOBAL_INDICES),
];

// Category counts
export const CATEGORY_COUNTS = {
  stocks: convertStocks(ALL_INDIAN_STOCKS).length,
  forex: convertForex(ALL_FOREX_PAIRS).length,
  crypto: convertCrypto(ALL_CRYPTOS).length,
  commodities: convertCommodities(ALL_COMMODITIES).length,
  indices: ALL_GLOBAL_INDICES.length,
};

// Search function with fuzzy matching
export function searchAssets(query: string, category?: AssetCategory, limit = 50): UnifiedAsset[] {
  const normalizedQuery = query.toLowerCase().trim();
  
  if (!normalizedQuery) {
    return category 
      ? UNIFIED_ASSETS.filter(a => a.category === category).slice(0, limit)
      : UNIFIED_ASSETS.slice(0, limit);
  }
  
  // Try to resolve index symbols first
  const resolvedIndex = resolveIndexSymbol(normalizedQuery);
  
  let assets = category 
    ? UNIFIED_ASSETS.filter(a => a.category === category)
    : UNIFIED_ASSETS;
  
  // Score and sort results
  const scored = assets.map(asset => {
    let score = 0;
    const symbol = asset.symbol.toLowerCase();
    const name = asset.name.toLowerCase();
    const description = (asset.description || '').toLowerCase();
    
    // Check resolved index symbol match (for indices)
    if (asset.category === 'indices' && symbol.toUpperCase() === resolvedIndex) {
      score += 150; // Highest priority for resolved index
    }
    
    // Exact symbol match (highest priority)
    if (symbol === normalizedQuery) score += 100;
    // Symbol starts with query
    else if (symbol.startsWith(normalizedQuery)) score += 50;
    // Symbol contains query
    else if (symbol.includes(normalizedQuery)) score += 30;
    
    // Exact name match
    if (name === normalizedQuery) score += 80;
    // Name starts with query
    else if (name.startsWith(normalizedQuery)) score += 40;
    // Name contains query word
    else if (name.includes(normalizedQuery)) score += 20;
    
    // Description contains query
    if (description.includes(normalizedQuery)) score += 10;
    
    // Sector/subcategory match
    if (asset.sector?.toLowerCase().includes(normalizedQuery)) score += 15;
    if (asset.subcategory.toLowerCase().includes(normalizedQuery)) score += 15;
    
    return { asset, score };
  });
  
  return scored
    .filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(s => s.asset);
}

// Get assets by category
export function getAssetsByCategory(category: AssetCategory, limit?: number): UnifiedAsset[] {
  const assets = UNIFIED_ASSETS.filter(a => a.category === category);
  return limit ? assets.slice(0, limit) : assets;
}

// Get asset by symbol
export function getAssetBySymbol(symbol: string): UnifiedAsset | undefined {
  const normalizedSymbol = symbol.toUpperCase();
  return UNIFIED_ASSETS.find(a => 
    a.symbol.toUpperCase() === normalizedSymbol || 
    a.tradingSymbol.toUpperCase() === normalizedSymbol ||
    a.tradingSymbol.toUpperCase().replace('.NS', '') === normalizedSymbol
  );
}

// Get popular assets for each category
export function getPopularAssets(): Record<AssetCategory, UnifiedAsset[]> {
  return {
    stocks: convertStocks(NIFTY_50.slice(0, 20)),
    forex: convertForex(MAJOR_PAIRS),
    crypto: convertCrypto(ALL_CRYPTOS.filter(c => 
      ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'LINKUSDT', 'MATICUSDT', 'AVAXUSDT'].includes(c.symbol)
    )),
    commodities: convertCommodities(ALL_COMMODITIES.filter(c => 
      ['XAUUSD', 'XAGUSD', 'USOIL', 'UKOIL', 'NATGAS', 'COPPER', 'WHEAT', 'CORN'].includes(c.symbol)
    )),
    indices: convertIndices(ALL_GLOBAL_INDICES.filter(i => 
      ['^NSEI', '^NSEBANK', '^BSESN', '^GSPC', '^NDX', '^DJI', '^FTSE', '^GDAXI', '^N225', '^HSI'].includes(i.symbol)
    )),
  };
}

// Get indices
export function getIndices(region?: IndexInfo['region']): IndexInfo[] {
  return region 
    ? ALL_GLOBAL_INDICES.filter(i => i.region === region)
    : ALL_GLOBAL_INDICES;
}

// Trading styles
export type TradingStyleType = 'fo' | 'intraday' | 'swing' | 'scalping' | 'longterm';

export interface TradingStyleInfo {
  id: TradingStyleType;
  name: string;
  description: string;
  timeframes: string[];
  holdingPeriod: string;
  riskLevel: 'low' | 'medium' | 'high' | 'very_high';
  capitalRequired: string;
  bestFor: string[];
}

export const TRADING_STYLES: TradingStyleInfo[] = [
  {
    id: 'fo',
    name: 'Futures & Options (F&O)',
    description: 'Derivatives trading with leverage for hedging or speculation',
    timeframes: ['5m', '15m', '1h', '4h', '1d'],
    holdingPeriod: 'Same day to expiry',
    riskLevel: 'very_high',
    capitalRequired: 'High (margin requirements)',
    bestFor: ['Hedging', 'Leverage trading', 'Income generation', 'Portfolio protection']
  },
  {
    id: 'intraday',
    name: 'Intraday Trading',
    description: 'Buying and selling within the same trading day',
    timeframes: ['1m', '5m', '15m', '1h'],
    holdingPeriod: 'Same day (no overnight)',
    riskLevel: 'high',
    capitalRequired: 'Medium to High',
    bestFor: ['Quick profits', 'No overnight risk', 'Active traders']
  },
  {
    id: 'swing',
    name: 'Swing Trading',
    description: 'Capturing short to medium-term price movements',
    timeframes: ['1h', '4h', '1d', '1w'],
    holdingPeriod: 'Days to weeks',
    riskLevel: 'medium',
    capitalRequired: 'Medium',
    bestFor: ['Part-time traders', 'Trend following', 'Technical analysis']
  },
  {
    id: 'scalping',
    name: 'Scalping',
    description: 'Making many small profits from tiny price changes',
    timeframes: ['1m', '5m', '15m'],
    holdingPeriod: 'Seconds to minutes',
    riskLevel: 'very_high',
    capitalRequired: 'High (for meaningful profits)',
    bestFor: ['Full-time traders', 'High liquidity markets', 'Quick decision makers']
  },
  {
    id: 'longterm',
    name: 'Long-term Investment',
    description: 'Buy and hold strategy based on fundamentals',
    timeframes: ['1d', '1w', '1M'],
    holdingPeriod: 'Months to years',
    riskLevel: 'low',
    capitalRequired: 'Variable',
    bestFor: ['Wealth building', 'Retirement planning', 'Passive investing', 'Value investors']
  }
];

// Get trading style by ID
export function getTradingStyle(id: TradingStyleType): TradingStyleInfo | undefined {
  return TRADING_STYLES.find(s => s.id === id);
}
