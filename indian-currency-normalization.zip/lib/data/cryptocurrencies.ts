// Complete list of major cryptocurrencies

export interface CryptoInfo {
  symbol: string;
  name: string;
  category: 'layer1' | 'layer2' | 'defi' | 'meme' | 'exchange' | 'stablecoin' | 'gaming' | 'ai' | 'infrastructure';
  description: string;
  launchDate?: string;
  maxSupply?: string;
  website?: string;
}

// Major Cryptocurrencies - Layer 1
export const LAYER1_CRYPTOS: CryptoInfo[] = [
  { symbol: "BTCUSDT", name: "Bitcoin", category: "layer1", description: "First decentralized cryptocurrency and digital gold", launchDate: "2009-01-03", maxSupply: "21,000,000", website: "bitcoin.org" },
  { symbol: "ETHUSDT", name: "Ethereum", category: "layer1", description: "Programmable blockchain for smart contracts and dApps", launchDate: "2015-07-30", maxSupply: "Unlimited", website: "ethereum.org" },
  { symbol: "SOLUSDT", name: "Solana", category: "layer1", description: "High-performance blockchain with fast transactions", launchDate: "2020-03-16", maxSupply: "Unlimited", website: "solana.com" },
  { symbol: "ADAUSDT", name: "Cardano", category: "layer1", description: "Research-driven blockchain platform", launchDate: "2017-09-29", maxSupply: "45,000,000,000", website: "cardano.org" },
  { symbol: "AVAXUSDT", name: "Avalanche", category: "layer1", description: "Platform for launching DeFi applications", launchDate: "2020-09-21", maxSupply: "720,000,000", website: "avax.network" },
  { symbol: "DOTUSDT", name: "Polkadot", category: "layer1", description: "Multi-chain interoperability protocol", launchDate: "2020-05-26", maxSupply: "Unlimited", website: "polkadot.network" },
  { symbol: "ATOMUSDT", name: "Cosmos", category: "layer1", description: "Internet of blockchains ecosystem", launchDate: "2019-03-14", maxSupply: "Unlimited", website: "cosmos.network" },
  { symbol: "NEARUSDT", name: "NEAR Protocol", category: "layer1", description: "Sharded proof-of-stake blockchain", launchDate: "2020-04-22", maxSupply: "1,000,000,000", website: "near.org" },
  { symbol: "ALGOUSDT", name: "Algorand", category: "layer1", description: "Pure proof-of-stake blockchain", launchDate: "2019-06-19", maxSupply: "10,000,000,000", website: "algorand.com" },
  { symbol: "FTMUSDT", name: "Fantom", category: "layer1", description: "High-performance smart contract platform", launchDate: "2019-12-27", maxSupply: "3,175,000,000", website: "fantom.foundation" },
  { symbol: "APTUSDT", name: "Aptos", category: "layer1", description: "Safe, scalable Layer 1 blockchain", launchDate: "2022-10-17", maxSupply: "Unlimited", website: "aptoslabs.com" },
  { symbol: "SUIUSDT", name: "Sui", category: "layer1", description: "Object-centric Layer 1 blockchain", launchDate: "2023-05-03", maxSupply: "10,000,000,000", website: "sui.io" },
  { symbol: "SEIUSDT", name: "Sei", category: "layer1", description: "Trading-focused Layer 1 blockchain", launchDate: "2023-08-15", maxSupply: "10,000,000,000", website: "sei.io" },
  { symbol: "XLMUSDT", name: "Stellar", category: "layer1", description: "Open network for money transfers", launchDate: "2014-07-31", maxSupply: "50,001,806,812", website: "stellar.org" },
  { symbol: "XRPUSDT", name: "XRP", category: "layer1", description: "Digital payment network and protocol", launchDate: "2012-06-02", maxSupply: "100,000,000,000", website: "ripple.com" },
  { symbol: "TONUSDT", name: "Toncoin", category: "layer1", description: "Telegram Open Network blockchain", launchDate: "2018-01-01", maxSupply: "5,000,000,000", website: "ton.org" },
  { symbol: "TRXUSDT", name: "TRON", category: "layer1", description: "Decentralized content sharing platform", launchDate: "2017-09-09", maxSupply: "Unlimited", website: "tron.network" },
  { symbol: "ICPUSDT", name: "Internet Computer", category: "layer1", description: "World computer blockchain", launchDate: "2021-05-10", maxSupply: "Unlimited", website: "dfinity.org" },
  { symbol: "HBARUSDT", name: "Hedera", category: "layer1", description: "Enterprise-grade public network", launchDate: "2019-09-16", maxSupply: "50,000,000,000", website: "hedera.com" },
  { symbol: "VETUSDT", name: "VeChain", category: "layer1", description: "Enterprise blockchain for supply chain", launchDate: "2018-06-30", maxSupply: "86,712,634,466", website: "vechain.org" },
];

// Layer 2 Solutions
export const LAYER2_CRYPTOS: CryptoInfo[] = [
  { symbol: "MATICUSDT", name: "Polygon", category: "layer2", description: "Ethereum scaling solution", launchDate: "2019-04-26", maxSupply: "10,000,000,000", website: "polygon.technology" },
  { symbol: "ARBUSDT", name: "Arbitrum", category: "layer2", description: "Optimistic rollup for Ethereum", launchDate: "2023-03-23", maxSupply: "10,000,000,000", website: "arbitrum.io" },
  { symbol: "OPUSDT", name: "Optimism", category: "layer2", description: "Low-cost Ethereum transactions", launchDate: "2022-05-31", maxSupply: "4,294,967,296", website: "optimism.io" },
  { symbol: "IMXUSDT", name: "Immutable X", category: "layer2", description: "NFT scaling solution for Ethereum", launchDate: "2021-06-28", maxSupply: "2,000,000,000", website: "immutable.com" },
  { symbol: "STRKUSDT", name: "Starknet", category: "layer2", description: "ZK-Rollup Layer 2 network", launchDate: "2024-02-20", maxSupply: "10,000,000,000", website: "starknet.io" },
  { symbol: "ZKUSDT", name: "zkSync", category: "layer2", description: "ZK-rollup scaling solution", launchDate: "2024-06-17", maxSupply: "21,000,000,000", website: "zksync.io" },
  { symbol: "MANTAUSDT", name: "Manta Network", category: "layer2", description: "Modular L2 for ZK applications", launchDate: "2024-01-18", maxSupply: "1,000,000,000", website: "manta.network" },
  { symbol: "METISUSDT", name: "Metis", category: "layer2", description: "Ethereum Layer 2 rollup", launchDate: "2021-11-19", maxSupply: "10,000,000", website: "metis.io" },
];

// DeFi Tokens
export const DEFI_CRYPTOS: CryptoInfo[] = [
  { symbol: "UNIUSDT", name: "Uniswap", category: "defi", description: "Decentralized exchange protocol", launchDate: "2020-09-17", maxSupply: "1,000,000,000", website: "uniswap.org" },
  { symbol: "AAVEUSDT", name: "Aave", category: "defi", description: "Decentralized lending protocol", launchDate: "2017-11-28", maxSupply: "16,000,000", website: "aave.com" },
  { symbol: "LINKUSDT", name: "Chainlink", category: "defi", description: "Decentralized oracle network", launchDate: "2017-09-19", maxSupply: "1,000,000,000", website: "chain.link" },
  { symbol: "MKRUSDT", name: "Maker", category: "defi", description: "Decentralized stablecoin governance", launchDate: "2017-12-18", maxSupply: "1,005,577", website: "makerdao.com" },
  { symbol: "CRVUSDT", name: "Curve DAO", category: "defi", description: "Stablecoin exchange protocol", launchDate: "2020-08-13", maxSupply: "3,030,303,031", website: "curve.fi" },
  { symbol: "COMPUSDT", name: "Compound", category: "defi", description: "Algorithmic money market protocol", launchDate: "2020-06-15", maxSupply: "10,000,000", website: "compound.finance" },
  { symbol: "SNXUSDT", name: "Synthetix", category: "defi", description: "Synthetic assets protocol", launchDate: "2018-03-01", maxSupply: "Unlimited", website: "synthetix.io" },
  { symbol: "LDOUSDT", name: "Lido DAO", category: "defi", description: "Liquid staking solution", launchDate: "2020-12-18", maxSupply: "1,000,000,000", website: "lido.fi" },
  { symbol: "SUSHIUSDT", name: "SushiSwap", category: "defi", description: "Decentralized exchange", launchDate: "2020-08-28", maxSupply: "250,000,000", website: "sushi.com" },
  { symbol: "1INCHUSDT", name: "1inch", category: "defi", description: "DEX aggregator protocol", launchDate: "2020-12-25", maxSupply: "1,500,000,000", website: "1inch.io" },
  { symbol: "INJUSDT", name: "Injective", category: "defi", description: "DeFi protocol for trading", launchDate: "2020-10-19", maxSupply: "100,000,000", website: "injective.com" },
  { symbol: "GMXUSDT", name: "GMX", category: "defi", description: "Decentralized perpetuals exchange", launchDate: "2021-09-01", maxSupply: "13,250,000", website: "gmx.io" },
  { symbol: "DYDXUSDT", name: "dYdX", category: "defi", description: "Decentralized derivatives exchange", launchDate: "2021-09-08", maxSupply: "1,000,000,000", website: "dydx.exchange" },
  { symbol: "PENDLEUSDT", name: "Pendle", category: "defi", description: "Yield trading protocol", launchDate: "2021-06-15", maxSupply: "251,061,124", website: "pendle.finance" },
  { symbol: "JUPUSDT", name: "Jupiter", category: "defi", description: "Solana DEX aggregator", launchDate: "2024-01-31", maxSupply: "10,000,000,000", website: "jup.ag" },
];

// Exchange Tokens
export const EXCHANGE_CRYPTOS: CryptoInfo[] = [
  { symbol: "BNBUSDT", name: "BNB", category: "exchange", description: "Binance ecosystem token", launchDate: "2017-07-25", maxSupply: "200,000,000", website: "bnbchain.org" },
  { symbol: "OKBUSDT", name: "OKB", category: "exchange", description: "OKX exchange token", launchDate: "2018-03-31", maxSupply: "300,000,000", website: "okx.com" },
  { symbol: "FTMUSDT", name: "FTT", category: "exchange", description: "FTX exchange token (defunct)", launchDate: "2019-05-08", maxSupply: "352,170,015" },
  { symbol: "CRONOUSDT", name: "Cronos", category: "exchange", description: "Crypto.com ecosystem token", launchDate: "2018-11-14", maxSupply: "30,263,013,692", website: "crypto.com" },
  { symbol: "GTUSDT", name: "Gate Token", category: "exchange", description: "Gate.io exchange token", launchDate: "2019-03-14", maxSupply: "300,000,000", website: "gate.io" },
  { symbol: "HTUSDT", name: "Huobi Token", category: "exchange", description: "Huobi exchange token", launchDate: "2018-01-24", maxSupply: "500,000,000", website: "huobi.com" },
];

// Meme Coins
export const MEME_CRYPTOS: CryptoInfo[] = [
  { symbol: "DOGEUSDT", name: "Dogecoin", category: "meme", description: "Original meme cryptocurrency", launchDate: "2013-12-06", maxSupply: "Unlimited", website: "dogecoin.com" },
  { symbol: "SHIBUSDT", name: "Shiba Inu", category: "meme", description: "Dogecoin killer meme token", launchDate: "2020-08-01", maxSupply: "999,982,362,095,958", website: "shibatoken.com" },
  { symbol: "PEPEUSDT", name: "Pepe", category: "meme", description: "Pepe the Frog meme coin", launchDate: "2023-04-14", maxSupply: "420,690,000,000,000", website: "pepe.vip" },
  { symbol: "FLOKIUSDT", name: "Floki", category: "meme", description: "Viking-themed meme coin", launchDate: "2021-06-28", maxSupply: "10,000,000,000,000", website: "floki.com" },
  { symbol: "WIFUSDT", name: "dogwifhat", category: "meme", description: "Solana meme coin", launchDate: "2023-11-20", maxSupply: "998,946,171", website: "dogwifcoin.org" },
  { symbol: "BONKUSDT", name: "Bonk", category: "meme", description: "Solana dog meme coin", launchDate: "2022-12-25", maxSupply: "93,726,779,841,286", website: "bonkcoin.com" },
  { symbol: "MEMEUSDT", name: "Memecoin", category: "meme", description: "9GAG meme token", launchDate: "2023-10-28", maxSupply: "69,000,000,000", website: "memecoin.org" },
  { symbol: "BOMEUSDT", name: "BOOK OF MEME", category: "meme", description: "Cultural meme archive token", launchDate: "2024-03-14", maxSupply: "68,966,894,549", website: "bookofmeme.io" },
  { symbol: "MOGUSDT", name: "Mog Coin", category: "meme", description: "Cat meme coin", launchDate: "2023-07-19", maxSupply: "420,000,000,000,000" },
  { symbol: "TRUMPUSDT", name: "Official Trump", category: "meme", description: "Trump meme coin", launchDate: "2025-01-17", maxSupply: "1,000,000,000" },
];

// Gaming & Metaverse
export const GAMING_CRYPTOS: CryptoInfo[] = [
  { symbol: "AXSUSDT", name: "Axie Infinity", category: "gaming", description: "Play-to-earn gaming ecosystem", launchDate: "2020-11-04", maxSupply: "270,000,000", website: "axieinfinity.com" },
  { symbol: "SANDUSDT", name: "The Sandbox", category: "gaming", description: "Virtual world gaming platform", launchDate: "2020-08-14", maxSupply: "3,000,000,000", website: "sandbox.game" },
  { symbol: "MANAUSDT", name: "Decentraland", category: "gaming", description: "Virtual reality platform", launchDate: "2017-09-08", maxSupply: "2,805,886,393", website: "decentraland.org" },
  { symbol: "ENJUSDT", name: "Enjin Coin", category: "gaming", description: "Gaming NFT platform", launchDate: "2017-10-31", maxSupply: "1,000,000,000", website: "enjin.io" },
  { symbol: "GALAUSDT", name: "Gala", category: "gaming", description: "Blockchain gaming ecosystem", launchDate: "2020-09-16", maxSupply: "50,000,000,000", website: "gala.games" },
  { symbol: "ILLUSDT", name: "Illuvium", category: "gaming", description: "Open-world RPG game", launchDate: "2021-03-30", maxSupply: "10,000,000", website: "illuvium.io" },
  { symbol: "RONUSDT", name: "Ronin", category: "gaming", description: "Gaming-focused blockchain", launchDate: "2022-01-27", maxSupply: "1,000,000,000", website: "roninchain.com" },
  { symbol: "YGGUSDT", name: "Yield Guild Games", category: "gaming", description: "Play-to-earn gaming guild", launchDate: "2021-07-27", maxSupply: "1,000,000,000", website: "yieldguild.io" },
  { symbol: "IMXUSDT", name: "IMX", category: "gaming", description: "NFT gaming Layer 2", launchDate: "2021-10-08", maxSupply: "2,000,000,000", website: "immutable.com" },
  { symbol: "MAGICUSDT", name: "Magic", category: "gaming", description: "Treasure ecosystem token", launchDate: "2021-09-01", maxSupply: "347,714,007", website: "treasure.lol" },
];

// AI & Infrastructure
export const AI_CRYPTOS: CryptoInfo[] = [
  { symbol: "FETUSDT", name: "Fetch.ai", category: "ai", description: "AI-powered autonomous agents", launchDate: "2019-02-25", maxSupply: "1,152,997,575", website: "fetch.ai" },
  { symbol: "OCEANUSDT", name: "Ocean Protocol", category: "ai", description: "Data marketplace protocol", launchDate: "2019-05-06", maxSupply: "1,410,000,000", website: "oceanprotocol.com" },
  { symbol: "AGIXUSDT", name: "SingularityNET", category: "ai", description: "AI services marketplace", launchDate: "2017-12-21", maxSupply: "2,000,000,000", website: "singularitynet.io" },
  { symbol: "RENDERUSDT", name: "Render", category: "ai", description: "Distributed GPU rendering", launchDate: "2020-06-11", maxSupply: "536,870,912", website: "rendernetwork.com" },
  { symbol: "TAOUSDT", name: "Bittensor", category: "ai", description: "Decentralized machine learning", launchDate: "2021-04-01", maxSupply: "21,000,000", website: "bittensor.com" },
  { symbol: "AKUSDT", name: "Akash Network", category: "ai", description: "Decentralized cloud computing", launchDate: "2020-09-25", maxSupply: "388,539,008", website: "akash.network" },
  { symbol: "GRTUSDT", name: "The Graph", category: "infrastructure", description: "Indexing protocol for blockchains", launchDate: "2020-12-17", maxSupply: "10,799,506,014", website: "thegraph.com" },
  { symbol: "FILUSDT", name: "Filecoin", category: "infrastructure", description: "Decentralized storage network", launchDate: "2020-10-15", maxSupply: "1,960,000,000", website: "filecoin.io" },
  { symbol: "ARUSDT", name: "Arweave", category: "infrastructure", description: "Permanent data storage", launchDate: "2018-06-08", maxSupply: "66,000,000", website: "arweave.org" },
  { symbol: "STXUSDT", name: "Stacks", category: "infrastructure", description: "Bitcoin smart contracts", launchDate: "2019-10-28", maxSupply: "1,818,000,000", website: "stacks.co" },
  { symbol: "RNDRUSDT", name: "Render Token", category: "ai", description: "GPU rendering network", launchDate: "2020-06-11", maxSupply: "536,870,912", website: "rendernetwork.com" },
  { symbol: "WLDUSDT", name: "Worldcoin", category: "ai", description: "Global identity and finance", launchDate: "2023-07-24", maxSupply: "10,000,000,000", website: "worldcoin.org" },
];

// Stablecoins (for reference)
export const STABLECOINS: CryptoInfo[] = [
  { symbol: "USDTUSDT", name: "Tether", category: "stablecoin", description: "USD-pegged stablecoin", launchDate: "2014-10-06", website: "tether.to" },
  { symbol: "USDCUSDT", name: "USD Coin", category: "stablecoin", description: "Regulated USD stablecoin", launchDate: "2018-09-26", website: "circle.com" },
  { symbol: "DAIUSDT", name: "Dai", category: "stablecoin", description: "Decentralized stablecoin", launchDate: "2017-12-18", website: "makerdao.com" },
  { symbol: "BUSDUSDT", name: "Binance USD", category: "stablecoin", description: "Binance USD stablecoin", launchDate: "2019-09-05", website: "paxos.com" },
  { symbol: "TUSDUSDT", name: "TrueUSD", category: "stablecoin", description: "Fully collateralized USD token", launchDate: "2018-03-05", website: "trueusd.com" },
  { symbol: "FRAXUSDT", name: "Frax", category: "stablecoin", description: "Fractional-algorithmic stablecoin", launchDate: "2020-12-21", website: "frax.finance" },
  { symbol: "LUSDUSDT", name: "Liquity USD", category: "stablecoin", description: "ETH-backed stablecoin", launchDate: "2021-04-05", website: "liquity.org" },
];

// Export all cryptocurrencies
export const ALL_CRYPTOS = [
  ...LAYER1_CRYPTOS,
  ...LAYER2_CRYPTOS,
  ...DEFI_CRYPTOS,
  ...EXCHANGE_CRYPTOS,
  ...MEME_CRYPTOS,
  ...GAMING_CRYPTOS,
  ...AI_CRYPTOS,
];

// Helper to get crypto by symbol
export function getCryptoBySymbol(symbol: string): CryptoInfo | undefined {
  return ALL_CRYPTOS.find(c => c.symbol === symbol || c.symbol === `${symbol}USDT`);
}
