export type AssetCategory = 'stocks' | 'forex' | 'crypto' | 'commodities' | 'indices';

export type TradingStyle = 'fo' | 'intraday' | 'swing' | 'scalping' | 'longterm';

export type TradingStyleType = TradingStyle;

export type Sentiment = 'bullish' | 'bearish' | 'neutral';

export interface Asset {
  symbol: string;
  name: string;
  category: AssetCategory;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high24h: number;
  low24h: number;
  lastUpdated: Date;
}

export interface AISignal {
  sentiment: Sentiment;
  confidence: number; // 0-100
  trendStrength: number; // 0-100
  entry: number;
  target: number;
  stopLoss: number;
  atr: number;
  tradingStyle: TradingStyle;
}

export interface PredictionData {
  asset: Asset;
  signal: AISignal;
  newsScore: number; // -100 to 100 (bearish to bullish)
  timestamp: Date;
}

export interface CandleData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface MarketTicker {
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
  volume: string;
}

export interface HeatmapItem {
  symbol: string;
  name: string;
  category: AssetCategory;
  volatility: number;
  change: number;
  price: number;
  volume: number;
}
