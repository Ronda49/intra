import type { Asset, AssetCategory, CandleData, MarketTicker } from './trading-types';
import { convertUSDToINR } from './currency';

// Finnhub API client for stocks/forex
export class FinnhubClient {
  private apiKey: string;
  private baseUrl = 'https://finnhub.io/api/v1';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async getQuote(symbol: string): Promise<Asset | null> {
    try {
      const response = await fetch(
        `${this.baseUrl}/quote?symbol=${symbol}&token=${this.apiKey}`
      );
      const data = await response.json();
      
      if (data.c === 0) return null;
      
      return {
        symbol,
        name: symbol,
        category: 'stocks',
        price: data.c,
        change: data.d,
        changePercent: data.dp,
        volume: 0,
        high24h: data.h,
        low24h: data.l,
        lastUpdated: new Date(),
      };
    } catch (error) {
      console.error('Finnhub quote error:', error);
      return null;
    }
  }

  async getCandles(symbol: string, resolution: string, from: number, to: number): Promise<CandleData[]> {
    try {
      const response = await fetch(
        `${this.baseUrl}/stock/candle?symbol=${symbol}&resolution=${resolution}&from=${from}&to=${to}&token=${this.apiKey}`
      );
      const data = await response.json();
      
      if (data.s !== 'ok') return [];
      
      return data.t.map((time: number, i: number) => ({
        time,
        open: data.o[i],
        high: data.h[i],
        low: data.l[i],
        close: data.c[i],
        volume: data.v[i],
      }));
    } catch (error) {
      console.error('Finnhub candles error:', error);
      return [];
    }
  }

  createWebSocket(symbols: string[], onMessage: (data: MarketTicker) => void): WebSocket | null {
    try {
      const ws = new WebSocket(`wss://ws.finnhub.io?token=${this.apiKey}`);
      
      ws.onopen = () => {
        symbols.forEach(symbol => {
          ws.send(JSON.stringify({ type: 'subscribe', symbol }));
        });
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === 'trade' && data.data?.[0]) {
          const trade = data.data[0];
          onMessage({
            symbol: trade.s,
            price: trade.p.toFixed(2),
            change: '0',
            changePercent: '0',
            volume: trade.v.toString(),
          });
        }
      };

      return ws;
    } catch (error) {
      console.error('Finnhub WebSocket error:', error);
      return null;
    }
  }
}

// Binance API client for crypto
export class BinanceClient {
  private baseUrl = 'https://api.binance.com/api/v3';

  async getPrice(symbol: string): Promise<Asset | null> {
    try {
      const [tickerRes, statsRes] = await Promise.all([
        fetch(`${this.baseUrl}/ticker/price?symbol=${symbol}`),
        fetch(`${this.baseUrl}/ticker/24hr?symbol=${symbol}`),
      ]);
      
      const ticker = await tickerRes.json();
      const stats = await statsRes.json();
      
      // Convert all USD prices to INR
      const priceUSD = parseFloat(ticker.price);
      const changeUSD = parseFloat(stats.priceChange);
      const volumeUSD = parseFloat(stats.volume) * priceUSD; // Convert volume to value
      const high24hUSD = parseFloat(stats.highPrice);
      const low24hUSD = parseFloat(stats.lowPrice);
      
      return {
        symbol,
        name: symbol.replace('USDT', ''),
        category: 'crypto',
        price: convertUSDToINR(priceUSD),
        change: convertUSDToINR(changeUSD),
        changePercent: parseFloat(stats.priceChangePercent), // Percentage stays same
        volume: convertUSDToINR(volumeUSD),
        high24h: convertUSDToINR(high24hUSD),
        low24h: convertUSDToINR(low24hUSD),
        lastUpdated: new Date(),
      };
    } catch (error) {
      console.error('Binance price error:', error);
      return null;
    }
  }

  async getKlines(symbol: string, interval: string, limit = 100): Promise<CandleData[]> {
    try {
      const response = await fetch(
        `${this.baseUrl}/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
      );
      const data = await response.json();
      
      // Convert all USD candle prices to INR
      return data.map((kline: (string | number)[]) => {
        const openUSD = parseFloat(kline[1] as string);
        const highUSD = parseFloat(kline[2] as string);
        const lowUSD = parseFloat(kline[3] as string);
        const closeUSD = parseFloat(kline[4] as string);
        const volumeUSD = parseFloat(kline[5] as string) * closeUSD;
        
        return {
          time: Math.floor(Number(kline[0]) / 1000),
          open: convertUSDToINR(openUSD),
          high: convertUSDToINR(highUSD),
          low: convertUSDToINR(lowUSD),
          close: convertUSDToINR(closeUSD),
          volume: convertUSDToINR(volumeUSD),
        };
      });
    } catch (error) {
      console.error('Binance klines error:', error);
      return [];
    }
  }

  createWebSocket(symbols: string[], onMessage: (data: MarketTicker) => void): WebSocket | null {
    try {
      const streams = symbols.map(s => `${s.toLowerCase()}@ticker`).join('/');
      const ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);

      ws.onmessage = (event) => {
        const { data } = JSON.parse(event.data);
        if (data) {
          onMessage({
            symbol: data.s,
            price: parseFloat(data.c).toFixed(2),
            change: parseFloat(data.p).toFixed(2),
            changePercent: parseFloat(data.P).toFixed(2),
            volume: parseFloat(data.v).toFixed(0),
          });
        }
      };

      return ws;
    } catch (error) {
      console.error('Binance WebSocket error:', error);
      return null;
    }
  }
}

// Calculate ATR for stop loss
export function calculateATR(candles: CandleData[], period = 14): number {
  if (candles.length < period + 1) return 0;
  
  const trueRanges: number[] = [];
  
  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const previous = candles[i - 1];
    
    const tr = Math.max(
      current.high - current.low,
      Math.abs(current.high - previous.close),
      Math.abs(current.low - previous.close)
    );
    trueRanges.push(tr);
  }
  
  const recentTRs = trueRanges.slice(-period);
  return recentTRs.reduce((sum, tr) => sum + tr, 0) / period;
}

// Calculate dynamic stop loss
export function calculateStopLoss(price: number, atr: number, isLong: boolean, multiplier = 2): number {
  return isLong ? price - (multiplier * atr) : price + (multiplier * atr);
}

// Generate mock AI signal (simulates ML model output)
export function generateAISignal(asset: Asset, candles: CandleData[]): {
  sentiment: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  trendStrength: number;
  entry: number;
  target: number;
  stopLoss: number;
} {
  const atr = calculateATR(candles);
  const recentCandles = candles.slice(-20);
  
  // Simple momentum calculation
  const closes = recentCandles.map(c => c.close);
  const sma5 = closes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const sma20 = closes.reduce((a, b) => a + b, 0) / closes.length;
  
  const momentum = ((sma5 - sma20) / sma20) * 100;
  const volatility = (atr / asset.price) * 100;
  
  let sentiment: 'bullish' | 'bearish' | 'neutral' = 'neutral';
  let confidence = 50;
  let trendStrength = Math.min(100, Math.abs(momentum) * 10);
  
  if (momentum > 0.5) {
    sentiment = 'bullish';
    confidence = Math.min(95, 60 + momentum * 5);
  } else if (momentum < -0.5) {
    sentiment = 'bearish';
    confidence = Math.min(95, 60 + Math.abs(momentum) * 5);
  }
  
  const isLong = sentiment === 'bullish';
  const entry = asset.price;
  const stopLoss = calculateStopLoss(entry, atr, isLong);
  const riskReward = 2;
  const risk = Math.abs(entry - stopLoss);
  const target = isLong ? entry + (risk * riskReward) : entry - (risk * riskReward);
  
  return {
    sentiment,
    confidence: Math.round(confidence),
    trendStrength: Math.round(trendStrength),
    entry: Math.round(entry * 100) / 100,
    target: Math.round(target * 100) / 100,
    stopLoss: Math.round(stopLoss * 100) / 100,
  };
}

// Category helpers
export function getCategoryColor(category: AssetCategory): string {
  const colors = {
    stocks: 'text-blue-400',
    forex: 'text-emerald-400',
    crypto: 'text-amber-400',
    commodities: 'text-purple-400',
  };
  return colors[category];
}

export function getCategoryBgColor(category: AssetCategory): string {
  const colors = {
    stocks: 'bg-blue-400/10',
    forex: 'bg-emerald-400/10',
    crypto: 'bg-amber-400/10',
    commodities: 'bg-purple-400/10',
  };
  return colors[category];
}
