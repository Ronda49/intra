"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Newspaper,
  TrendingUp,
  TrendingDown,
  Minus,
  ExternalLink,
  RefreshCw,
  Clock,
  Globe,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: string;
  category: string;
  sentiment: "bullish" | "bearish" | "neutral";
  sentimentScore: number;
  relatedSymbols: string[];
  aiAnalysis?: string;
}

interface NewsFeedProps {
  symbol?: string;
  category?: "stocks" | "crypto" | "forex" | "commodities" | "all";
  compact?: boolean;
}

// Simulated news data - in production, this would come from a real news API
const generateMockNews = (symbol?: string, category?: string): NewsItem[] => {
  const baseNews: NewsItem[] = [
    {
      id: "1",
      title: "Federal Reserve Signals Potential Rate Cut in Q2 2026",
      summary:
        "Fed Chair indicates the central bank is closely monitoring inflation data and may consider rate adjustments if economic conditions warrant.",
      source: "Reuters",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      category: "macro",
      sentiment: "bullish",
      sentimentScore: 0.72,
      relatedSymbols: ["SPY", "QQQ", "DIA", "^GSPC"],
      aiAnalysis:
        "Rate cut expectations typically boost equity valuations. Tech and growth stocks may benefit most.",
    },
    {
      id: "2",
      title: "Bitcoin ETF Inflows Reach Record $2.1B This Week",
      summary:
        "Institutional demand for Bitcoin continues to surge as spot ETFs see unprecedented capital inflows.",
      source: "CoinDesk",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
      category: "crypto",
      sentiment: "bullish",
      sentimentScore: 0.85,
      relatedSymbols: ["BTCUSD", "ETHUSD", "COIN", "MSTR"],
      aiAnalysis:
        "Strong institutional buying pressure suggests continued upward momentum for major cryptocurrencies.",
    },
    {
      id: "3",
      title: "Oil Prices Dip on Surprise Inventory Build",
      summary:
        "Crude oil futures fell 2.3% after EIA reported an unexpected increase in U.S. crude stockpiles.",
      source: "Bloomberg",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
      category: "commodities",
      sentiment: "bearish",
      sentimentScore: -0.58,
      relatedSymbols: ["CL=F", "XOM", "CVX", "OXY"],
      aiAnalysis:
        "Inventory builds signal weakening demand. Energy sector may face near-term headwinds.",
    },
    {
      id: "4",
      title: "Reliance Industries Reports Strong Q4 Earnings",
      summary:
        "India's largest conglomerate beats analyst expectations with 18% YoY profit growth driven by retail and telecom segments.",
      source: "Economic Times",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      category: "stocks",
      sentiment: "bullish",
      sentimentScore: 0.78,
      relatedSymbols: ["RELIANCE.NS", "NIFTY50", "SENSEX"],
      aiAnalysis:
        "Earnings beat and diversified growth strategy support bullish outlook for Indian markets.",
    },
    {
      id: "5",
      title: "EUR/USD Weakens Amid Diverging Central Bank Policies",
      summary:
        "Euro falls to 3-month low against the dollar as ECB signals more rate cuts while Fed remains cautious.",
      source: "FXStreet",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
      category: "forex",
      sentiment: "bearish",
      sentimentScore: -0.45,
      relatedSymbols: ["EURUSD", "DXY", "GBPUSD"],
      aiAnalysis:
        "Policy divergence favors USD strength. EUR/USD may test 1.05 support level.",
    },
    {
      id: "6",
      title: "NVIDIA Unveils Next-Gen AI Chips at GTC 2026",
      summary:
        "The Blackwell Ultra architecture promises 4x performance improvement for AI training workloads.",
      source: "TechCrunch",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
      category: "stocks",
      sentiment: "bullish",
      sentimentScore: 0.92,
      relatedSymbols: ["NVDA", "AMD", "INTC", "SMH"],
      aiAnalysis:
        "Technology leadership in AI chips reinforces NVIDIA's competitive moat. Potential catalyst for semiconductor sector.",
    },
    {
      id: "7",
      title: "Gold Prices Surge to New All-Time High",
      summary:
        "Safe-haven demand and central bank buying push gold above $2,800/oz for the first time.",
      source: "Kitco",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
      category: "commodities",
      sentiment: "bullish",
      sentimentScore: 0.68,
      relatedSymbols: ["GC=F", "GLD", "NEM", "GOLD"],
      aiAnalysis:
        "Geopolitical uncertainty and inflation hedging drive gold demand. Miners may see expanded margins.",
    },
    {
      id: "8",
      title: "Japan's Nikkei 225 Hits Record High on Weak Yen",
      summary:
        "Export-heavy Japanese stocks rally as yen weakness boosts overseas earnings outlook.",
      source: "Nikkei Asia",
      url: "#",
      publishedAt: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
      category: "stocks",
      sentiment: "bullish",
      sentimentScore: 0.55,
      relatedSymbols: ["^N225", "EWJ", "USDJPY"],
      aiAnalysis:
        "Currency dynamics favor Japanese exporters. Watch for BOJ intervention risk at 160 USDJPY.",
    },
  ];

  // Filter by category if provided
  let filtered = baseNews;
  if (category && category !== "all") {
    filtered = baseNews.filter((n) => n.category === category);
  }

  // Filter by symbol if provided
  if (symbol) {
    filtered = baseNews.filter(
      (n) =>
        n.relatedSymbols.some(
          (s) =>
            s.toLowerCase().includes(symbol.toLowerCase()) ||
            symbol.toLowerCase().includes(s.toLowerCase().replace(/[.=^]/g, ""))
        ) || filtered.length === 0
    );
    // If no direct matches, return general market news
    if (filtered.length === 0) {
      filtered = baseNews.slice(0, 3);
    }
  }

  return filtered;
};

export function NewsFeed({
  symbol,
  category = "all",
  compact = false,
}: NewsFeedProps) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(category);
  const [isAnalyzing, setIsAnalyzing] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setNews(generateMockNews(symbol, selectedCategory));
      setIsLoading(false);
    }, 500);
  }, [symbol, selectedCategory]);

  const refreshNews = () => {
    setIsLoading(true);
    setTimeout(() => {
      setNews(generateMockNews(symbol, selectedCategory));
      setIsLoading(false);
    }, 500);
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "bullish":
        return <TrendingUp className="h-3.5 w-3.5" />;
      case "bearish":
        return <TrendingDown className="h-3.5 w-3.5" />;
      default:
        return <Minus className="h-3.5 w-3.5" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "bullish":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      case "bearish":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      default:
        return "bg-zinc-500/20 text-zinc-400 border-zinc-500/30";
    }
  };

  if (compact) {
    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Newspaper className="h-4 w-4 text-blue-400" />
              Latest News
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={refreshNews}
            >
              <RefreshCw
                className={cn("h-3 w-3", isLoading && "animate-spin")}
              />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <ScrollArea className="h-[200px]">
            <div className="space-y-3">
              {news.slice(0, 5).map((item) => (
                <div
                  key={item.id}
                  className="group cursor-pointer hover:bg-zinc-800/50 rounded-lg p-2 -mx-2 transition-colors"
                >
                  <div className="flex items-start gap-2">
                    <Badge
                      variant="outline"
                      className={cn(
                        "shrink-0 text-[10px] px-1.5",
                        getSentimentColor(item.sentiment)
                      )}
                    >
                      {getSentimentIcon(item.sentiment)}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-zinc-300 line-clamp-2 group-hover:text-white transition-colors">
                        {item.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-zinc-500">
                          {item.source}
                        </span>
                        <span className="text-[10px] text-zinc-600">-</span>
                        <span className="text-[10px] text-zinc-500">
                          {formatTimeAgo(item.publishedAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-zinc-900/50 border-zinc-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-400" />
            Market News & Analysis
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={refreshNews}
            className="h-8 bg-transparent"
          >
            <RefreshCw
              className={cn("h-3.5 w-3.5 mr-1.5", isLoading && "animate-spin")}
            />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!symbol && (
          <Tabs
            value={selectedCategory}
            onValueChange={(v) =>
              setSelectedCategory(
                v as "stocks" | "crypto" | "forex" | "commodities" | "all"
              )
            }
            className="mb-4"
          >
            <TabsList className="bg-zinc-800/50">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="stocks">Stocks</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
              <TabsTrigger value="forex">Forex</TabsTrigger>
              <TabsTrigger value="commodities">Commodities</TabsTrigger>
            </TabsList>
          </Tabs>
        )}

        <ScrollArea className="h-[400px]">
          <div className="space-y-4">
            {isLoading ? (
              <div className="flex items-center justify-center h-40">
                <RefreshCw className="h-6 w-6 animate-spin text-zinc-500" />
              </div>
            ) : (
              news.map((item) => (
                <div
                  key={item.id}
                  className="group bg-zinc-800/30 hover:bg-zinc-800/50 rounded-xl p-4 transition-all border border-zinc-800 hover:border-zinc-700"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            getSentimentColor(item.sentiment)
                          )}
                        >
                          {getSentimentIcon(item.sentiment)}
                          <span className="ml-1 capitalize">
                            {item.sentiment}
                          </span>
                        </Badge>
                        <Badge
                          variant="outline"
                          className="text-xs bg-zinc-800/50 text-zinc-400 border-zinc-700"
                        >
                          {item.category}
                        </Badge>
                      </div>
                      <h3 className="text-sm font-medium text-white group-hover:text-blue-400 transition-colors line-clamp-2 mb-2">
                        {item.title}
                      </h3>
                      <p className="text-xs text-zinc-400 line-clamp-2 mb-3">
                        {item.summary}
                      </p>

                      {item.aiAnalysis && (
                        <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-lg p-3 mb-3">
                          <div className="flex items-center gap-1.5 mb-1.5">
                            <Sparkles className="h-3 w-3 text-blue-400" />
                            <span className="text-[10px] font-medium text-blue-400 uppercase tracking-wider">
                              AI Analysis
                            </span>
                          </div>
                          <p className="text-xs text-zinc-300">
                            {item.aiAnalysis}
                          </p>
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-[10px] text-zinc-500">
                          <span className="font-medium">{item.source}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatTimeAgo(item.publishedAt)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {item.relatedSymbols.slice(0, 3).map((sym) => (
                            <Badge
                              key={sym}
                              variant="outline"
                              className="text-[10px] bg-zinc-900/50 text-zinc-400 border-zinc-700 px-1.5"
                            >
                              {sym}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
