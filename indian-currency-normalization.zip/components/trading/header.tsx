'use client';

import { Activity, Cpu, TrendingUp, Zap } from 'lucide-react';
import Link from 'next/link';

interface HeaderProps {
  showApiStatus?: boolean;
  finnhubConnected?: boolean;
  binanceConnected?: boolean;
  apiConnected?: boolean;
}

export function Header({ showApiStatus = false, finnhubConnected = false, binanceConnected = false, apiConnected = false }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center justify-between px-4 lg:px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded bg-primary">
            <Cpu className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight">AlphaPredict</span>
            <span className="text-[10px] text-muted-foreground">Indian Markets • ₹</span>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          <Link 
            href="/" 
            className="flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <TrendingUp className="h-3.5 w-3.5" />
            Heatmap
          </Link>
          <Link 
            href="/asset/BTCUSDT" 
            className="flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <Activity className="h-3.5 w-3.5" />
            Terminal
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {showApiStatus && (
            <div className="hidden items-center gap-3 text-[10px] md:flex">
              <div className="flex items-center gap-1.5">
                <span className={`h-1.5 w-1.5 rounded-full ${finnhubConnected ? 'bg-bullish animate-pulse' : 'bg-muted-foreground'}`} />
                <span className="text-muted-foreground">Finnhub</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`h-1.5 w-1.5 rounded-full ${binanceConnected || apiConnected ? 'bg-bullish animate-pulse' : 'bg-muted-foreground'}`} />
                <span className="text-muted-foreground">Binance</span>
              </div>
            </div>
          )}
          
          <div className="flex items-center gap-1.5 rounded border border-border bg-card px-2 py-1">
            <Zap className="h-3 w-3 text-warning" />
            <span className="text-[10px] text-muted-foreground">AI Active</span>
          </div>
        </div>
      </div>
    </header>
  );
}
