'use client';

import { Activity, TrendingDown, TrendingUp, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatsCardsProps {
  totalAssets: number;
  bullishCount: number;
  bearishCount: number;
  avgVolatility: number;
}

export function StatsCards({ totalAssets, bullishCount, bearishCount, avgVolatility }: StatsCardsProps) {
  const stats = [
    {
      label: 'Tracking',
      value: totalAssets.toString(),
      icon: <Activity className="h-4 w-4" />,
      color: 'text-foreground',
      bg: 'bg-foreground/5',
    },
    {
      label: 'Bullish',
      value: bullishCount.toString(),
      icon: <TrendingUp className="h-4 w-4" />,
      color: 'text-bullish',
      bg: 'bg-bullish/10',
    },
    {
      label: 'Bearish',
      value: bearishCount.toString(),
      icon: <TrendingDown className="h-4 w-4" />,
      color: 'text-bearish',
      bg: 'bg-bearish/10',
    },
    {
      label: 'Avg Vol',
      value: `${avgVolatility.toFixed(1)}%`,
      icon: <Zap className="h-4 w-4" />,
      color: 'text-warning',
      bg: 'bg-warning/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="flex items-center gap-3 rounded border border-border bg-card p-3"
        >
          <div className={cn('flex h-9 w-9 items-center justify-center rounded', stat.bg, stat.color)}>
            {stat.icon}
          </div>
          <div>
            <p className="text-lg font-bold tabular-nums">{stat.value}</p>
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
