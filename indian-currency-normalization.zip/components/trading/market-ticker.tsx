'use client';

import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import type { MarketTicker as MarketTickerType } from '@/lib/trading-types';

interface MarketTickerProps {
  tickers: MarketTickerType[];
}

export function MarketTicker({ tickers }: MarketTickerProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    let animationId: number;
    let scrollPosition = 0;

    const scroll = () => {
      if (!isPaused) {
        scrollPosition += 0.5;
        if (scrollPosition >= scrollContainer.scrollWidth / 2) {
          scrollPosition = 0;
        }
        scrollContainer.scrollLeft = scrollPosition;
      }
      animationId = requestAnimationFrame(scroll);
    };

    animationId = requestAnimationFrame(scroll);
    return () => cancelAnimationFrame(animationId);
  }, [isPaused]);

  const duplicatedTickers = [...tickers, ...tickers];

  return (
    <div 
      className="border-b border-border bg-card/50"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div
        ref={scrollRef}
        className="flex overflow-hidden py-1.5"
        style={{ scrollBehavior: 'auto' }}
      >
        <div className="flex min-w-max gap-6 px-4">
          {duplicatedTickers.map((ticker, index) => (
            <div
              key={`${ticker.symbol}-${index}`}
              className="flex items-center gap-2 text-xs"
            >
              <span className="font-medium text-foreground">{ticker.symbol}</span>
              <span className="tabular-nums text-muted-foreground">
                ₹{parseFloat(ticker.price).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span
                className={cn(
                  'tabular-nums',
                  parseFloat(ticker.changePercent) >= 0 ? 'text-bullish' : 'text-bearish'
                )}
              >
                {parseFloat(ticker.changePercent) >= 0 ? '+' : ''}
                {parseFloat(ticker.changePercent).toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
