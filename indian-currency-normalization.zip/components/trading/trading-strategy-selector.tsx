'use client';

import { TRADING_STYLES, type TradingStyleInfo } from '@/lib/data/asset-database';
import { TradingStyleType } from '@/lib/trading-types'; // Declare TradingStyleType here
import { cn } from '@/lib/utils';
import { TrendingUp, Zap, BarChart3, Timer, Landmark, AlertTriangle, Clock, Target } from 'lucide-react';

interface TradingStrategySelectorProps {
  selected: TradingStyleType;
  onChange: (style: TradingStyleType) => void;
  assetCategory?: string;
}

const styleIcons: Record<TradingStyleType, typeof TrendingUp> = {
  fo: Landmark,
  intraday: Timer,
  swing: TrendingUp,
  scalping: Zap,
  longterm: Target,
};

const riskColors: Record<TradingStyleInfo['riskLevel'], string> = {
  low: 'text-bullish bg-bullish/10',
  medium: 'text-amber-400 bg-amber-400/10',
  high: 'text-orange-400 bg-orange-400/10',
  very_high: 'text-bearish bg-bearish/10',
};

export function TradingStrategySelector({ selected, onChange, assetCategory }: TradingStrategySelectorProps) {
  // Filter F&O for stocks only
  const availableStyles = TRADING_STYLES.filter(style => {
    if (style.id === 'fo' && assetCategory !== 'stocks') {
      return false;
    }
    return true;
  });

  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="border-b border-border p-4">
        <h3 className="flex items-center gap-2 text-sm font-semibold">
          <BarChart3 className="h-4 w-4 text-primary" />
          Trading Strategy
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Select your trading style for customized analysis
        </p>
      </div>
      
      <div className="p-2">
        {availableStyles.map(style => {
          const Icon = styleIcons[style.id];
          const isSelected = selected === style.id;
          
          return (
            <button
              key={style.id}
              type="button"
              onClick={() => onChange(style.id)}
              className={cn(
                'w-full rounded-lg p-3 text-left transition-all',
                isSelected 
                  ? 'bg-primary/10 border border-primary/50' 
                  : 'hover:bg-accent border border-transparent'
              )}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg',
                  isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted'
                )}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{style.name}</span>
                    <span className={cn(
                      'rounded px-1.5 py-0.5 text-[10px] font-medium',
                      riskColors[style.riskLevel]
                    )}>
                      {style.riskLevel.replace('_', ' ')} risk
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">
                    {style.description}
                  </p>
                  <div className="mt-2 flex items-center gap-3 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {style.holdingPeriod}
                    </span>
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// Compact version for sidebar
export function TradingStrategyTabs({ selected, onChange, assetCategory }: TradingStrategySelectorProps) {
  const availableStyles = TRADING_STYLES.filter(style => {
    if (style.id === 'fo' && assetCategory !== 'stocks') {
      return false;
    }
    return true;
  });

  return (
    <div className="flex flex-wrap gap-2">
      {availableStyles.map(style => {
        const Icon = styleIcons[style.id];
        const isSelected = selected === style.id;
        
        return (
          <button
            key={style.id}
            type="button"
            onClick={() => onChange(style.id)}
            className={cn(
              'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-colors',
              isSelected 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-muted text-muted-foreground hover:bg-accent hover:text-foreground'
            )}
          >
            <Icon className="h-3 w-3" />
            {style.id === 'fo' ? 'F&O' : style.id === 'longterm' ? 'Long-term' : style.id.charAt(0).toUpperCase() + style.id.slice(1)}
          </button>
        );
      })}
    </div>
  );
}
