'use client';

import React from "react"

import { useState, useCallback, useRef, useEffect } from 'react';
import { Search, X, TrendingUp, Coins, DollarSign, Gem, ChevronRight, Type as type, LucideIcon } from 'lucide-react';
import { searchAssets, type UnifiedAsset } from '@/lib/data/asset-database';
import type { AssetCategory } from '@/lib/trading-types';
import { cn } from '@/lib/utils';
import Link from 'next/link';

interface SearchBarProps {
  onSelect?: (asset: UnifiedAsset) => void;
  placeholder?: string;
  className?: string;
}

const categoryIcons: Record<AssetCategory, LucideIcon> = {
  stocks: TrendingUp,
  crypto: Coins,
  forex: DollarSign,
  commodities: Gem,
};

const categoryColors: Record<AssetCategory, string> = {
  stocks: 'text-blue-400 bg-blue-400/10',
  crypto: 'text-amber-400 bg-amber-400/10',
  forex: 'text-emerald-400 bg-emerald-400/10',
  commodities: 'text-purple-400 bg-purple-400/10',
};

export function SearchBar({ onSelect, placeholder = 'Search stocks, crypto, forex, commodities...', className }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UnifiedAsset[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleSearch = useCallback((searchQuery: string) => {
    setQuery(searchQuery);
    if (searchQuery.trim().length > 0) {
      const searchResults = searchAssets(searchQuery, undefined, 15);
      setResults(searchResults);
      setIsOpen(true);
      setSelectedIndex(-1);
    } else {
      setResults([]);
      setIsOpen(false);
    }
  }, []);

  const handleSelect = useCallback((asset: UnifiedAsset) => {
    setQuery('');
    setResults([]);
    setIsOpen(false);
    onSelect?.(asset);
  }, [onSelect]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => (prev < results.length - 1 ? prev + 1 : 0));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => (prev > 0 ? prev - 1 : results.length - 1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0) {
          handleSelect(results[selectedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setSelectedIndex(-1);
        break;
    }
  }, [isOpen, results, selectedIndex, handleSelect]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className={cn('relative', className)}>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => query.trim() && setIsOpen(true)}
          placeholder={placeholder}
          className="h-10 w-full rounded-lg border border-border bg-card pl-10 pr-10 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setResults([]);
              setIsOpen(false);
              inputRef.current?.focus();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {isOpen && results.length > 0 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 max-h-96 overflow-y-auto rounded-lg border border-border bg-card shadow-lg">
          {results.map((asset, index) => {
            const Icon = categoryIcons[asset.category];
            return (
              <Link
                key={asset.id}
                href={`/asset/${asset.tradingSymbol}`}
                onClick={() => handleSelect(asset)}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 transition-colors hover:bg-accent',
                  selectedIndex === index && 'bg-accent'
                )}
              >
                <div className={cn('flex h-8 w-8 items-center justify-center rounded', categoryColors[asset.category])}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{asset.symbol}</span>
                    <span className={cn('rounded px-1.5 py-0.5 text-[10px] uppercase', categoryColors[asset.category])}>
                      {asset.category}
                    </span>
                  </div>
                  <p className="truncate text-xs text-muted-foreground">{asset.name}</p>
                </div>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
              </Link>
            );
          })}
        </div>
      )}

      {isOpen && query.trim() && results.length === 0 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 rounded-lg border border-border bg-card p-4 text-center text-sm text-muted-foreground shadow-lg">
          No results found for "{query}"
        </div>
      )}
    </div>
  );
}
