'use client';

import { useMemo } from 'react';
import type { CandleData, TradingStyle } from '@/lib/trading-types';
import { performTechnicalAnalysis } from '@/lib/technical-analysis';
import { cn } from '@/lib/utils';
import { 
  TrendingUp, TrendingDown, Activity, BarChart2, Gauge, Layers, 
  Volume2, ArrowUpRight, ArrowDownRight, AlertTriangle
} from 'lucide-react';

interface TechnicalAnalysisPanelProps {
  candles: CandleData[];
  currentPrice: number;
  tradingStyle: TradingStyle;
}

export function TechnicalAnalysisPanel({ candles, currentPrice, tradingStyle }: TechnicalAnalysisPanelProps) {
  const analysis = useMemo(() => performTechnicalAnalysis(candles), [candles]);
  
  const { rsi, macd, bollingerBands, movingAverages, stochastic, atr, supportResistance, volumeAnalysis, signals } = analysis;

  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border p-4">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold">Technical Indicators</h3>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          Real-time analysis based on price action and volume
        </p>
      </div>

      <div className="p-4 space-y-4">
        {/* Technical Indicators Grid */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {/* RSI */}
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Gauge className="h-3 w-3" />
              RSI (14)
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{rsi.value}</span>
              <span className={cn(
                'text-xs',
                rsi.signal === 'oversold' ? 'text-bullish' :
                rsi.signal === 'overbought' ? 'text-bearish' : 'text-muted-foreground'
              )}>
                {rsi.signal}
              </span>
            </div>
            <div className="mt-1.5 h-1.5 w-full rounded-full bg-muted overflow-hidden">
              <div 
                className={cn(
                  'h-full transition-all',
                  rsi.value > 70 ? 'bg-bearish' : rsi.value < 30 ? 'bg-bullish' : 'bg-amber-400'
                )}
                style={{ width: `${rsi.value}%` }}
              />
            </div>
          </div>

          {/* MACD */}
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Activity className="h-3 w-3" />
              MACD
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{macd.histogram > 0 ? '+' : ''}{macd.histogram.toFixed(4)}</span>
            </div>
            <div className={cn(
              'mt-1 inline-block rounded px-1.5 py-0.5 text-[10px] font-medium',
              macd.trend === 'bullish' ? 'text-bullish bg-bullish/10' : 
              macd.trend === 'bearish' ? 'text-bearish bg-bearish/10' : 'text-muted-foreground bg-muted'
            )}>
              {macd.crossover !== 'none' ? (
                macd.crossover === 'bullish_cross' ? 'Bullish Cross' : 'Bearish Cross'
              ) : macd.trend}
            </div>
          </div>

          {/* Bollinger Bands */}
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Layers className="h-3 w-3" />
              Bollinger
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{bollingerBands.percentB.toFixed(0)}%</span>
              <span className={cn(
                'text-xs',
                bollingerBands.signal === 'oversold' ? 'text-bullish' :
                bollingerBands.signal === 'overbought' ? 'text-bearish' :
                bollingerBands.signal === 'squeeze' ? 'text-amber-400' : 'text-muted-foreground'
              )}>
                {bollingerBands.signal}
              </span>
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">
              Width: {bollingerBands.bandwidth.toFixed(2)}%
            </div>
          </div>

          {/* Stochastic */}
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <BarChart2 className="h-3 w-3" />
              Stochastic
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{stochastic.k.toFixed(0)}</span>
              <span className={cn(
                'text-xs',
                stochastic.signal === 'oversold' ? 'text-bullish' :
                stochastic.signal === 'overbought' ? 'text-bearish' : 'text-muted-foreground'
              )}>
                {stochastic.signal}
              </span>
            </div>
            <div className="mt-1 text-[10px] text-muted-foreground">
              %D: {stochastic.d.toFixed(1)}
            </div>
          </div>
        </div>

        {/* Moving Averages */}
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3" />
              Moving Averages
            </div>
            <span className={cn(
              'rounded px-1.5 py-0.5 text-[10px] font-medium',
              movingAverages.trend.includes('bullish') ? 'text-bullish bg-bullish/10' :
              movingAverages.trend.includes('bearish') ? 'text-bearish bg-bearish/10' : 'text-amber-400 bg-amber-400/10'
            )}>
              {movingAverages.trend.replace('_', ' ')}
            </span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">SMA 20</span>
              <span className={cn(
                'font-mono',
                currentPrice > movingAverages.sma20 ? 'text-bullish' : 'text-bearish'
              )}>
                ₹{movingAverages.sma20.toLocaleString('en-IN')}
                {currentPrice > movingAverages.sma20 ? <ArrowUpRight className="inline h-3 w-3" /> : <ArrowDownRight className="inline h-3 w-3" />}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">SMA 50</span>
              <span className={cn(
                'font-mono',
                currentPrice > movingAverages.sma50 ? 'text-bullish' : 'text-bearish'
              )}>
                ₹{movingAverages.sma50.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">SMA 200</span>
              <span className={cn(
                'font-mono',
                currentPrice > movingAverages.sma200 ? 'text-bullish' : 'text-bearish'
              )}>
                ₹{movingAverages.sma200.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
          
          {(movingAverages.goldenCross || movingAverages.deathCross) && (
            <div className={cn(
              'mt-2 rounded p-2 text-center text-xs font-medium',
              movingAverages.goldenCross ? 'bg-bullish/10 text-bullish' : 'bg-bearish/10 text-bearish'
            )}>
              {movingAverages.goldenCross ? 'Golden Cross Detected' : 'Death Cross Detected'}
            </div>
          )}
        </div>

        {/* Support & Resistance */}
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
            <Layers className="h-3 w-3" />
            Support & Resistance (Pivot)
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <p className="mb-1 text-[10px] font-medium text-bearish">Resistance</p>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">R3</span>
                  <span className="font-mono text-bearish">₹{supportResistance.r3.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">R2</span>
                  <span className="font-mono text-bearish">₹{supportResistance.r2.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">R1</span>
                  <span className="font-mono text-bearish">₹{supportResistance.r1.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
            <div>
              <p className="mb-1 text-[10px] font-medium text-bullish">Support</p>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">S1</span>
                  <span className="font-mono text-bullish">₹{supportResistance.s1.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">S2</span>
                  <span className="font-mono text-bullish">₹{supportResistance.s2.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">S3</span>
                  <span className="font-mono text-bullish">₹{supportResistance.s3.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-2 flex items-center justify-between rounded bg-card p-2 text-xs">
            <span className="text-muted-foreground">Pivot Point</span>
            <span className="font-mono font-medium">₹{supportResistance.pivotPoint.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Volatility & Volume */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <AlertTriangle className="h-3 w-3" />
              ATR (Volatility)
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{atr.value.toFixed(4)}</span>
            </div>
            <div className={cn(
              'mt-1 inline-block rounded px-1.5 py-0.5 text-[10px] font-medium',
              atr.volatilityLevel === 'low' ? 'bg-bullish/10 text-bullish' :
              atr.volatilityLevel === 'medium' ? 'bg-amber-400/10 text-amber-400' :
              atr.volatilityLevel === 'high' ? 'bg-orange-400/10 text-orange-400' : 'bg-bearish/10 text-bearish'
            )}>
              {atr.volatilityLevel} ({atr.percentATR.toFixed(2)}%)
            </div>
          </div>

          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Volume2 className="h-3 w-3" />
              Volume
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-lg font-bold">{volumeAnalysis.volumeRatio.toFixed(2)}x</span>
            </div>
            <div className={cn(
              'mt-1 inline-block rounded px-1.5 py-0.5 text-[10px] font-medium',
              volumeAnalysis.trend === 'accumulation' ? 'bg-bullish/10 text-bullish' :
              volumeAnalysis.trend === 'distribution' ? 'bg-bearish/10 text-bearish' : 'bg-muted text-muted-foreground'
            )}>
              {volumeAnalysis.trend}
            </div>
          </div>
        </div>

        {/* Signal Summary */}
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
            <Activity className="h-3 w-3" />
            Signal Summary
          </div>
          
          <div className="flex flex-wrap gap-2">
            {signals.map((signal, i) => (
              <div 
                key={i} 
                className={cn(
                  'flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-medium',
                  signal.signal === 'buy' ? 'bg-bullish/10 text-bullish' :
                  signal.signal === 'sell' ? 'bg-bearish/10 text-bearish' : 'bg-muted text-muted-foreground'
                )}
              >
                {signal.signal === 'buy' ? <ArrowUpRight className="h-3 w-3" /> : 
                 signal.signal === 'sell' ? <ArrowDownRight className="h-3 w-3" /> : null}
                {signal.indicator}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
