'use client';

import { useEffect, useState, useRef } from 'react';
import { cn } from '@/lib/utils';

interface Trade {
  id: string;
  price: number;
  quantity: number;
  time: string;
  isBuyer: boolean;
}

interface TradesFeedProps {
  symbol: string;
}

export function TradesFeed({ symbol }: TradesFeedProps) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Only connect for crypto symbols
    if (!symbol.includes('USDT')) {
      // Generate mock trades for non-crypto
      const mockTrades: Trade[] = [];
      for (let i = 0; i < 20; i++) {
        mockTrades.push({
          id: `mock-${i}`,
          price: 100 + Math.random() * 10,
          quantity: Math.random() * 5,
          time: new Date(Date.now() - i * 1000).toLocaleTimeString(),
          isBuyer: Math.random() > 0.5,
        });
      }
      setTrades(mockTrades);
      return;
    }

    const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@trade`);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      const newTrade: Trade = {
        id: data.t.toString(),
        price: parseFloat(data.p),
        quantity: parseFloat(data.q),
        time: new Date(data.T).toLocaleTimeString(),
        isBuyer: data.m === false, // m is true for maker (sell), false for taker (buy)
      };

      setTrades(prev => [newTrade, ...prev.slice(0, 49)]);
    };

    ws.onerror = () => {
      setIsConnected(false);
    };

    ws.onclose = () => {
      setIsConnected(false);
    };

    return () => {
      ws.close();
    };
  }, [symbol]);

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-xs font-semibold">Recent Trades</h3>
        <div className="flex items-center gap-1.5">
          <span className={cn(
            'h-1.5 w-1.5 rounded-full',
            isConnected ? 'bg-bullish animate-pulse' : 'bg-muted-foreground'
          )} />
          <span className="text-[9px] text-muted-foreground">
            {isConnected ? 'Live' : 'Offline'}
          </span>
        </div>
      </div>

      {/* Headers */}
      <div className="mb-2 grid grid-cols-3 text-[9px] text-muted-foreground">
        <span>Price</span>
        <span className="text-right">Amount</span>
        <span className="text-right">Time</span>
      </div>

      {/* Trades list */}
      <div className="max-h-[300px] space-y-0.5 overflow-y-auto">
        {trades.map((trade) => (
          <div
            key={trade.id}
            className="grid grid-cols-3 text-[10px] transition-colors hover:bg-muted/30"
          >
            <span className={cn(
              'tabular-nums',
              trade.isBuyer ? 'text-bullish' : 'text-bearish'
            )}>
              ₹{trade.price.toFixed(2)}
            </span>
            <span className="text-right tabular-nums text-muted-foreground">
              {trade.quantity.toFixed(4)}
            </span>
            <span className="text-right tabular-nums text-muted-foreground">
              {trade.time}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
