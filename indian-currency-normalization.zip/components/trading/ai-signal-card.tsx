'use client';

import { Activity, ArrowDownRight, ArrowUpRight, Minus, Shield, Target, TrendingDown, TrendingUp, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatINR } from '@/lib/currency';
import type { AISignal, Sentiment, TradingStyle } from '@/lib/trading-types';

interface AISignalCardProps {
  signal: AISignal;
  currentPrice: number;
  className?: string;
}

function getSentimentColor(sentiment: Sentiment): string {
  switch (sentiment) {
    case 'bullish':
      return 'text-bullish';
    case 'bearish':
      return 'text-bearish';
    default:
      return 'text-muted-foreground';
  }
}

function getSentimentBg(sentiment: Sentiment): string {
  switch (sentiment) {
    case 'bullish':
      return 'bg-bullish/10 border-bullish/20';
    case 'bearish':
      return 'bg-bearish/10 border-bearish/20';
    default:
      return 'bg-muted/50 border-border';
  }
}

function getTradingStyleLabel(style: TradingStyle): string {
  switch (style) {
    case 'scalping':
      return 'SCALP';
    case 'intraday':
      return 'INTRA';
    case 'swing':
      return 'SWING';
  }
}

function getTradingStyleColor(style: TradingStyle): string {
  switch (style) {
    case 'scalping':
      return 'text-amber-400 bg-amber-400/10';
    case 'intraday':
      return 'text-blue-400 bg-blue-400/10';
    case 'swing':
      return 'text-purple-400 bg-purple-400/10';
  }
}

export function AISignalCard({ signal, currentPrice, className }: AISignalCardProps) {
  const riskReward = Math.abs((signal.target - signal.entry) / (signal.entry - signal.stopLoss)).toFixed(2);
  const potentialProfit = ((Math.abs(signal.target - signal.entry) / signal.entry) * 100).toFixed(2);
  const potentialLoss = ((Math.abs(signal.entry - signal.stopLoss) / signal.entry) * 100).toFixed(2);

  return (
    <div className={cn('rounded-lg border border-border bg-card p-4', className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded bg-primary/10">
            <Zap className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h3 className="text-xs font-semibold">AI Signal</h3>
            <p className="text-[10px] text-muted-foreground">XGBoost + LSTM Hybrid</p>
          </div>
        </div>
        <span className={cn('rounded px-2 py-0.5 text-[10px] font-medium', getTradingStyleColor(signal.tradingStyle))}>
          {getTradingStyleLabel(signal.tradingStyle)}
        </span>
      </div>

      {/* Sentiment Badge */}
      <div className={cn('mt-4 flex items-center justify-between rounded border p-3', getSentimentBg(signal.sentiment))}>
        <div className="flex items-center gap-2">
          {signal.sentiment === 'bullish' ? (
            <TrendingUp className={cn('h-5 w-5', getSentimentColor(signal.sentiment))} />
          ) : signal.sentiment === 'bearish' ? (
            <TrendingDown className={cn('h-5 w-5', getSentimentColor(signal.sentiment))} />
          ) : (
            <Minus className={cn('h-5 w-5', getSentimentColor(signal.sentiment))} />
          )}
          <span className={cn('text-sm font-bold uppercase', getSentimentColor(signal.sentiment))}>
            {signal.sentiment}
          </span>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold">{signal.confidence}%</div>
          <div className="text-[10px] text-muted-foreground">Confidence</div>
        </div>
      </div>

      {/* Trend Strength */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Trend Strength</span>
          <span className="font-medium">{signal.trendStrength}%</span>
        </div>
        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
          <div
            className={cn('h-full transition-all', signal.sentiment === 'bullish' ? 'bg-bullish' : signal.sentiment === 'bearish' ? 'bg-bearish' : 'bg-muted-foreground')}
            style={{ width: `${signal.trendStrength}%` }}
          />
        </div>
      </div>

      {/* Price Levels */}
      <div className="mt-4 space-y-2">
        <div className="flex items-center justify-between rounded border border-border bg-background/50 p-2">
          <div className="flex items-center gap-1.5">
            <ArrowUpRight className="h-3 w-3 text-muted-foreground" />
            <span className="text-[10px] text-muted-foreground">Entry</span>
          </div>
          <span className="text-xs font-medium tabular-nums">{formatINR(signal.entry)}</span>
        </div>
        
        <div className="flex items-center justify-between rounded border border-bullish/20 bg-bullish/5 p-2">
          <div className="flex items-center gap-1.5">
            <Target className="h-3 w-3 text-bullish" />
            <span className="text-[10px] text-bullish">Target</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-bullish">+{potentialProfit}%</span>
            <span className="text-xs font-medium tabular-nums text-bullish">{formatINR(signal.target)}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between rounded border border-bearish/20 bg-bearish/5 p-2">
          <div className="flex items-center gap-1.5">
            <Shield className="h-3 w-3 text-bearish" />
            <span className="text-[10px] text-bearish">Stop Loss</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-bearish">-{potentialLoss}%</span>
            <span className="text-xs font-medium tabular-nums text-bearish">{formatINR(signal.stopLoss)}</span>
          </div>
        </div>
      </div>

      {/* Risk/Reward */}
      <div className="mt-4 flex items-center justify-between rounded bg-muted/50 p-2">
        <div className="flex items-center gap-1.5">
          <Activity className="h-3 w-3 text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">Risk/Reward</span>
        </div>
        <span className="text-xs font-bold text-primary">1:{riskReward}</span>
      </div>

      {/* ATR Info */}
      <div className="mt-3 text-center text-[9px] text-muted-foreground">
        ATR-based Dynamic SL · 2x ATR Multiplier
      </div>
    </div>
  );
}
