'use client';

import React from "react"

import { cn } from '@/lib/utils';
import type { AssetCategory } from '@/lib/trading-types';
import { BarChart3, Bitcoin, DollarSign, Gem, Layers } from 'lucide-react';

interface CategoryFilterProps {
  selected: AssetCategory | 'all';
  onChange: (category: AssetCategory | 'all') => void;
}

const categories: { id: AssetCategory | 'all'; label: string; icon: React.ReactNode }[] = [
  { id: 'all', label: 'All', icon: <Layers className="h-3 w-3" /> },
  { id: 'stocks', label: 'Stocks', icon: <BarChart3 className="h-3 w-3" /> },
  { id: 'forex', label: 'Forex', icon: <DollarSign className="h-3 w-3" /> },
  { id: 'crypto', label: 'Crypto', icon: <Bitcoin className="h-3 w-3" /> },
  { id: 'commodities', label: 'Commodities', icon: <Gem className="h-3 w-3" /> },
];

export function CategoryFilter({ selected, onChange }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onChange(category.id)}
          className={cn(
            'flex items-center gap-1.5 rounded border px-3 py-1.5 text-xs font-medium transition-all',
            selected === category.id
              ? 'border-primary bg-primary/10 text-primary'
              : 'border-border bg-card text-muted-foreground hover:border-foreground/20 hover:text-foreground'
          )}
        >
          {category.icon}
          {category.label}
        </button>
      ))}
    </div>
  );
}
