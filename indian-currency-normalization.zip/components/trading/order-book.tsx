'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

interface OrderBookEntry {
  price: number;
  quantity: number;
  total: number;
}

interface OrderBookProps {
  symbol: string;
  currentPrice: number;
}

export function OrderBook({ symbol, currentPrice }: OrderBookProps) {
  const [bids, setBids] = useState<OrderBookEntry[]>([]);
  const [asks, setAsks] = useState<OrderBookEntry[]>([]);
  const [spread, setSpread] = useState(0);

  useEffect(() => {
    async function fetchOrderBook() {
      // Check if it's a crypto symbol
      if (symbol.includes('USDT')) {
        try {
          const response = await fetch(
            `https://api.binance.com/api/v3/depth?symbol=${symbol}&limit=10`
          );
          const data = await response.json();
          
          const newBids: OrderBookEntry[] = data.bids.map((bid: string[], i: number, arr: string[][]) => {
            const price = parseFloat(bid[0]);
            const quantity = parseFloat(bid[1]);
            const prevTotal = i > 0 ? parseFloat(arr[i-1][1]) : 0;
            return { price, quantity, total: quantity + prevTotal };
          });

          const newAsks: OrderBookEntry[] = data.asks.map((ask: string[], i: number, arr: string[][]) => {
            const price = parseFloat(ask[0]);
            const quantity = parseFloat(ask[1]);
            const prevTotal = i > 0 ? parseFloat(arr[i-1][1]) : 0;
            return { price, quantity, total: quantity + prevTotal };
          });

          setBids(newBids);
          setAsks(newAsks.reverse());
          
          if (newAsks.length > 0 && newBids.length > 0) {
            const lowestAsk = parseFloat(data.asks[0][0]);
            const highestBid = parseFloat(data.bids[0][0]);
            setSpread(((lowestAsk - highestBid) / lowestAsk) * 100);
          }
        } catch (error) {
          console.error('Error fetching order book:', error);
          generateMockData();
        }
      } else {
        generateMockData();
      }
    }

    function generateMockData() {
      const mockBids: OrderBookEntry[] = [];
      const mockAsks: OrderBookEntry[] = [];
      let bidTotal = 0;
      let askTotal = 0;

      for (let i = 0; i < 8; i++) {
        const bidPrice = currentPrice * (1 - 0.001 * (i + 1));
        const askPrice = currentPrice * (1 + 0.001 * (i + 1));
        const bidQty = Math.random() * 10;
        const askQty = Math.random() * 10;
        bidTotal += bidQty;
        askTotal += askQty;

        mockBids.push({ price: bidPrice, quantity: bidQty, total: bidTotal });
        mockAsks.unshift({ price: askPrice, quantity: askQty, total: askTotal });
      }

      setBids(mockBids);
      setAsks(mockAsks);
      setSpread(0.1);
    }

    fetchOrderBook();
    const interval = setInterval(fetchOrderBook, 2000);
    return () => clearInterval(interval);
  }, [symbol, currentPrice]);

  const maxTotal = Math.max(
    ...bids.map(b => b.total),
    ...asks.map(a => a.total)
  );

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-xs font-semibold">Order Book</h3>
        <span className="text-[10px] text-muted-foreground">
          Spread: {spread.toFixed(3)}%
        </span>
      </div>

      {/* Headers */}
      <div className="mb-2 grid grid-cols-3 text-[9px] text-muted-foreground">
        <span>Price</span>
        <span className="text-right">Amount</span>
        <span className="text-right">Total</span>
      </div>

      {/* Asks (Sell orders) */}
      <div className="space-y-0.5">
        {asks.map((ask, i) => (
          <div key={`ask-${i}`} className="relative grid grid-cols-3 text-[10px]">
            <div
              className="absolute inset-0 bg-bearish/10"
              style={{ width: `${(ask.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
            />
            <span className="relative z-10 text-bearish tabular-nums">
              {ask.price.toFixed(2)}
            </span>
            <span className="relative z-10 text-right tabular-nums text-muted-foreground">
              {ask.quantity.toFixed(4)}
            </span>
            <span className="relative z-10 text-right tabular-nums text-muted-foreground">
              {ask.total.toFixed(4)}
            </span>
          </div>
        ))}
      </div>

      {/* Current Price */}
      <div className="my-2 flex items-center justify-center rounded bg-muted/50 py-1">
        <span className="text-sm font-bold tabular-nums">
          ₹{currentPrice.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
      </div>

      {/* Bids (Buy orders) */}
      <div className="space-y-0.5">
        {bids.map((bid, i) => (
          <div key={`bid-${i}`} className="relative grid grid-cols-3 text-[10px]">
            <div
              className="absolute inset-0 bg-bullish/10"
              style={{ width: `${(bid.total / maxTotal) * 100}%`, right: 0, left: 'auto' }}
            />
            <span className="relative z-10 text-bullish tabular-nums">
              {bid.price.toFixed(2)}
            </span>
            <span className="relative z-10 text-right tabular-nums text-muted-foreground">
              {bid.quantity.toFixed(4)}
            </span>
            <span className="relative z-10 text-right tabular-nums text-muted-foreground">
              {bid.total.toFixed(4)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
