'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowDown, ArrowUp, Minus, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { HeatmapItem, AssetCategory } from '@/lib/trading-types';
import { getCategoryColor } from '@/lib/api-client';

interface HeatmapProps {
  items: HeatmapItem[];
  onItemClick?: (item: HeatmapItem) => void;
}

function getVolatilityColor(change: number): string {
  const absChange = Math.abs(change);
  
  if (change > 0) {
    if (absChange >= 5) return 'bg-emerald-500/40 hover:bg-emerald-500/50';
    if (absChange >= 3) return 'bg-emerald-500/30 hover:bg-emerald-500/40';
    if (absChange >= 1) return 'bg-emerald-500/20 hover:bg-emerald-500/30';
    return 'bg-emerald-500/10 hover:bg-emerald-500/20';
  } else if (change < 0) {
    if (absChange >= 5) return 'bg-red-500/40 hover:bg-red-500/50';
    if (absChange >= 3) return 'bg-red-500/30 hover:bg-red-500/40';
    if (absChange >= 1) return 'bg-red-500/20 hover:bg-red-500/30';
    return 'bg-red-500/10 hover:bg-red-500/20';
  }
  
  return 'bg-muted/50 hover:bg-muted/70';
}

function getTextColor(change: number): string {
  if (change > 0) return 'text-bullish';
  if (change < 0) return 'text-bearish';
  return 'text-muted-foreground';
}

function getCategoryLabel(category: AssetCategory): string {
  const labels = {
    stocks: 'STK',
    forex: 'FX',
    crypto: 'CRY',
    commodities: 'CMD',
  };
  return labels[category];
}

export function Heatmap({ items, onItemClick }: HeatmapProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-5">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="h-28 animate-pulse rounded border border-border bg-card"
          />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-5">
      {items.map((item, index) => (
        <Link
          key={item.symbol}
          href={`/asset/${item.symbol}`}
          className={cn(
            'group relative flex flex-col justify-between rounded border border-border p-3 transition-all duration-200',
            getVolatilityColor(item.change),
            'hover:border-foreground/20 hover:shadow-lg'
          )}
          style={{
            animationDelay: `${index * 50}ms`,
          }}
          onClick={() => onItemClick?.(item)}
        >
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold">{item.symbol}</span>
                <span className={cn('text-[9px] font-medium', getCategoryColor(item.category))}>
                  {getCategoryLabel(item.category)}
                </span>
              </div>
              <p className="mt-0.5 text-[10px] text-muted-foreground line-clamp-1">
                {item.name}
              </p>
            </div>
            <div className={cn('flex items-center', getTextColor(item.change))}>
              {item.change > 0 ? (
                <ArrowUp className="h-3 w-3" />
              ) : item.change < 0 ? (
                <ArrowDown className="h-3 w-3" />
              ) : (
                <Minus className="h-3 w-3" />
              )}
            </div>
          </div>

          <div className="mt-3">
            <div className="flex items-end justify-between">
              <span className="text-lg font-bold tabular-nums">
                ₹{item.price.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={cn('text-xs font-medium tabular-nums', getTextColor(item.change))}>
                {item.change > 0 ? '+' : ''}{item.change.toFixed(2)}%
              </span>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-[9px] text-muted-foreground">
              <div className="flex items-center gap-0.5">
                <TrendingUp className="h-2.5 w-2.5" />
                <span>Vol: {item.volatility.toFixed(1)}%</span>
              </div>
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 h-0.5 overflow-hidden rounded-b">
            <div
              className={cn(
                'h-full transition-all',
                item.change > 0 ? 'bg-bullish' : item.change < 0 ? 'bg-bearish' : 'bg-muted'
              )}
              style={{ width: `${Math.min(100, Math.abs(item.change) * 10)}%` }}
            />
          </div>
        </Link>
      ))}
    </div>
  );
}
