'use client';

import { useMemo } from 'react';
import type { CandleData, TradingStyle } from '@/lib/trading-types';
import { performTechnicalAnalysis, type ComprehensiveTechnicalAnalysis } from '@/lib/technical-analysis';
import { cn } from '@/lib/utils';
import { 
  Target, AlertTriangle, TrendingUp, TrendingDown, Clock, Zap, 
  ArrowUpRight, ArrowDownRight, Shield, IndianRupee, BarChart2,
  Landmark, Timer, Activity, DollarSign
} from 'lucide-react';

interface TradeRecommendationProps {
  candles: CandleData[];
  currentPrice: number;
  symbol: string;
  tradingStyle: TradingStyle;
  assetCategory?: string;
}

interface StrategyRecommendation {
  direction: 'long' | 'short' | 'neutral';
  entry: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  riskRewardRatio: number;
  confidence: number;
  reasoning: string[];
  timeframe: string;
  holdingPeriod: string;
  positionSize: string;
  // F&O specific
  foRecommendation?: {
    type: 'call' | 'put';
    strike: number;
    expiry: string;
    premium: number;
    breakeven: number;
    maxProfit: string;
    maxLoss: number;
    lotSize: number;
    strategy: string;
  };
}

function calculateStrikePrice(currentPrice: number, direction: 'call' | 'put'): number {
  // Round to nearest 50 for stocks, 100 for indices
  const roundTo = currentPrice > 1000 ? 100 : 50;
  const base = Math.round(currentPrice / roundTo) * roundTo;
  
  if (direction === 'call') {
    return base; // At-the-money or slightly OTM
  } else {
    return base; // At-the-money or slightly OTM
  }
}

function getExpiryDate(): string {
  const now = new Date();
  // Get next Thursday (weekly expiry for Indian markets)
  const daysUntilThursday = (4 - now.getDay() + 7) % 7 || 7;
  const nextThursday = new Date(now.getTime() + daysUntilThursday * 24 * 60 * 60 * 1000);
  return nextThursday.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function generateStrategyRecommendation(
  analysis: ComprehensiveTechnicalAnalysis,
  currentPrice: number,
  tradingStyle: TradingStyle,
  assetCategory?: string
): StrategyRecommendation {
  const { overallSentiment, confidenceScore, atr, supportResistance, signals } = analysis;
  
  const isLong = overallSentiment === 'strong_buy' || overallSentiment === 'buy';
  const isShort = overallSentiment === 'strong_sell' || overallSentiment === 'sell';
  const direction = isLong ? 'long' : isShort ? 'short' : 'neutral';
  
  // Base calculations
  let entry = currentPrice;
  let stopLoss: number;
  let target1: number;
  let target2: number;
  let target3: number;
  let timeframe: string;
  let holdingPeriod: string;
  let positionSize: string;
  
  // Adjust based on trading style
  switch (tradingStyle) {
    case 'scalping':
      // Tight stops, quick profits
      if (isLong) {
        stopLoss = currentPrice - (atr.value * 0.5);
        target1 = currentPrice + (atr.value * 0.75);
        target2 = currentPrice + (atr.value * 1);
        target3 = currentPrice + (atr.value * 1.5);
      } else {
        stopLoss = currentPrice + (atr.value * 0.5);
        target1 = currentPrice - (atr.value * 0.75);
        target2 = currentPrice - (atr.value * 1);
        target3 = currentPrice - (atr.value * 1.5);
      }
      timeframe = '1m - 5m';
      holdingPeriod = '5-30 minutes';
      positionSize = '2-5% of capital per trade';
      break;
      
    case 'intraday':
      // Medium stops, close by EOD
      if (isLong) {
        entry = supportResistance.pivotPoint < currentPrice ? currentPrice : supportResistance.pivotPoint;
        stopLoss = supportResistance.s1;
        target1 = supportResistance.r1;
        target2 = supportResistance.r2;
        target3 = supportResistance.r3;
      } else {
        entry = supportResistance.pivotPoint > currentPrice ? currentPrice : supportResistance.pivotPoint;
        stopLoss = supportResistance.r1;
        target1 = supportResistance.s1;
        target2 = supportResistance.s2;
        target3 = supportResistance.s3;
      }
      timeframe = '5m - 15m';
      holdingPeriod = '30 min - 6 hours';
      positionSize = '3-5% of capital per trade';
      break;
      
    case 'swing':
      // Wider stops, hold for days
      if (isLong) {
        stopLoss = currentPrice - (atr.value * 2);
        target1 = currentPrice + (atr.value * 2.5);
        target2 = currentPrice + (atr.value * 4);
        target3 = currentPrice + (atr.value * 6);
      } else {
        stopLoss = currentPrice + (atr.value * 2);
        target1 = currentPrice - (atr.value * 2.5);
        target2 = currentPrice - (atr.value * 4);
        target3 = currentPrice - (atr.value * 6);
      }
      timeframe = '1h - 4h';
      holdingPeriod = '2-10 days';
      positionSize = '5-10% of capital per trade';
      break;
      
    case 'longterm':
      // Very wide stops, hold for weeks/months
      if (isLong) {
        stopLoss = currentPrice * 0.92; // 8% stop loss
        target1 = currentPrice * 1.15; // 15% target
        target2 = currentPrice * 1.25; // 25% target
        target3 = currentPrice * 1.40; // 40% target
      } else {
        stopLoss = currentPrice * 1.08;
        target1 = currentPrice * 0.85;
        target2 = currentPrice * 0.75;
        target3 = currentPrice * 0.60;
      }
      timeframe = '1D - 1W';
      holdingPeriod = '2 weeks - 6 months';
      positionSize = '10-20% of capital per position';
      break;
      
    case 'fo':
    default:
      // F&O - options strategy
      if (isLong) {
        stopLoss = supportResistance.s2;
        target1 = supportResistance.r1;
        target2 = supportResistance.r2;
        target3 = supportResistance.r3;
      } else {
        stopLoss = supportResistance.r2;
        target1 = supportResistance.s1;
        target2 = supportResistance.s2;
        target3 = supportResistance.s3;
      }
      timeframe = '15m - 1h';
      holdingPeriod = '1 day - 1 week (till expiry)';
      positionSize = '1-2 lots based on margin';
      break;
  }
  
  const risk = Math.abs(entry - stopLoss);
  const reward = Math.abs(target1 - entry);
  const riskRewardRatio = risk > 0 ? reward / risk : 0;
  
  // Generate reasoning based on signals
  const reasoning: string[] = [];
  const buySignals = signals.filter(s => s.signal === 'buy');
  const sellSignals = signals.filter(s => s.signal === 'sell');
  
  if (isLong) {
    buySignals.forEach(s => reasoning.push(s.reason));
    if (analysis.movingAverages.goldenCross) reasoning.push('Golden Cross pattern detected');
    if (analysis.rsi.signal === 'oversold') reasoning.push('RSI indicates oversold conditions');
    if (analysis.macd.crossover === 'bullish_cross') reasoning.push('MACD bullish crossover');
    if (analysis.volumeAnalysis.trend === 'accumulation') reasoning.push('Volume indicates accumulation');
  } else if (isShort) {
    sellSignals.forEach(s => reasoning.push(s.reason));
    if (analysis.movingAverages.deathCross) reasoning.push('Death Cross pattern detected');
    if (analysis.rsi.signal === 'overbought') reasoning.push('RSI indicates overbought conditions');
    if (analysis.macd.crossover === 'bearish_cross') reasoning.push('MACD bearish crossover');
    if (analysis.volumeAnalysis.trend === 'distribution') reasoning.push('Volume indicates distribution');
  } else {
    reasoning.push('Mixed signals - wait for clearer direction');
    reasoning.push('Price consolidating near support/resistance');
  }
  
  // F&O recommendation for stocks
  let foRecommendation: StrategyRecommendation['foRecommendation'] | undefined;
  
  if (tradingStyle === 'fo' && (assetCategory === 'stocks' || !assetCategory)) {
    const optionType = isLong ? 'call' : isShort ? 'put' : 'call';
    const strike = calculateStrikePrice(currentPrice, optionType);
    const estimatedPremium = Math.round(atr.value * 2 * 100) / 100;
    const breakeven = optionType === 'call' ? strike + estimatedPremium : strike - estimatedPremium;
    
    foRecommendation = {
      type: optionType,
      strike,
      expiry: getExpiryDate(),
      premium: estimatedPremium,
      breakeven: Math.round(breakeven * 100) / 100,
      maxProfit: 'Unlimited',
      maxLoss: estimatedPremium,
      lotSize: currentPrice > 5000 ? 25 : currentPrice > 1000 ? 50 : 100, // Estimated lot sizes
      strategy: isLong ? 'Buy Call (Bullish)' : isShort ? 'Buy Put (Bearish)' : 'Wait for signal',
    };
  }
  
  return {
    direction,
    entry: Math.round(entry * 100) / 100,
    stopLoss: Math.round(stopLoss * 100) / 100,
    target1: Math.round(target1 * 100) / 100,
    target2: Math.round(target2 * 100) / 100,
    target3: Math.round(target3 * 100) / 100,
    riskRewardRatio: Math.round(riskRewardRatio * 100) / 100,
    confidence: confidenceScore,
    reasoning: reasoning.slice(0, 4), // Top 4 reasons
    timeframe,
    holdingPeriod,
    positionSize,
    foRecommendation,
  };
}

export function TradeRecommendation({ candles, currentPrice, symbol, tradingStyle, assetCategory }: TradeRecommendationProps) {
  const analysis = useMemo(() => performTechnicalAnalysis(candles), [candles]);
  const recommendation = useMemo(
    () => generateStrategyRecommendation(analysis, currentPrice, tradingStyle, assetCategory),
    [analysis, currentPrice, tradingStyle, assetCategory]
  );

  const isLong = recommendation.direction === 'long';
  const isShort = recommendation.direction === 'short';
  const isNeutral = recommendation.direction === 'neutral';

  const strategyNames: Record<TradingStyle, string> = {
    fo: 'F&O (Futures & Options)',
    intraday: 'Intraday Trading',
    swing: 'Swing Trading',
    scalping: 'Scalping',
    longterm: 'Long-term Investment',
  };

  const strategyIcons: Record<TradingStyle, typeof Landmark> = {
    fo: Landmark,
    intraday: Timer,
    swing: TrendingUp,
    scalping: Zap,
    longterm: Target,
  };

  const StrategyIcon = strategyIcons[tradingStyle];

  return (
    <div className="space-y-4">
      {/* Main Recommendation Card */}
      <div className={cn(
        'rounded-xl border-2 p-4',
        isLong ? 'border-bullish/50 bg-bullish/5' :
        isShort ? 'border-bearish/50 bg-bearish/5' :
        'border-amber-500/50 bg-amber-500/5'
      )}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              'flex h-12 w-12 items-center justify-center rounded-xl',
              isLong ? 'bg-bullish/20' : isShort ? 'bg-bearish/20' : 'bg-amber-500/20'
            )}>
              {isLong ? (
                <ArrowUpRight className="h-6 w-6 text-bullish" />
              ) : isShort ? (
                <ArrowDownRight className="h-6 w-6 text-bearish" />
              ) : (
                <Activity className="h-6 w-6 text-amber-500" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <StrategyIcon className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{strategyNames[tradingStyle]}</span>
              </div>
              <h3 className={cn(
                'text-xl font-bold',
                isLong ? 'text-bullish' : isShort ? 'text-bearish' : 'text-amber-500'
              )}>
                {isLong ? 'BUY / LONG' : isShort ? 'SELL / SHORT' : 'WAIT / NEUTRAL'}
              </h3>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted-foreground">Confidence</div>
            <div className={cn(
              'text-2xl font-bold',
              recommendation.confidence >= 70 ? 'text-bullish' :
              recommendation.confidence >= 50 ? 'text-amber-500' : 'text-muted-foreground'
            )}>
              {recommendation.confidence}%
            </div>
          </div>
        </div>

        {/* Entry, Stop Loss, Targets */}
        {!isNeutral && (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-lg bg-card p-3">
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <DollarSign className="h-3 w-3" />
                Entry Price
              </div>
              <div className="mt-1 font-mono text-lg font-bold">{recommendation.entry.toLocaleString()}</div>
            </div>
            <div className="rounded-lg bg-bearish/10 p-3">
              <div className="flex items-center gap-1 text-[10px] text-bearish">
                <Shield className="h-3 w-3" />
                Stop Loss
              </div>
              <div className="mt-1 font-mono text-lg font-bold text-bearish">{recommendation.stopLoss.toLocaleString()}</div>
              <div className="text-[10px] text-muted-foreground">
                Risk: {Math.abs(((recommendation.stopLoss - recommendation.entry) / recommendation.entry) * 100).toFixed(2)}%
              </div>
            </div>
            <div className="rounded-lg bg-bullish/10 p-3">
              <div className="flex items-center gap-1 text-[10px] text-bullish">
                <Target className="h-3 w-3" />
                Target 1
              </div>
              <div className="mt-1 font-mono text-lg font-bold text-bullish">{recommendation.target1.toLocaleString()}</div>
              <div className="text-[10px] text-muted-foreground">
                +{Math.abs(((recommendation.target1 - recommendation.entry) / recommendation.entry) * 100).toFixed(2)}%
              </div>
            </div>
            <div className="rounded-lg bg-bullish/10 p-3">
              <div className="flex items-center gap-1 text-[10px] text-bullish">
                <Target className="h-3 w-3" />
                Target 2
              </div>
              <div className="mt-1 font-mono text-lg font-bold text-bullish">{recommendation.target2.toLocaleString()}</div>
              <div className="text-[10px] text-muted-foreground">
                +{Math.abs(((recommendation.target2 - recommendation.entry) / recommendation.entry) * 100).toFixed(2)}%
              </div>
            </div>
          </div>
        )}

        {/* Additional Info */}
        <div className="mt-4 grid grid-cols-3 gap-3 text-center">
          <div className="rounded-lg bg-card p-2">
            <div className="text-[10px] text-muted-foreground">Risk:Reward</div>
            <div className={cn(
              'font-bold',
              recommendation.riskRewardRatio >= 2 ? 'text-bullish' :
              recommendation.riskRewardRatio >= 1.5 ? 'text-amber-500' : 'text-bearish'
            )}>
              1:{recommendation.riskRewardRatio}
            </div>
          </div>
          <div className="rounded-lg bg-card p-2">
            <div className="text-[10px] text-muted-foreground">Timeframe</div>
            <div className="font-bold">{recommendation.timeframe}</div>
          </div>
          <div className="rounded-lg bg-card p-2">
            <div className="text-[10px] text-muted-foreground">Hold Period</div>
            <div className="text-xs font-bold">{recommendation.holdingPeriod}</div>
          </div>
        </div>
      </div>

      {/* F&O Recommendation */}
      {tradingStyle === 'fo' && recommendation.foRecommendation && !isNeutral && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-3 flex items-center gap-2">
            <Landmark className="h-5 w-5 text-primary" />
            <h4 className="font-semibold">Options Strategy</h4>
            <span className={cn(
              'ml-auto rounded-full px-2.5 py-0.5 text-xs font-medium',
              recommendation.foRecommendation.type === 'call' ? 'bg-bullish/20 text-bullish' : 'bg-bearish/20 text-bearish'
            )}>
              {recommendation.foRecommendation.type === 'call' ? 'CALL' : 'PUT'}
            </span>
          </div>

          <div className="rounded-lg bg-muted/50 p-3 mb-3">
            <div className="text-center">
              <div className="text-xs text-muted-foreground">Recommended Strategy</div>
              <div className="mt-1 text-lg font-bold">{recommendation.foRecommendation.strategy}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-lg bg-muted/30 p-2.5">
              <div className="text-[10px] text-muted-foreground">Strike Price</div>
              <div className="font-mono font-bold">{recommendation.foRecommendation.strike.toLocaleString()}</div>
            </div>
            <div className="rounded-lg bg-muted/30 p-2.5">
              <div className="text-[10px] text-muted-foreground">Premium (Est.)</div>
              <div className="font-mono font-bold">{recommendation.foRecommendation.premium.toLocaleString()}</div>
            </div>
            <div className="rounded-lg bg-muted/30 p-2.5">
              <div className="text-[10px] text-muted-foreground">Breakeven</div>
              <div className="font-mono font-bold">{recommendation.foRecommendation.breakeven.toLocaleString()}</div>
            </div>
            <div className="rounded-lg bg-muted/30 p-2.5">
              <div className="text-[10px] text-muted-foreground">Expiry</div>
              <div className="font-mono text-sm font-bold">{recommendation.foRecommendation.expiry}</div>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-3">
            <div className="rounded-lg border border-bullish/30 bg-bullish/5 p-2.5 text-center">
              <div className="text-[10px] text-muted-foreground">Max Profit</div>
              <div className="font-bold text-bullish">{recommendation.foRecommendation.maxProfit}</div>
            </div>
            <div className="rounded-lg border border-bearish/30 bg-bearish/5 p-2.5 text-center">
              <div className="text-[10px] text-muted-foreground">Max Loss</div>
              <div className="font-bold text-bearish">{recommendation.foRecommendation.maxLoss.toLocaleString()}</div>
            </div>
            <div className="rounded-lg border border-border p-2.5 text-center">
              <div className="text-[10px] text-muted-foreground">Lot Size</div>
              <div className="font-bold">{recommendation.foRecommendation.lotSize}</div>
            </div>
          </div>

          <div className="mt-3 rounded-lg bg-amber-500/10 p-2.5 text-xs text-amber-500">
            <AlertTriangle className="mr-1 inline h-3 w-3" />
            F&O involves high risk. Only trade with capital you can afford to lose.
          </div>
        </div>
      )}

      {/* Reasoning */}
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="mb-3 flex items-center gap-2">
          <BarChart2 className="h-4 w-4 text-muted-foreground" />
          <h4 className="text-sm font-semibold">Analysis Reasoning</h4>
        </div>
        <ul className="space-y-2">
          {recommendation.reasoning.map((reason, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <div className={cn(
                'mt-1 h-1.5 w-1.5 shrink-0 rounded-full',
                isLong ? 'bg-bullish' : isShort ? 'bg-bearish' : 'bg-amber-500'
              )} />
              {reason}
            </li>
          ))}
        </ul>
      </div>

      {/* Position Sizing */}
      <div className="rounded-lg bg-muted/30 p-3 text-center text-xs text-muted-foreground">
        <span className="font-medium">Suggested Position Size:</span> {recommendation.positionSize}
      </div>

      {/* Disclaimer */}
      <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 text-[10px] text-amber-600 dark:text-amber-400">
        <AlertTriangle className="mr-1 inline h-3 w-3" />
        <strong>Disclaimer:</strong> This is AI-generated analysis for educational purposes only. 
        Not financial advice. Always do your own research and consider your risk tolerance before trading.
      </div>
    </div>
  );
}
