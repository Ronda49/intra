'use client';

import { useMemo, useState, useCallback, useRef, useEffect } from 'react';
import type { TradingStyle, HeatmapItem, AssetCategory } from '@/lib/trading-types';
import { TradingStrategyTabs } from './trading-strategy-selector';
import { cn } from '@/lib/utils';
import { 
  Target, AlertTriangle, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, 
  Shield, IndianRupee, Zap, Timer, Activity, ChevronRight, Sparkles,
  BarChart2, Clock, Search, X, Coins, Gem, CheckCircle2, XCircle,
  ArrowRight, LineChart, CandlestickChart, Percent, Info, DollarSign
} from 'lucide-react';
import Link from 'next/link';
import { searchAssets, type UnifiedAsset, getPopularAssets } from '@/lib/data/asset-database';

interface TradeSignalsPanelProps {
  assets: HeatmapItem[];
}

interface TradeSignal {
  symbol: string;
  name: string;
  category: AssetCategory;
  exchange: string;
  direction: 'LONG' | 'SHORT' | 'NEUTRAL';
  marketBias: 'Bullish' | 'Bearish' | 'Neutral';
  entry: number;
  entryZone: { low: number; high: number };
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  riskReward: number;
  confidence: number;
  timeframe: string;
  holdingPeriod: string;
  reasoning: string;
  technicalNotes: string[];
  currentPrice: number;
  change24h: number;
  sessionTiming: string;
}

const categoryIcons: Record<AssetCategory, typeof TrendingUp> = {
  stocks: TrendingUp,
  crypto: Coins,
  forex: DollarSign,
  commodities: Gem,
  indices: BarChart2,
};

const categoryColors: Record<AssetCategory, string> = {
  stocks: 'text-blue-400 bg-blue-400/10 border-blue-400/30',
  crypto: 'text-amber-400 bg-amber-400/10 border-amber-400/30',
  forex: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30',
  commodities: 'text-purple-400 bg-purple-400/10 border-purple-400/30',
  indices: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/30',
};

const strategyConfig: Record<TradingStyle, { 
  name: string; 
  timeframe: string; 
  holding: string;
  atrMultiplier: { sl: number; t1: number; t2: number; t3: number };
}> = {
  scalping: { 
    name: 'Scalping', 
    timeframe: '1m - 5m', 
    holding: '5-30 minutes',
    atrMultiplier: { sl: 0.5, t1: 0.75, t2: 1.25, t3: 1.75 }
  },
  intraday: { 
    name: 'Intraday', 
    timeframe: '5m - 15m', 
    holding: 'Same day',
    atrMultiplier: { sl: 1, t1: 1.5, t2: 2.5, t3: 3.5 }
  },
  swing: { 
    name: 'Swing Trading', 
    timeframe: '1H - 4H', 
    holding: '2-10 days',
    atrMultiplier: { sl: 2, t1: 3, t2: 5, t3: 7 }
  },
  fo: { 
    name: 'F&O / Options', 
    timeframe: '15m - 1H', 
    holding: '1 day - expiry',
    atrMultiplier: { sl: 1.5, t1: 2, t2: 3.5, t3: 5 }
  },
  longterm: { 
    name: 'Long-term Investing', 
    timeframe: 'Daily - Weekly', 
    holding: 'Weeks - Months',
    atrMultiplier: { sl: 8, t1: 15, t2: 30, t3: 50 }
  },
};

function generateTradeSignal(
  asset: UnifiedAsset, 
  style: TradingStyle,
  priceData?: { price: number; change: number }
): TradeSignal {
  // Simulated current price if not provided
  const basePrice = priceData?.price || getSimulatedPrice(asset);
  const change24h = priceData?.change || (Math.random() - 0.5) * 10;
  
  // Calculate ATR proxy (using volatility estimate)
  const volatilityPercent = Math.abs(change24h) + Math.random() * 3 + 1;
  const atrProxy = basePrice * (volatilityPercent / 100);
  
  // Determine market bias based on price action simulation
  const momentum = change24h;
  const rsi = 50 + momentum * 3 + (Math.random() - 0.5) * 20;
  const ema20Above = momentum > 0.5;
  const ema50Above = momentum > 1;
  
  let marketBias: 'Bullish' | 'Bearish' | 'Neutral';
  let direction: 'LONG' | 'SHORT' | 'NEUTRAL';
  
  if (momentum > 1 && rsi > 45 && rsi < 70) {
    marketBias = 'Bullish';
    direction = 'LONG';
  } else if (momentum < -1 && rsi > 30 && rsi < 55) {
    marketBias = 'Bearish';
    direction = 'SHORT';
  } else {
    marketBias = 'Neutral';
    direction = Math.abs(momentum) > 0.5 ? (momentum > 0 ? 'LONG' : 'SHORT') : 'NEUTRAL';
  }
  
  const config = strategyConfig[style];
  const isLong = direction === 'LONG';
  
  // Calculate levels
  let entry = basePrice;
  let entryZone = { low: basePrice * 0.998, high: basePrice * 1.002 };
  let stopLoss: number;
  let target1: number;
  let target2: number;
  let target3: number;
  
  if (isLong) {
    stopLoss = basePrice - (atrProxy * config.atrMultiplier.sl);
    target1 = basePrice + (atrProxy * config.atrMultiplier.t1);
    target2 = basePrice + (atrProxy * config.atrMultiplier.t2);
    target3 = basePrice + (atrProxy * config.atrMultiplier.t3);
    entryZone = { low: basePrice * 0.998, high: basePrice * 1.003 };
  } else {
    stopLoss = basePrice + (atrProxy * config.atrMultiplier.sl);
    target1 = basePrice - (atrProxy * config.atrMultiplier.t1);
    target2 = basePrice - (atrProxy * config.atrMultiplier.t2);
    target3 = basePrice - (atrProxy * config.atrMultiplier.t3);
    entryZone = { low: basePrice * 0.997, high: basePrice * 1.002 };
  }
  
  const risk = Math.abs(entry - stopLoss);
  const reward = Math.abs(target1 - entry);
  const riskReward = risk > 0 ? Math.round((reward / risk) * 10) / 10 : 2;
  
  // Calculate confidence
  const baseConfidence = 50;
  const momentumBonus = Math.min(20, Math.abs(momentum) * 5);
  const rrBonus = Math.min(15, riskReward * 5);
  const confidence = Math.min(92, Math.round(baseConfidence + momentumBonus + rrBonus));
  
  // Generate technical notes
  const technicalNotes: string[] = [];
  technicalNotes.push(`RSI(14): ${rsi.toFixed(1)} - ${rsi > 70 ? 'Overbought' : rsi < 30 ? 'Oversold' : 'Neutral zone'}`);
  technicalNotes.push(`Price ${ema20Above ? 'above' : 'below'} 20 EMA`);
  technicalNotes.push(`Volatility: ${volatilityPercent.toFixed(1)}% (${volatilityPercent > 3 ? 'High' : 'Normal'})`);
  
  if (style === 'fo') {
    // Calculate ATM strike based on asset type
    const strikeInterval = asset.category === 'indices' ? 
      (basePrice > 40000 ? 100 : 50) : // BANKNIFTY uses 100, NIFTY uses 50
      (basePrice > 1000 ? 50 : 10);
    const atmStrike = Math.round(basePrice / strikeInterval) * strikeInterval;
    technicalNotes.push(`ATM Strike: ${atmStrike.toLocaleString()}`);
    technicalNotes.push(isLong ? 'Consider buying CE' : 'Consider buying PE');
    
    // Add index-specific F&O data
    if (asset.category === 'indices') {
      const simulatedOI = Math.round(5000000 + Math.random() * 10000000);
      const simulatedPCR = 0.7 + Math.random() * 0.8; // 0.7 to 1.5
      const maxPain = Math.round(basePrice / strikeInterval) * strikeInterval + 
        (Math.random() > 0.5 ? strikeInterval : -strikeInterval) * Math.floor(Math.random() * 3);
      
      technicalNotes.push(`OI: ${(simulatedOI / 1000000).toFixed(1)}M contracts`);
      technicalNotes.push(`PCR: ${simulatedPCR.toFixed(2)} (${simulatedPCR > 1 ? 'Bullish' : simulatedPCR < 0.8 ? 'Bearish' : 'Neutral'})`);
      technicalNotes.push(`Max Pain: ${maxPain.toLocaleString()}`);
    }
  }
  
  // Session timing
  const hour = new Date().getHours();
  let sessionTiming = 'Asian Session';
  if (hour >= 13 && hour < 18) sessionTiming = 'London Session';
  else if (hour >= 18 || hour < 2) sessionTiming = 'New York Session';
  
  // Generate reasoning
  let reasoning = '';
  if (direction === 'LONG') {
    reasoning = `${marketBias} momentum detected. Price showing strength with ${change24h > 0 ? '+' : ''}${change24h.toFixed(2)}% move. `;
    reasoning += `RSI at ${rsi.toFixed(0)} supports upside. `;
    reasoning += style === 'fo' ? 'Buy CE at ATM strike.' : `Entry at market with ${config.atrMultiplier.sl}x ATR stop.`;
  } else if (direction === 'SHORT') {
    reasoning = `${marketBias} pressure building. Weakness showing with ${change24h.toFixed(2)}% decline. `;
    reasoning += `RSI at ${rsi.toFixed(0)} confirms downside. `;
    reasoning += style === 'fo' ? 'Buy PE at ATM strike.' : `Entry at market with ${config.atrMultiplier.sl}x ATR stop.`;
  } else {
    reasoning = 'Market in consolidation. Wait for directional breakout. ';
    reasoning += style === 'fo' ? 'Consider Iron Condor or Straddle.' : 'No clear trade setup - patience advised.';
  }
  
  return {
    symbol: asset.symbol,
    name: asset.name,
    category: asset.category,
    exchange: asset.exchange || 'Exchange',
    direction,
    marketBias,
    entry: roundPrice(entry, asset.category),
    entryZone: { 
      low: roundPrice(entryZone.low, asset.category), 
      high: roundPrice(entryZone.high, asset.category) 
    },
    stopLoss: roundPrice(stopLoss, asset.category),
    target1: roundPrice(target1, asset.category),
    target2: roundPrice(target2, asset.category),
    target3: roundPrice(target3, asset.category),
    riskReward,
    confidence,
    timeframe: config.timeframe,
    holdingPeriod: config.holding,
    reasoning,
    technicalNotes,
    currentPrice: roundPrice(basePrice, asset.category),
    change24h,
    sessionTiming,
  };
}

function getSimulatedPrice(asset: UnifiedAsset): number {
  // Simulated realistic prices based on asset type
  const basePrices: Record<string, number> = {
    // Crypto
    'BTCUSDT': 97845, 'ETHUSDT': 3456, 'SOLUSDT': 245, 'BNBUSDT': 712, 'XRPUSDT': 2.45,
    'ADAUSDT': 1.12, 'DOGEUSDT': 0.42, 'DOTUSDT': 8.92, 'LINKUSDT': 18.5, 'AVAXUSDT': 42,
    // Forex
    'EURUSD': 1.0845, 'GBPUSD': 1.2654, 'USDJPY': 149.85, 'AUDUSD': 0.6523, 'USDCAD': 1.3542,
    // Commodities
    'XAUUSD': 2645, 'XAGUSD': 31.25, 'USOIL': 78.45, 'UKOIL': 82.30, 'NATGAS': 2.85,
    // Indian Indices
    'NIFTY': 24850, 'BANKNIFTY': 52450, 'SENSEX': 81750, 'FINNIFTY': 23850,
    'NIFTYMIDCAP': 58200, 'NIFTYSMALL': 17450, 'NIFTYIT': 38500,
    // US Indices
    'SPX': 6045, 'NAS100': 21450, 'DJ30': 44850, 'RUT2000': 2285, 'VIX': 14.5,
    // European Indices
    'UK100': 8425, 'DAX40': 20150, 'CAC40': 7850,
    // Asian Indices
    'JP225': 39450, 'HK50': 19850, 'SSEC': 3285,
  };
  
  if (basePrices[asset.symbol] || basePrices[asset.tradingSymbol]) {
    return basePrices[asset.symbol] || basePrices[asset.tradingSymbol];
  }
  
  // Generate realistic price for indices
  if (asset.category === 'indices') {
    return 15000 + Math.random() * 30000;
  }
  
  // Generate realistic price for stocks
  if (asset.category === 'stocks') {
    return 500 + Math.random() * 4500;
  }
  
  return 100 + Math.random() * 900;
}

function roundPrice(price: number, category: AssetCategory): number {
  if (category === 'forex') return Math.round(price * 100000) / 100000;
  if (category === 'crypto' && price < 1) return Math.round(price * 10000) / 10000;
  if (category === 'indices') return Math.round(price * 100) / 100;
  if (price > 1000) return Math.round(price * 100) / 100;
  return Math.round(price * 100) / 100;
}

function formatPrice(price: number, category: AssetCategory): string {
  if (category === 'forex') return price.toFixed(5);
  if (category === 'crypto' && price < 1) return price.toFixed(4);
  if (category === 'indices' || price > 10000) return price.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return price.toFixed(2);
}

function formatPriceWithSymbol(price: number, category: AssetCategory): string {
  // ALL prices displayed in INR - convert crypto/commodities from USD
  if (category === 'crypto' || category === 'commodities') {
    // Prices already in INR equivalent from generation
    const formatted = formatPrice(price, category);
    return `₹${formatted}`;
  }
  const formatted = formatPrice(price, category);
  return `₹${formatted}`;
}

export function TradeSignalsPanel({ assets }: TradeSignalsPanelProps) {
  const [selectedAsset, setSelectedAsset] = useState<UnifiedAsset | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<TradingStyle | null>(null);
  const [signal, setSignal] = useState<TradeSignal | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UnifiedAsset[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Popular assets for quick selection
  const popularAssets = useMemo(() => getPopularAssets(), []);
  
  // Handle search
  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    if (query.trim().length > 0) {
      const results = searchAssets(query, undefined, 10);
      setSearchResults(results);
      setIsSearchOpen(true);
    } else {
      setSearchResults([]);
      setIsSearchOpen(false);
    }
  }, []);
  
  // Handle asset selection
  const handleSelectAsset = useCallback((asset: UnifiedAsset) => {
    setSelectedAsset(asset);
    setSelectedStyle(null);
    setSignal(null);
    setSearchQuery('');
    setSearchResults([]);
    setIsSearchOpen(false);
  }, []);
  
  // Handle strategy selection
  const handleSelectStrategy = useCallback((style: TradingStyle) => {
    setSelectedStyle(style);
    if (selectedAsset) {
      // Find matching price data from assets prop
      const assetData = assets.find(a => 
        a.symbol === selectedAsset.symbol || 
        a.symbol === selectedAsset.tradingSymbol
      );
      const priceData = assetData ? { price: assetData.price, change: assetData.change } : undefined;
      const newSignal = generateTradeSignal(selectedAsset, style, priceData);
      setSignal(newSignal);
    }
  }, [selectedAsset, assets]);
  
  // Reset function
  const handleReset = useCallback(() => {
    setSelectedAsset(null);
    setSelectedStyle(null);
    setSignal(null);
    setSearchQuery('');
  }, []);
  
  // Close search on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="border-b border-border bg-gradient-to-r from-primary/5 to-transparent p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <CandlestickChart className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-lg">AI Trade Signal Engine</h2>
              <p className="text-xs text-muted-foreground">
                Search any instrument and get professional trade signals
              </p>
            </div>
          </div>
          {selectedAsset && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1 rounded-lg bg-muted px-3 py-1.5 text-xs hover:bg-muted/80"
            >
              <X className="h-3 w-3" />
              Reset
            </button>
          )}
        </div>
      </div>
      
      {/* Step 1: Search Instrument */}
      {!selectedAsset && (
        <div className="p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-medium">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">1</span>
            Search Instrument
          </div>
          
          <div ref={searchRef} className="relative mb-4">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              ref={inputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              onFocus={() => searchQuery.trim() && setIsSearchOpen(true)}
              placeholder="Search: NIFTY, BANKNIFTY, TATA, BTC, EUR/USD, S&P 500..."
              className="h-11 w-full rounded-lg border border-border bg-background pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            
            {isSearchOpen && searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full z-50 mt-1 max-h-64 overflow-y-auto rounded-lg border border-border bg-card shadow-xl">
                {searchResults.map((asset) => {
                  const Icon = categoryIcons[asset.category];
                  return (
                    <button
                      key={asset.id}
                      onClick={() => handleSelectAsset(asset)}
                      className="flex w-full items-center gap-3 px-3 py-2.5 text-left transition-colors hover:bg-accent"
                    >
                      <div className={cn('flex h-8 w-8 items-center justify-center rounded', categoryColors[asset.category])}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{asset.symbol}</span>
                          <span className={cn('rounded px-1.5 py-0.5 text-[10px] uppercase', categoryColors[asset.category])}>
                            {asset.category}
                          </span>
                        </div>
                        <p className="truncate text-xs text-muted-foreground">{asset.name}</p>
                      </div>
                      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                    </button>
                  );
                })}
              </div>
            )}
          </div>
          
          {/* Quick Selection */}
          <div className="space-y-3">
            <p className="text-xs font-medium text-muted-foreground">Quick Select:</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              {(['indices', 'stocks', 'crypto', 'forex', 'commodities'] as AssetCategory[]).map((category) => {
                const Icon = categoryIcons[category];
                const categoryAssets = popularAssets[category].slice(0, 3);
                return (
                  <div key={category} className="space-y-2">
                    <div className={cn('flex items-center gap-1.5 text-xs font-medium', categoryColors[category].split(' ')[0])}>
                      <Icon className="h-3.5 w-3.5" />
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {categoryAssets.map((asset) => (
                        <button
                          key={asset.id}
                          onClick={() => handleSelectAsset(asset)}
                          className={cn(
                            'rounded-md border px-2 py-1 text-xs transition-colors hover:bg-accent',
                            categoryColors[asset.category]
                          )}
                        >
                          {asset.symbol.replace('USDT', '').replace('.NS', '')}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
      
      {/* Step 2: Strategy Selection */}
      {selectedAsset && !selectedStyle && (
        <div className="p-4">
          {/* Selected Asset Display */}
          <div className={cn(
            'mb-4 flex items-center gap-3 rounded-lg border p-3',
            categoryColors[selectedAsset.category]
          )}>
            {(() => {
              const Icon = categoryIcons[selectedAsset.category];
              return (
                <div className={cn('flex h-10 w-10 items-center justify-center rounded-lg', categoryColors[selectedAsset.category])}>
                  <Icon className="h-5 w-5" />
                </div>
              );
            })()}
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg">{selectedAsset.symbol}</span>
                <span className="rounded bg-background/50 px-2 py-0.5 text-xs">
                  {selectedAsset.exchange}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{selectedAsset.name}</p>
            </div>
            <CheckCircle2 className="h-5 w-5 text-bullish" />
          </div>
          
          <div className="mb-3 flex items-center gap-2 text-sm font-medium">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">2</span>
            Select Trading Strategy
          </div>
          
          <div className="grid gap-2">
            {(['intraday', 'scalping', 'swing', 'fo', 'longterm'] as TradingStyle[]).map((style) => {
              const config = strategyConfig[style];
              return (
                <button
                  key={style}
                  onClick={() => handleSelectStrategy(style)}
                  className="flex items-center justify-between rounded-lg border border-border bg-background p-3 text-left transition-all hover:border-primary hover:bg-accent"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
                      {style === 'scalping' && <Zap className="h-4 w-4 text-amber-500" />}
                      {style === 'intraday' && <Timer className="h-4 w-4 text-blue-500" />}
                      {style === 'swing' && <LineChart className="h-4 w-4 text-emerald-500" />}
                      {style === 'fo' && <BarChart2 className="h-4 w-4 text-purple-500" />}
                      {style === 'longterm' && <TrendingUp className="h-4 w-4 text-primary" />}
                    </div>
                    <div>
                      <div className="font-medium">{config.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {config.timeframe} | Hold: {config.holding}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </button>
              );
            })}
          </div>
        </div>
      )}
      
      {/* Step 3: Trade Signal */}
      {selectedAsset && selectedStyle && signal && (
        <div className="p-4">
          {/* Asset + Strategy Header */}
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {(() => {
                const Icon = categoryIcons[selectedAsset.category];
                return (
                  <div className={cn('flex h-10 w-10 items-center justify-center rounded-lg', categoryColors[selectedAsset.category])}>
                    <Icon className="h-5 w-5" />
                  </div>
                );
              })()}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">{signal.symbol}</span>
                  <span className="rounded bg-muted px-2 py-0.5 text-[10px]">
                    {strategyConfig[selectedStyle].name}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">{signal.exchange} | {signal.sessionTiming}</p>
              </div>
            </div>
            <button
              onClick={() => { setSelectedStyle(null); setSignal(null); }}
              className="text-xs text-primary hover:underline"
            >
              Change Strategy
            </button>
          </div>
          
          {/* Market Bias & Direction */}
          <div className={cn(
            'mb-4 rounded-lg border-2 p-4',
            signal.direction === 'LONG' ? 'border-bullish/50 bg-bullish/5' :
            signal.direction === 'SHORT' ? 'border-bearish/50 bg-bearish/5' :
            'border-border bg-muted/30'
          )}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {signal.direction === 'LONG' ? (
                  <ArrowUpRight className="h-8 w-8 text-bullish" />
                ) : signal.direction === 'SHORT' ? (
                  <ArrowDownRight className="h-8 w-8 text-bearish" />
                ) : (
                  <Activity className="h-8 w-8 text-muted-foreground" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      'text-2xl font-bold',
                      signal.direction === 'LONG' ? 'text-bullish' :
                      signal.direction === 'SHORT' ? 'text-bearish' : 'text-muted-foreground'
                    )}>
                      {signal.direction === 'LONG' ? 'BUY' : signal.direction === 'SHORT' ? 'SELL' : 'WAIT'}
                    </span>
                    <span className={cn(
                      'rounded px-2 py-0.5 text-xs font-medium',
                      signal.marketBias === 'Bullish' ? 'bg-bullish/20 text-bullish' :
                      signal.marketBias === 'Bearish' ? 'bg-bearish/20 text-bearish' :
                      'bg-muted text-muted-foreground'
                    )}>
                      {signal.marketBias}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{signal.reasoning}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-muted-foreground">Confidence</div>
                <div className={cn(
                  'text-3xl font-bold',
                  signal.confidence >= 70 ? 'text-bullish' :
                  signal.confidence >= 50 ? 'text-amber-500' : 'text-muted-foreground'
                )}>
                  {signal.confidence}%
                </div>
              </div>
            </div>
          </div>
          
          {/* Price Levels */}
          {signal.direction !== 'NEUTRAL' && (
            <>
              {/* Current Price */}
              <div className="mb-3 flex items-center justify-between rounded-lg bg-muted/50 p-3">
                <span className="text-sm text-muted-foreground">Current Price</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-lg font-bold">{formatPriceWithSymbol(signal.currentPrice, signal.category)}</span>
                  <span className={cn(
                    'text-sm font-medium',
                    signal.change24h >= 0 ? 'text-bullish' : 'text-bearish'
                  )}>
                    {signal.change24h >= 0 ? '+' : ''}{signal.change24h.toFixed(2)}%
                  </span>
                </div>
              </div>
              
              {/* Trade Levels Grid */}
              <div className="mb-4 grid grid-cols-2 gap-2">
                {/* Entry */}
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-primary">
                    <IndianRupee className="h-3 w-3" />
                    Entry Zone
                  </div>
                  <div className="mt-1 font-mono text-lg font-bold">{formatPriceWithSymbol(signal.entry, signal.category)}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {formatPriceWithSymbol(signal.entryZone.low, signal.category)} - {formatPriceWithSymbol(signal.entryZone.high, signal.category)}
                  </div>
                </div>
                
                {/* Stop Loss */}
                <div className="rounded-lg border border-bearish/30 bg-bearish/5 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-bearish">
                    <Shield className="h-3 w-3" />
                    Stop Loss
                  </div>
                  <div className="mt-1 font-mono text-lg font-bold text-bearish">{formatPriceWithSymbol(signal.stopLoss, signal.category)}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {((Math.abs(signal.entry - signal.stopLoss) / signal.entry) * 100).toFixed(2)}% risk
                  </div>
                </div>
                
                {/* Target 1 */}
                <div className="rounded-lg border border-bullish/30 bg-bullish/5 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-bullish">
                    <Target className="h-3 w-3" />
                    Target 1
                  </div>
                  <div className="mt-1 font-mono text-lg font-bold text-bullish">{formatPriceWithSymbol(signal.target1, signal.category)}</div>
                  <div className="text-[10px] text-muted-foreground">
                    +{((Math.abs(signal.target1 - signal.entry) / signal.entry) * 100).toFixed(2)}%
                  </div>
                </div>
                
                {/* Target 2 */}
                <div className="rounded-lg border border-bullish/30 bg-bullish/5 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-bullish">
                    <Target className="h-3 w-3" />
                    Target 2
                  </div>
                  <div className="mt-1 font-mono text-lg font-bold text-bullish">{formatPriceWithSymbol(signal.target2, signal.category)}</div>
                  <div className="text-[10px] text-muted-foreground">
                    +{((Math.abs(signal.target2 - signal.entry) / signal.entry) * 100).toFixed(2)}%
                  </div>
                </div>
              </div>
              
              {/* Target 3 & Risk Reward */}
              <div className="mb-4 flex gap-2">
                <div className="flex-1 rounded-lg border border-bullish/30 bg-bullish/5 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-bullish">
                    <Target className="h-3 w-3" />
                    Target 3 (Extended)
                  </div>
                  <div className="mt-1 font-mono text-lg font-bold text-bullish">{formatPriceWithSymbol(signal.target3, signal.category)}</div>
                </div>
                <div className="flex-1 rounded-lg border border-border bg-muted/30 p-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Percent className="h-3 w-3" />
                    Risk : Reward
                  </div>
                  <div className={cn(
                    'mt-1 text-lg font-bold',
                    signal.riskReward >= 2 ? 'text-bullish' :
                    signal.riskReward >= 1.5 ? 'text-amber-500' : 'text-bearish'
                  )}>
                    1 : {signal.riskReward}
                  </div>
                </div>
              </div>
              
              {/* Technical Notes */}
              <div className="mb-4 rounded-lg border border-border bg-muted/30 p-3">
                <div className="mb-2 flex items-center gap-1.5 text-xs font-medium">
                  <Info className="h-3 w-3" />
                  Technical Analysis
                </div>
                <div className="space-y-1">
                  {signal.technicalNotes.map((note, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="h-1 w-1 rounded-full bg-muted-foreground" />
                      {note}
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Timeframe & Holding Period */}
              <div className="mb-4 flex items-center justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3" />
                  Timeframe: {signal.timeframe}
                </span>
                <span className="flex items-center gap-1.5">
                  <Timer className="h-3 w-3" />
                  Hold: {signal.holdingPeriod}
                </span>
              </div>
            </>
          )}
          
          {/* View Full Analysis Link */}
          <Link
            href={`/asset/${selectedAsset.tradingSymbol}`}
            className="flex items-center justify-center gap-2 rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            View Full Analysis
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      )}
      
      {/* Disclaimer */}
      <div className="border-t border-amber-500/20 bg-amber-500/5 p-3 text-[10px] text-amber-600 dark:text-amber-400">
        <AlertTriangle className="mr-1 inline h-3 w-3" />
        <strong>Disclaimer:</strong> AI-generated signals for educational purposes only. Always do your own research and risk management before trading.
      </div>
    </div>
  );
}
