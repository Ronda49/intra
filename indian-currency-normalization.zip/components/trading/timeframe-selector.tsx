'use client';

import { cn } from '@/lib/utils';

interface TimeframeSelectorProps {
  selected: string;
  onChange: (timeframe: string) => void;
}

const timeframes = [
  { id: '1m', label: '1m' },
  { id: '5m', label: '5m' },
  { id: '15m', label: '15m' },
  { id: '1h', label: '1H' },
  { id: '4h', label: '4H' },
  { id: '1d', label: '1D' },
  { id: '1w', label: '1W' },
];

export function TimeframeSelector({ selected, onChange }: TimeframeSelectorProps) {
  return (
    <div className="flex items-center gap-1">
      {timeframes.map((tf) => (
        <button
          key={tf.id}
          onClick={() => onChange(tf.id)}
          className={cn(
            'rounded px-2 py-1 text-[10px] font-medium transition-colors',
            selected === tf.id
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:bg-muted hover:text-foreground'
          )}
        >
          {tf.label}
        </button>
      ))}
    </div>
  );
}
