'use client';

import { IndianRupee } from 'lucide-react';

export function CurrencyBanner() {
  return (
    <div className="border-b border-border/50 bg-gradient-to-r from-emerald-500/5 via-emerald-500/10 to-emerald-500/5 px-4 py-2">
      <div className="mx-auto flex max-w-7xl items-center justify-center gap-2 text-xs">
        <IndianRupee className="h-3.5 w-3.5 text-emerald-500" />
        <span className="font-medium text-emerald-600 dark:text-emerald-400">
          All prices displayed in Indian Rupees (₹)
        </span>
        <span className="text-muted-foreground">•</span>
        <span className="text-muted-foreground">
          Real-time conversion from USD at ₹83.25
        </span>
      </div>
    </div>
  );
}
