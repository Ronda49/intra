'use client';

import { ArrowDown, ArrowUp, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Asset, AssetCategory } from '@/lib/trading-types';
import { getCategoryColor, getCategoryBgColor } from '@/lib/api-client';
import { formatPrice, formatChange, formatVolumeINR, convertUSDToINR, convertToINR } from '@/lib/currency';

interface PriceDisplayProps {
  asset: Asset;
}

function getCategoryLabel(category: AssetCategory): string {
  const labels = {
    stocks: 'Stock',
    forex: 'Forex',
    crypto: 'Crypto',
    commodities: 'Commodity',
  };
  return labels[category];
}

export function PriceDisplay({ asset }: PriceDisplayProps) {
  const isPositive = asset.changePercent >= 0;
  const isNeutral = asset.changePercent === 0;

  // Prices are already converted to INR at the data source level
  // No need for double conversion
  const displayPrice = asset.price;
  const displayHigh = asset.high24h;
  const displayLow = asset.low24h;
  const displayChange = asset.change;
  const displayVolume = asset.volume;

  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">{asset.symbol}</h1>
            <span className={cn(
              'rounded px-1.5 py-0.5 text-[10px] font-medium',
              getCategoryBgColor(asset.category),
              getCategoryColor(asset.category)
            )}>
              {getCategoryLabel(asset.category)}
            </span>
          </div>
          <p className="mt-0.5 text-sm text-muted-foreground">{asset.name}</p>
        </div>
        
        <div className="text-right">
          <div className="text-3xl font-bold tabular-nums">
            {formatPrice(displayPrice, asset.category)}
          </div>
          <div className={cn(
            'mt-1 flex items-center justify-end gap-1 text-sm font-medium',
            isNeutral ? 'text-muted-foreground' : isPositive ? 'text-bullish' : 'text-bearish'
          )}>
            {isNeutral ? (
              <Minus className="h-4 w-4" />
            ) : isPositive ? (
              <ArrowUp className="h-4 w-4" />
            ) : (
              <ArrowDown className="h-4 w-4" />
            )}
            <span className="tabular-nums">
              {isPositive ? '+' : ''}₹{displayChange.toFixed(2)} ({isPositive ? '+' : ''}{asset.changePercent.toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>

      {/* 24h Stats */}
      <div className="mt-4 grid grid-cols-4 gap-4 border-t border-border pt-4">
        <div>
          <p className="text-[10px] text-muted-foreground">24h High</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums text-bullish">
            {formatPrice(displayHigh, asset.category)}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-muted-foreground">24h Low</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums text-bearish">
            {formatPrice(displayLow, asset.category)}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-muted-foreground">24h Volume</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">
            {displayVolume > 0 ? formatVolumeINR(displayVolume) : 'N/A'}
          </p>
        </div>
        <div>
          <p className="text-[10px] text-muted-foreground">Updated</p>
          <p className="mt-0.5 text-sm font-medium tabular-nums">
            {asset.lastUpdated.toLocaleTimeString()}
          </p>
        </div>
      </div>
    </div>
  );
}
