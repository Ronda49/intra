"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Globe,
  BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";
import Link from "next/link";

interface IndexData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  region: "india" | "us" | "europe" | "asia";
}

// Mock real-time data
const generateIndicesData = (): IndexData[] => {
  const baseIndices: IndexData[] = [
    // India
    {
      symbol: "NIFTY50",
      name: "Nifty 50",
      price: 24890.45,
      change: 0,
      changePercent: 0,
      region: "india",
    },
    {
      symbol: "SENSEX",
      name: "BSE Sensex",
      price: 81567.89,
      change: 0,
      changePercent: 0,
      region: "india",
    },
    {
      symbol: "NIFTYBANK",
      name: "Bank Nifty",
      price: 52340.25,
      change: 0,
      changePercent: 0,
      region: "india",
    },
    {
      symbol: "NIFTYIT",
      name: "Nifty IT",
      price: 38945.6,
      change: 0,
      changePercent: 0,
      region: "india",
    },
    // US
    {
      symbol: "SPX",
      name: "S&P 500",
      price: 5890.32,
      change: 0,
      changePercent: 0,
      region: "us",
    },
    {
      symbol: "NDX",
      name: "Nasdaq 100",
      price: 20456.78,
      change: 0,
      changePercent: 0,
      region: "us",
    },
    {
      symbol: "DJI",
      name: "Dow Jones",
      price: 43567.89,
      change: 0,
      changePercent: 0,
      region: "us",
    },
    {
      symbol: "RUT",
      name: "Russell 2000",
      price: 2234.56,
      change: 0,
      changePercent: 0,
      region: "us",
    },
    // Europe
    {
      symbol: "FTSE",
      name: "FTSE 100",
      price: 8234.56,
      change: 0,
      changePercent: 0,
      region: "europe",
    },
    {
      symbol: "DAX",
      name: "DAX 40",
      price: 19876.54,
      change: 0,
      changePercent: 0,
      region: "europe",
    },
    {
      symbol: "CAC",
      name: "CAC 40",
      price: 7654.32,
      change: 0,
      changePercent: 0,
      region: "europe",
    },
    {
      symbol: "STOXX",
      name: "Euro Stoxx 50",
      price: 5123.45,
      change: 0,
      changePercent: 0,
      region: "europe",
    },
    // Asia
    {
      symbol: "N225",
      name: "Nikkei 225",
      price: 42345.67,
      change: 0,
      changePercent: 0,
      region: "asia",
    },
    {
      symbol: "HSI",
      name: "Hang Seng",
      price: 21234.56,
      change: 0,
      changePercent: 0,
      region: "asia",
    },
    {
      symbol: "SSEC",
      name: "Shanghai Comp",
      price: 3456.78,
      change: 0,
      changePercent: 0,
      region: "asia",
    },
    {
      symbol: "KOSPI",
      name: "KOSPI",
      price: 2678.9,
      change: 0,
      changePercent: 0,
      region: "asia",
    },
  ];

  // Add random changes
  return baseIndices.map((index) => {
    const changePercent = (Math.random() - 0.48) * 3; // Slight bullish bias
    const change = index.price * (changePercent / 100);
    return {
      ...index,
      price: index.price + change,
      change,
      changePercent,
    };
  });
};

interface IndicesWidgetProps {
  compact?: boolean;
}

export function IndicesWidget({ compact = false }: IndicesWidgetProps) {
  const [indices, setIndices] = useState<IndexData[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>("india");

  useEffect(() => {
    setIndices(generateIndicesData());

    // Update every 5 seconds
    const interval = setInterval(() => {
      setIndices((prev) =>
        prev.map((index) => {
          const microChange = (Math.random() - 0.5) * 0.1;
          const newPrice = index.price * (1 + microChange / 100);
          const totalChangePercent = index.changePercent + microChange * 0.1;
          return {
            ...index,
            price: newPrice,
            change: index.price * (totalChangePercent / 100),
            changePercent: totalChangePercent,
          };
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const filteredIndices = indices.filter(
    (i) => i.region === selectedRegion || selectedRegion === "all"
  );

  if (compact) {
    return (
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Activity className="h-4 w-4 text-emerald-400" />
            Global Indices
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 gap-2">
            {indices.slice(0, 8).map((index) => (
              <div
                key={index.symbol}
                className="bg-zinc-800/50 rounded-lg p-2 hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-zinc-400 truncate">
                    {index.symbol}
                  </span>
                  {index.changePercent >= 0 ? (
                    <TrendingUp className="h-3 w-3 text-emerald-400" />
                  ) : (
                    <TrendingDown className="h-3 w-3 text-red-400" />
                  )}
                </div>
                <div className="text-xs font-medium text-white">
                  ₹{index.price.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </div>
                <div
                  className={cn(
                    "text-[10px]",
                    index.changePercent >= 0 ? "text-emerald-400" : "text-red-400"
                  )}
                >
                  {index.changePercent >= 0 ? "+" : ""}
                  {index.changePercent.toFixed(2)}%
                </div>
              </div>
            ))}
          </div>
          <Link
            href="/indices"
            className="text-xs text-blue-400 hover:text-blue-300 mt-2 block text-center"
          >
            View all indices
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-zinc-900/50 border-zinc-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Globe className="h-5 w-5 text-emerald-400" />
            Global Market Indices
          </CardTitle>
          <Link href="/indices">
            <Badge
              variant="outline"
              className="text-xs cursor-pointer hover:bg-zinc-800"
            >
              View All
            </Badge>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedRegion} onValueChange={setSelectedRegion}>
          <TabsList className="bg-zinc-800/50 mb-4">
            <TabsTrigger value="india">India</TabsTrigger>
            <TabsTrigger value="us">US</TabsTrigger>
            <TabsTrigger value="europe">Europe</TabsTrigger>
            <TabsTrigger value="asia">Asia</TabsTrigger>
          </TabsList>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {filteredIndices.map((index) => (
              <Link
                key={index.symbol}
                href={`/asset/${index.symbol}`}
                className="bg-zinc-800/50 hover:bg-zinc-800 rounded-xl p-4 transition-all border border-zinc-800 hover:border-zinc-700"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-zinc-400">
                    {index.symbol}
                  </span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[10px] px-1.5",
                      index.changePercent >= 0
                        ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                        : "bg-red-500/20 text-red-400 border-red-500/30"
                    )}
                  >
                    {index.changePercent >= 0 ? (
                      <TrendingUp className="h-3 w-3 mr-0.5" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-0.5" />
                    )}
                    {Math.abs(index.changePercent).toFixed(2)}%
                  </Badge>
                </div>
                <div className="text-lg font-bold text-white mb-1">
                  ₹{index.price.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </div>
                <div className="text-xs text-zinc-500 truncate">{index.name}</div>
                <div
                  className={cn(
                    "text-xs mt-1",
                    index.change >= 0 ? "text-emerald-400" : "text-red-400"
                  )}
                >
                  {index.change >= 0 ? "+" : ""}
                  ₹{Math.abs(index.change).toFixed(2)}
                </div>
              </Link>
            ))}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}
