'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import type { MarketTicker } from '@/lib/trading-types';

interface UseBinanceWebSocketOptions {
  symbols: string[];
  onTicker?: (ticker: MarketTicker) => void;
}

export function useBinanceWebSocket({ symbols, onTicker }: UseBinanceWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<MarketTicker | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (symbols.length === 0) return;

    const streams = symbols.map(s => `${s.toLowerCase()}@ticker`).join('/');
    const ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
    };

    ws.onmessage = (event) => {
      try {
        const { data } = JSON.parse(event.data);
        if (data) {
          const ticker: MarketTicker = {
            symbol: data.s,
            price: parseFloat(data.c).toFixed(2),
            change: parseFloat(data.p).toFixed(2),
            changePercent: parseFloat(data.P).toFixed(2),
            volume: parseFloat(data.v).toFixed(0),
          };
          setLastMessage(ticker);
          onTicker?.(ticker);
        }
      } catch (error) {
        console.error('WebSocket message parse error:', error);
      }
    };

    ws.onerror = () => {
      setIsConnected(false);
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Attempt to reconnect after 5 seconds
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000);
    };
  }, [symbols, onTicker]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return {
    isConnected,
    lastMessage,
    disconnect,
    reconnect: connect,
  };
}

interface UseFinnhubWebSocketOptions {
  apiKey: string;
  symbols: string[];
  onTrade?: (data: { symbol: string; price: number; volume: number }) => void;
}

export function useFinnhubWebSocket({ apiKey, symbols, onTrade }: UseFinnhubWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (!apiKey || symbols.length === 0) return;

    const ws = new WebSocket(`wss://ws.finnhub.io?token=${apiKey}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      // Subscribe to symbols
      symbols.forEach(symbol => {
        ws.send(JSON.stringify({ type: 'subscribe', symbol }));
      });
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'trade' && data.data?.[0]) {
          const trade = data.data[0];
          onTrade?.({
            symbol: trade.s,
            price: trade.p,
            volume: trade.v,
          });
        }
      } catch (error) {
        console.error('Finnhub WebSocket message parse error:', error);
      }
    };

    ws.onerror = () => {
      setIsConnected(false);
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Attempt to reconnect after 5 seconds
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000);
    };
  }, [apiKey, symbols, onTrade]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      // Unsubscribe from symbols before closing
      symbols.forEach(symbol => {
        wsRef.current?.send(JSON.stringify({ type: 'unsubscribe', symbol }));
      });
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
  }, [symbols]);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return {
    isConnected,
    disconnect,
    reconnect: connect,
  };
}
