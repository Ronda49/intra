import { NextRequest, NextResponse } from 'next/server';

const FINNHUB_API_KEY = process.env.FINNHUB_API_KEY || '';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get('symbol');
  const type = searchParams.get('type') || 'quote';

  if (!FINNHUB_API_KEY) {
    return NextResponse.json({ error: 'API key not configured', data: null }, { status: 200 });
  }

  try {
    if (type === 'quote' && symbol) {
      const response = await fetch(
        `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${FINNHUB_API_KEY}`
      );
      const data = await response.json();
      return NextResponse.json({ data, error: null });
    }

    if (type === 'stocks') {
      const symbols = ['AAPL', 'GOOGL', 'TSLA', 'MSFT', 'NVDA', 'META', 'AMZN', 'JPM'];
      const results = [];

      for (const sym of symbols) {
        try {
          const response = await fetch(
            `https://finnhub.io/api/v1/quote?symbol=${sym}&token=${FINNHUB_API_KEY}`
          );
          const data = await response.json();
          
          if (data.c > 0) {
            results.push({
              symbol: sym,
              name: sym,
              category: 'stocks',
              volatility: Math.abs(data.dp || 0),
              change: data.dp || 0,
              price: data.c,
              volume: 0,
            });
          }
        } catch (e) {
          console.error(`Error fetching ${sym}:`, e);
        }
      }

      return NextResponse.json({ data: results, error: null });
    }

    if (type === 'candles' && symbol) {
      const to = Math.floor(Date.now() / 1000);
      const from = to - 7 * 24 * 60 * 60; // 7 days ago
      
      const response = await fetch(
        `https://finnhub.io/api/v1/stock/candle?symbol=${symbol}&resolution=60&from=${from}&to=${to}&token=${FINNHUB_API_KEY}`
      );
      const data = await response.json();
      return NextResponse.json({ data, error: null });
    }

    return NextResponse.json({ error: 'Invalid request type', data: null }, { status: 400 });
  } catch (error) {
    console.error('Finnhub API error:', error);
    return NextResponse.json({ error: 'Failed to fetch data', data: null }, { status: 500 });
  }
}
