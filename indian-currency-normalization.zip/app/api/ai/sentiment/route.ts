import { generateText, Output } from 'ai';
import { z } from 'zod';

const sentimentSchema = z.object({
  overallSentiment: z.enum(['very_bullish', 'bullish', 'neutral', 'bearish', 'very_bearish']),
  sentimentScore: z.number().min(-100).max(100),
  confidence: z.number().min(0).max(100),
  keyFactors: z.array(z.object({
    factor: z.string(),
    impact: z.enum(['positive', 'negative', 'neutral']),
    importance: z.enum(['high', 'medium', 'low']),
  })),
  newsImpact: z.object({
    shortTerm: z.enum(['bullish', 'bearish', 'neutral']),
    mediumTerm: z.enum(['bullish', 'bearish', 'neutral']),
    longTerm: z.enum(['bullish', 'bearish', 'neutral']),
  }),
  priceImpactPrediction: z.object({
    direction: z.enum(['up', 'down', 'sideways']),
    magnitude: z.enum(['significant', 'moderate', 'minimal']),
    timeframe: z.string(),
  }),
  tradingRecommendation: z.object({
    action: z.enum(['strong_buy', 'buy', 'hold', 'sell', 'strong_sell']),
    reasoning: z.string(),
    riskLevel: z.enum(['low', 'medium', 'high', 'very_high']),
  }),
  summary: z.string(),
});

export async function POST(req: Request) {
  try {
    const { symbol, assetName, category, newsHeadlines, technicalData, currentPrice } = await req.json();

    if (!symbol) {
      return Response.json({ error: 'Symbol is required' }, { status: 400 });
    }

    const newsContext = newsHeadlines?.length > 0
      ? `Recent news headlines:\n${newsHeadlines.map((h: string, i: number) => `${i + 1}. ${h}`).join('\n')}`
      : 'No recent news available.';

    const technicalContext = technicalData
      ? `Technical indicators:
- RSI: ${technicalData.rsi?.value || 'N/A'} (${technicalData.rsi?.signal || 'N/A'})
- MACD: ${technicalData.macd?.trend || 'N/A'} (${technicalData.macd?.crossover || 'none'})
- Moving Averages: ${technicalData.movingAverages?.trend || 'N/A'}
- Bollinger Bands: ${technicalData.bollingerBands?.signal || 'N/A'}
- Overall Technical Sentiment: ${technicalData.overallSentiment || 'N/A'}`
      : 'No technical data available.';

    const prompt = `You are an expert financial analyst specializing in ${category} markets. Analyze the following asset and provide a comprehensive sentiment analysis.

Asset: ${assetName} (${symbol})
Category: ${category}
Current Price: ${currentPrice || 'Unknown'}

${newsContext}

${technicalContext}

Based on the available information, provide a detailed sentiment analysis including:
1. Overall market sentiment towards this asset
2. Key factors driving the sentiment
3. Short-term, medium-term, and long-term outlook
4. Price impact prediction
5. Trading recommendation with risk assessment

Consider market conditions, sector trends, and any relevant macroeconomic factors.`;

    const result = await generateText({
      model: 'openai/gpt-4o-mini',
      prompt,
      output: Output.object({ schema: sentimentSchema }),
    });

    return Response.json({
      success: true,
      analysis: result.output,
      analyzedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Sentiment analysis error:', error);
    return Response.json({ 
      error: 'Failed to analyze sentiment',
      fallback: generateFallbackSentiment()
    }, { status: 500 });
  }
}

function generateFallbackSentiment() {
  return {
    overallSentiment: 'neutral',
    sentimentScore: 0,
    confidence: 50,
    keyFactors: [
      { factor: 'Market conditions uncertain', impact: 'neutral', importance: 'medium' },
    ],
    newsImpact: {
      shortTerm: 'neutral',
      mediumTerm: 'neutral',
      longTerm: 'neutral',
    },
    priceImpactPrediction: {
      direction: 'sideways',
      magnitude: 'minimal',
      timeframe: '1-7 days',
    },
    tradingRecommendation: {
      action: 'hold',
      reasoning: 'Insufficient data for definitive recommendation. Consider waiting for more clarity.',
      riskLevel: 'medium',
    },
    summary: 'Unable to perform full analysis. Please check back later for updated sentiment.',
  };
}
