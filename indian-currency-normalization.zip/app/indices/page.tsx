'use client';

import { useState, useMemo, useEffect } from 'react';
import Link from 'next/link';
import { Header } from '@/components/trading/header';
import { ALL_GLOBAL_INDICES, INDIAN_INDICES, US_INDICES, EUROPEAN_INDICES, ASIAN_INDICES, type IndexInfo } from '@/lib/data/global-indices';
import { cn } from '@/lib/utils';
import { ArrowLeft, Globe, TrendingUp, TrendingDown, Clock, Search, RefreshCw } from 'lucide-react';

type Region = 'all' | 'india' | 'usa' | 'europe' | 'asia' | 'other';

interface IndexWithPrice extends IndexInfo {
  price?: number;
  change?: number;
  changePercent?: number;
}

// Simulated real-time prices (in production, fetch from APIs)
function generateMockPrice(symbol: string): { price: number; change: number; changePercent: number } {
  const baseValues: Record<string, number> = {
    '^NSEI': 24850,
    '^BSESN': 81500,
    '^NSEBANK': 52300,
    '^DJI': 43500,
    '^GSPC': 6050,
    '^IXIC': 19800,
    '^N225': 39500,
    '^HSI': 20100,
    '^FTSE': 8450,
    '^GDAXI': 20500,
  };
  
  const base = baseValues[symbol] || 10000 + Math.random() * 5000;
  const changePercent = (Math.random() - 0.5) * 3;
  const change = (base * changePercent) / 100;
  
  return {
    price: base + change,
    change,
    changePercent,
  };
}

export default function IndicesPage() {
  const [region, setRegion] = useState<Region>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [indicesWithPrices, setIndicesWithPrices] = useState<IndexWithPrice[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(false);

  // Initialize prices
  useEffect(() => {
    updatePrices();
    const interval = setInterval(updatePrices, 30000);
    return () => clearInterval(interval);
  }, []);

  function updatePrices() {
    setIsLoading(true);
    const updated = ALL_GLOBAL_INDICES.map(index => ({
      ...index,
      ...generateMockPrice(index.symbol),
    }));
    setIndicesWithPrices(updated);
    setLastUpdate(new Date());
    setIsLoading(false);
  }

  // Filter indices
  const filteredIndices = useMemo(() => {
    let indices = indicesWithPrices;
    
    // Region filter
    switch (region) {
      case 'india':
        indices = indices.filter(i => i.country === 'India');
        break;
      case 'usa':
        indices = indices.filter(i => i.country === 'USA');
        break;
      case 'europe':
        indices = indices.filter(i => i.region === 'europe');
        break;
      case 'asia':
        indices = indices.filter(i => i.region === 'asia' && i.country !== 'India');
        break;
      case 'other':
        indices = indices.filter(i => !['asia', 'europe', 'americas'].includes(i.region) || (i.region === 'americas' && i.country !== 'USA'));
        break;
    }
    
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      indices = indices.filter(i => 
        i.name.toLowerCase().includes(query) ||
        i.symbol.toLowerCase().includes(query) ||
        i.country.toLowerCase().includes(query)
      );
    }
    
    return indices;
  }, [indicesWithPrices, region, searchQuery]);

  // Group by region for display
  const groupedIndices = useMemo(() => {
    const groups: Record<string, IndexWithPrice[]> = {};
    
    for (const index of filteredIndices) {
      const key = index.region;
      if (!groups[key]) groups[key] = [];
      groups[key].push(index);
    }
    
    return groups;
  }, [filteredIndices]);

  const regionLabels: Record<string, string> = {
    asia: 'Asia Pacific',
    europe: 'Europe',
    americas: 'Americas',
    middle_east: 'Middle East',
    africa: 'Africa',
    oceania: 'Oceania',
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="mx-auto max-w-7xl px-4 py-6 lg:px-6">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link 
            href="/" 
            className="flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Heatmap
          </Link>
        </div>

        {/* Header */}
        <div className="mb-6 rounded-xl border border-border bg-card p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Globe className="h-7 w-7" />
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Global Indices</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                Real-time tracking of major stock market indices worldwide including NIFTY 50, SENSEX, BANK NIFTY, and global markets
              </p>
              <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                <span>{ALL_GLOBAL_INDICES.length} indices tracked</span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Updated: {lastUpdate.toLocaleTimeString()}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={updatePrices}
              disabled={isLoading}
              className="flex items-center gap-1.5 rounded border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:opacity-50"
            >
              <RefreshCw className={cn('h-3 w-3', isLoading && 'animate-spin')} />
              Refresh
            </button>
          </div>
        </div>

        {/* Featured Indian Indices */}
        <div className="mb-6">
          <h2 className="mb-3 text-sm font-semibold">Indian Markets</h2>
          <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4">
            {INDIAN_INDICES.slice(0, 4).map(index => {
              const data = indicesWithPrices.find(i => i.symbol === index.symbol);
              const isPositive = (data?.changePercent || 0) >= 0;
              return (
                <div
                  key={index.symbol}
                  className="rounded-lg border border-border bg-card p-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{index.name}</span>
                    {isPositive ? (
                      <TrendingUp className="h-4 w-4 text-bullish" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-bearish" />
                    )}
                  </div>
                  <div className="mt-2 text-xl font-bold">
                    {data?.price?.toLocaleString('en-IN', { maximumFractionDigits: 2 }) || '-'}
                  </div>
                  <div className={cn(
                    'mt-1 text-sm font-medium',
                    isPositive ? 'text-bullish' : 'text-bearish'
                  )}>
                    {isPositive ? '+' : ''}{data?.change?.toFixed(2)} ({isPositive ? '+' : ''}{data?.changePercent?.toFixed(2)}%)
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            {(['all', 'india', 'usa', 'europe', 'asia', 'other'] as Region[]).map(r => (
              <button
                key={r}
                type="button"
                onClick={() => setRegion(r)}
                className={cn(
                  'rounded-full px-3 py-1.5 text-xs font-medium transition-colors',
                  region === r 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground hover:bg-accent hover:text-foreground'
                )}
              >
                {r === 'all' ? 'All Regions' : r === 'usa' ? 'USA' : r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>
          
          <div className="relative md:w-64">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search indices..."
              className="h-9 w-full rounded border border-border bg-card pl-9 pr-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>

        {/* Indices by Region */}
        <div className="space-y-6">
          {Object.entries(groupedIndices).map(([regionKey, indices]) => (
            <div key={regionKey}>
              <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold">
                <Globe className="h-4 w-4 text-muted-foreground" />
                {regionLabels[regionKey] || regionKey}
                <span className="text-xs font-normal text-muted-foreground">({indices.length})</span>
              </h2>
              <div className="overflow-hidden rounded-lg border border-border">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr className="text-left text-xs text-muted-foreground">
                      <th className="px-4 py-2.5 font-medium">Index</th>
                      <th className="px-4 py-2.5 font-medium">Country</th>
                      <th className="hidden px-4 py-2.5 font-medium text-right md:table-cell">Last</th>
                      <th className="px-4 py-2.5 font-medium text-right">Change</th>
                      <th className="hidden px-4 py-2.5 font-medium lg:table-cell">Trading Hours</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {indices.map(index => {
                      const isPositive = (index.changePercent || 0) >= 0;
                      return (
                        <tr key={index.symbol} className="transition-colors hover:bg-accent">
                          <td className="px-4 py-2.5">
                            <div>
                              <span className="font-medium">{index.name}</span>
                              <span className="ml-2 text-xs text-muted-foreground">{index.symbol}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2.5 text-sm text-muted-foreground">{index.country}</td>
                          <td className="hidden px-4 py-2.5 text-right font-mono text-sm md:table-cell">
                            {index.price?.toLocaleString(undefined, { maximumFractionDigits: 2 }) || '-'}
                          </td>
                          <td className="px-4 py-2.5 text-right">
                            <span className={cn(
                              'font-medium',
                              isPositive ? 'text-bullish' : 'text-bearish'
                            )}>
                              {isPositive ? '+' : ''}{index.changePercent?.toFixed(2)}%
                            </span>
                          </td>
                          <td className="hidden px-4 py-2.5 text-xs text-muted-foreground lg:table-cell">
                            {index.tradingHours}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>

        {filteredIndices.length === 0 && (
          <div className="py-12 text-center">
            <p className="text-muted-foreground">No indices found</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setRegion('all');
              }}
              className="mt-2 text-sm text-primary hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
