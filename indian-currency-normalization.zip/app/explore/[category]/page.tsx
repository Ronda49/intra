'use client';

import { useState, useMemo } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Header } from '@/components/trading/header';
import { SearchBar } from '@/components/trading/search-bar';
import { getAssetsByCategory, searchAssets, CATEGORY_COUNTS, type UnifiedAsset } from '@/lib/data/asset-database';
import type { AssetCategory } from '@/lib/trading-types';
import { cn } from '@/lib/utils';
import { 
  TrendingUp, Coins, DollarSign, Gem, ArrowLeft, ChevronRight, 
  Filter, SortAsc, Grid3X3, List, Search 
} from 'lucide-react';

const categoryInfo: Record<AssetCategory, { name: string; description: string; icon: typeof TrendingUp; color: string }> = {
  stocks: {
    name: 'Indian Stocks',
    description: 'NIFTY 50, NIFTY 100, NIFTY 500, and all NSE/BSE listed stocks',
    icon: TrendingUp,
    color: 'text-blue-400 bg-blue-400/10 border-blue-400/20',
  },
  crypto: {
    name: 'Cryptocurrencies',
    description: 'Bitcoin, Ethereum, and top altcoins across Layer 1, DeFi, Gaming, and more',
    icon: Coins,
    color: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
  },
  forex: {
    name: 'Forex Currencies',
    description: 'Major, minor, exotic, and emerging market currency pairs',
    icon: DollarSign,
    color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
  },
  commodities: {
    name: 'Commodities',
    description: 'Precious metals, energy, agriculture, livestock, and industrial metals',
    icon: Gem,
    color: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
  },
};

type SortOption = 'name' | 'symbol' | 'sector';
type ViewMode = 'grid' | 'list';

export default function CategoryPage() {
  const params = useParams();
  const category = params.category as AssetCategory;
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('symbol');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [subcategoryFilter, setSubcategoryFilter] = useState<string>('all');

  const allAssets = getAssetsByCategory(category);

  const info = categoryInfo[category];
  
  const subcategories = useMemo(() => {
    const subs = new Set(allAssets.map(a => a.subcategory));
    return ['all', ...Array.from(subs).sort()];
  }, [allAssets]);

  const filteredAssets = useMemo(() => {
    let assets = searchQuery 
      ? searchAssets(searchQuery, category, 500) 
      : allAssets;
    
    // Filter by subcategory
    if (subcategoryFilter !== 'all') {
      assets = assets.filter(a => a.subcategory === subcategoryFilter);
    }
    
    // Sort
    return [...assets].sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'symbol':
          return a.symbol.localeCompare(b.symbol);
        case 'sector':
          return (a.sector || '').localeCompare(b.sector || '');
        default:
          return 0;
      }
    });
  }, [allAssets, searchQuery, category, subcategoryFilter, sortBy]);

  if (!info) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="mx-auto max-w-7xl px-4 py-8">
          <h1 className="text-2xl font-bold">Category not found</h1>
          <Link href="/" className="mt-4 text-primary hover:underline">Go back home</Link>
        </main>
      </div>
    );
  }

  const Icon = info.icon;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="mx-auto max-w-7xl px-4 py-6 lg:px-6">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link 
            href="/" 
            className="flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Heatmap
          </Link>
        </div>

        {/* Header */}
        <div className={cn('mb-6 rounded-xl border p-6', info.color)}>
          <div className="flex items-start gap-4">
            <div className={cn('flex h-14 w-14 items-center justify-center rounded-xl', info.color)}>
              <Icon className="h-7 w-7" />
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">{info.name}</h1>
              <p className="mt-1 text-sm text-muted-foreground">{info.description}</p>
              <p className="mt-2 text-xs text-muted-foreground">
                {CATEGORY_COUNTS[category]} assets available
              </p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1 md:max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search ${info.name.toLowerCase()}...`}
              className="h-10 w-full rounded-lg border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
          
          <div className="flex items-center gap-3">
            {/* Subcategory Filter */}
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <select
                value={subcategoryFilter}
                onChange={(e) => setSubcategoryFilter(e.target.value)}
                className="h-9 rounded border border-border bg-card px-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
              >
                {subcategories.map(sub => (
                  <option key={sub} value={sub}>
                    {sub === 'all' ? 'All Types' : sub.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <SortAsc className="h-4 w-4 text-muted-foreground" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="h-9 rounded border border-border bg-card px-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="symbol">Symbol</option>
                <option value="name">Name</option>
                <option value="sector">Sector</option>
              </select>
            </div>

            {/* View Mode */}
            <div className="flex items-center rounded border border-border">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={cn(
                  'flex h-9 w-9 items-center justify-center transition-colors',
                  viewMode === 'grid' ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Grid3X3 className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={cn(
                  'flex h-9 w-9 items-center justify-center transition-colors',
                  viewMode === 'list' ? 'bg-accent text-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4 text-sm text-muted-foreground">
          Showing {filteredAssets.length} {filteredAssets.length === 1 ? 'asset' : 'assets'}
          {subcategoryFilter !== 'all' && ` in ${subcategoryFilter.replace(/_/g, ' ')}`}
          {searchQuery && ` matching "${searchQuery}"`}
        </div>

        {/* Assets Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filteredAssets.map(asset => (
              <Link
                key={asset.id}
                href={`/asset/${asset.tradingSymbol}`}
                className="group rounded-lg border border-border bg-card p-4 transition-all hover:border-primary/50 hover:bg-accent"
              >
                <div className="flex items-start justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{asset.symbol}</span>
                    </div>
                    <p className="mt-1 truncate text-xs text-muted-foreground">{asset.name}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                </div>
                {asset.sector && (
                  <div className="mt-2">
                    <span className="inline-block rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
                      {asset.sector}
                    </span>
                  </div>
                )}
                {asset.description && (
                  <p className="mt-2 line-clamp-2 text-[11px] text-muted-foreground">
                    {asset.description}
                  </p>
                )}
              </Link>
            ))}
          </div>
        ) : (
          <div className="overflow-hidden rounded-lg border border-border">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr className="text-left text-xs text-muted-foreground">
                  <th className="px-4 py-3 font-medium">Symbol</th>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="hidden px-4 py-3 font-medium md:table-cell">Type</th>
                  <th className="hidden px-4 py-3 font-medium lg:table-cell">Sector</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredAssets.map(asset => (
                  <tr key={asset.id} className="transition-colors hover:bg-accent">
                    <td className="px-4 py-3">
                      <Link href={`/asset/${asset.tradingSymbol}`} className="font-medium hover:text-primary">
                        {asset.symbol}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{asset.name}</td>
                    <td className="hidden px-4 py-3 md:table-cell">
                      <span className="inline-block rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
                        {asset.subcategory.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="hidden px-4 py-3 text-sm text-muted-foreground lg:table-cell">
                      {asset.sector || '-'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link 
                        href={`/asset/${asset.tradingSymbol}`}
                        className="text-xs text-primary hover:underline"
                      >
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {filteredAssets.length === 0 && (
          <div className="py-12 text-center">
            <p className="text-muted-foreground">No assets found</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSubcategoryFilter('all');
              }}
              className="mt-2 text-sm text-primary hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
