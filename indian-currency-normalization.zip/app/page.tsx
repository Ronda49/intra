'use client';

import { useCallback, useEffect, useState } from 'react';
import { Header } from '@/components/trading/header';
import { CurrencyBanner } from '@/components/trading/currency-banner';
import { Heatmap } from '@/components/trading/heatmap';
import { MarketTicker } from '@/components/trading/market-ticker';
import { CategoryFilter } from '@/components/trading/category-filter';
import { StatsCards } from '@/components/trading/stats-cards';
import { SearchBar } from '@/components/trading/search-bar';
import { IndicesWidget } from '@/components/trading/indices-widget';
import { NewsFeed } from '@/components/trading/news-feed';
import { TradeSignalsPanel } from '@/components/trading/trade-signals-panel';
import type { AssetCategory, HeatmapItem, MarketTicker as MarketTickerType } from '@/lib/trading-types';
import { convertUSDToINR } from '@/lib/currency';
import { AlertCircle, RefreshCw, Settings, TrendingUp, BarChart3, Newspaper } from 'lucide-react';
import Link from 'next/link';

// Mock data for demonstration - ALL PRICES IN INR
const MOCK_HEATMAP_DATA: HeatmapItem[] = [
  { symbol: 'BTCUSDT', name: 'Bitcoin', category: 'crypto', volatility: 4.2, change: 3.45, price: convertUSDToINR(97845.23), volume: convertUSDToINR(28500000000) },
  { symbol: 'ETHUSDT', name: 'Ethereum', category: 'crypto', volatility: 5.1, change: -2.18, price: convertUSDToINR(3456.78), volume: convertUSDToINR(15200000000) },
  { symbol: 'AAPL', name: 'Apple Inc', category: 'stocks', volatility: 1.8, change: 1.24, price: 198.45, volume: 52000000 },
  { symbol: 'GOOGL', name: 'Alphabet Inc', category: 'stocks', volatility: 2.1, change: -0.87, price: 178.92, volume: 21000000 },
  { symbol: 'EURUSD', name: 'Euro/USD', category: 'forex', volatility: 0.5, change: 0.15, price: 1.0842, volume: 0 },
  { symbol: 'GBPUSD', name: 'GBP/USD', category: 'forex', volatility: 0.7, change: -0.32, price: 1.2654, volume: 0 },
  { symbol: 'XAUUSD', name: 'Gold', category: 'commodities', volatility: 1.2, change: 0.89, price: convertUSDToINR(2745.50), volume: 0 },
  { symbol: 'XAGUSD', name: 'Silver', category: 'commodities', volatility: 2.3, change: -1.45, price: convertUSDToINR(30.82), volume: 0 },
  { symbol: 'SOLUSDT', name: 'Solana', category: 'crypto', volatility: 7.8, change: 5.67, price: convertUSDToINR(245.89), volume: convertUSDToINR(8500000000) },
  { symbol: 'TSLA', name: 'Tesla Inc', category: 'stocks', volatility: 3.5, change: 2.34, price: 412.56, volume: 85000000 },
];

const MOCK_TICKERS: MarketTickerType[] = [
  { symbol: 'BTC', price: convertUSDToINR(97845.23).toFixed(2), change: convertUSDToINR(3250.45).toFixed(2), changePercent: '3.45', volume: convertUSDToINR(28500000000).toFixed(0) },
  { symbol: 'ETH', price: convertUSDToINR(3456.78).toFixed(2), change: convertUSDToINR(-76.54).toFixed(2), changePercent: '-2.18', volume: convertUSDToINR(15200000000).toFixed(0) },
  { symbol: 'SOL', price: convertUSDToINR(245.89).toFixed(2), change: convertUSDToINR(13.21).toFixed(2), changePercent: '5.67', volume: convertUSDToINR(8500000000).toFixed(0) },
  { symbol: 'AAPL', price: '198.45', change: '2.43', changePercent: '1.24', volume: '52000000' },
  { symbol: 'GOOGL', price: '178.92', change: '-1.57', changePercent: '-0.87', volume: '21000000' },
  { symbol: 'TSLA', price: '412.56', change: '9.43', changePercent: '2.34', volume: '85000000' },
  { symbol: 'EUR/USD', price: '1.0842', change: '0.0016', changePercent: '0.15', volume: '0' },
  { symbol: 'GOLD', price: convertUSDToINR(2745.50).toFixed(2), change: convertUSDToINR(24.21).toFixed(2), changePercent: '0.89', volume: '0' },
];

// Simulated crypto data with realistic values (fallback when API is geo-blocked)
function getSimulatedCryptoData(): HeatmapItem[] {
  const baseData = [
    { symbol: 'BTCUSDT', name: 'Bitcoin', basePrice: 97845, baseChange: 3.45 },
    { symbol: 'ETHUSDT', name: 'Ethereum', basePrice: 3456, baseChange: -2.18 },
    { symbol: 'SOLUSDT', name: 'Solana', basePrice: 245, baseChange: 5.67 },
    { symbol: 'BNBUSDT', name: 'BNB', basePrice: 712, baseChange: 1.23 },
    { symbol: 'XRPUSDT', name: 'XRP', basePrice: 2.45, baseChange: -0.87 },
    { symbol: 'ADAUSDT', name: 'Cardano', basePrice: 1.12, baseChange: 2.34 },
    { symbol: 'DOGEUSDT', name: 'Dogecoin', basePrice: 0.42, baseChange: 4.56 },
    { symbol: 'DOTUSDT', name: 'Polkadot', basePrice: 8.92, baseChange: -1.45 },
  ];

  return baseData.map(item => {
    // Add small random variation to simulate live data
    const priceVariation = (Math.random() - 0.5) * 0.02 * item.basePrice;
    const changeVariation = (Math.random() - 0.5) * 0.5;
    const priceUSD = item.basePrice + priceVariation;
    const change = item.baseChange + changeVariation;
    
    // Convert USD prices to INR
    const priceINR = convertUSDToINR(priceUSD);
    const volumeINR = convertUSDToINR(priceUSD * (Math.random() * 500000000 + 100000000));
    
    return {
      symbol: item.symbol,
      name: item.name,
      category: 'crypto' as const,
      volatility: Math.abs(change),
      change,
      price: priceINR,
      volume: volumeINR,
    };
  });
}

// Fetch crypto data - uses simulated data since Binance API is geo-restricted
async function fetchCryptoData(): Promise<HeatmapItem[]> {
  // Return simulated data (Binance API returns 451 from restricted locations)
  return getSimulatedCryptoData();
}

// Fetch stock data via server-side API route (keeps API key secure)
async function fetchStockData(): Promise<HeatmapItem[]> {
  try {
    const response = await fetch('/api/finnhub?type=stocks');
    const result = await response.json();
    
    if (result.error || !result.data) {
      return [];
    }
    
    return result.data as HeatmapItem[];
  } catch (error) {
    console.error('Error fetching stock data:', error);
    return [];
  }
}

// Fetch Binance data for crypto assets
async function fetchBinanceData(): Promise<HeatmapItem[]> {
  // Return simulated data (Binance API returns 451 from restricted locations)
  return getSimulatedCryptoData();
}

export default function HeatmapPage() {
  const [selectedCategory, setSelectedCategory] = useState<AssetCategory | 'all'>('all');
  const [heatmapData, setHeatmapData] = useState<HeatmapItem[]>(MOCK_HEATMAP_DATA);
  const [tickers, setTickers] = useState<MarketTickerType[]>(MOCK_TICKERS);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [apiConnected, setApiConnected] = useState(false);
  const [showApiNotice, setShowApiNotice] = useState(true);
  const [wsConnected, setWsConnected] = useState(false);
  const [hasStockData, setHasStockData] = useState(false);

  // WebSocket for real-time crypto updates (may be blocked in some regions)
  useEffect(() => {
    let ws: WebSocket | null = null;
    
    try {
      const cryptoSymbols = ['btcusdt', 'ethusdt', 'solusdt', 'bnbusdt', 'xrpusdt'];
      const streams = cryptoSymbols.map(s => `${s}@ticker`).join('/');
      ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);
      
      ws.onopen = () => {
        setWsConnected(true);
        setApiConnected(true);
      };
      
      ws.onmessage = (event) => {
        try {
          const { data } = JSON.parse(event.data);
          if (data && data.s) {
            // Convert USD prices to INR for crypto
            const priceUSD = parseFloat(data.c);
            const volumeUSD = parseFloat(data.v) * priceUSD;
            
            setHeatmapData(prev => prev.map(item => {
              if (item.symbol === data.s) {
                return {
                  ...item,
                  price: convertUSDToINR(priceUSD),
                  change: parseFloat(data.P),
                  volatility: Math.abs(parseFloat(data.P)),
                  volume: convertUSDToINR(volumeUSD),
                };
              }
              return item;
            }));
            
            setTickers(prev => prev.map(ticker => {
              if (ticker.symbol === data.s.replace('USDT', '')) {
                return {
                  ...ticker,
                  price: convertUSDToINR(priceUSD).toFixed(2),
                  change: parseFloat(data.p).toFixed(2),
                  changePercent: parseFloat(data.P).toFixed(2),
                  volume: (parseFloat(data.v) * parseFloat(data.c)).toString(),
                };
              }
              return ticker;
            }));
          }
        } catch {
          // Ignore parse errors
        }
      };
      
      ws.onclose = () => setWsConnected(false);
      ws.onerror = () => {
        setWsConnected(false);
        // WebSocket blocked - using simulated data instead
      };
    } catch {
      // WebSocket connection failed - using simulated data
      setWsConnected(false);
    }
    
    return () => {
      if (ws) ws.close();
    };
  }, []);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    
    try {
      // Always try to fetch Binance data (no API key required)
      const cryptoData = await fetchBinanceData();
      
      // Fetch stock data via secure server route
      const stockData = await fetchStockData();
      if (stockData.length > 0) {
        setHasStockData(true);
        setApiConnected(true);
      }

      // Add forex and commodities simulated data since real APIs require paid plans
      const forexData: HeatmapItem[] = [
        { symbol: 'EURUSD', name: 'Euro/USD', category: 'forex', volatility: 0.5 + Math.random() * 0.5, change: (Math.random() - 0.5) * 1, price: 1.0842 + (Math.random() - 0.5) * 0.01, volume: 0 },
        { symbol: 'GBPUSD', name: 'GBP/USD', category: 'forex', volatility: 0.6 + Math.random() * 0.5, change: (Math.random() - 0.5) * 1, price: 1.2654 + (Math.random() - 0.5) * 0.01, volume: 0 },
      ];

      const commoditiesData: HeatmapItem[] = [
        { symbol: 'XAUUSD', name: 'Gold', category: 'commodities', volatility: 1.0 + Math.random() * 0.5, change: (Math.random() - 0.5) * 2, price: 2745 + (Math.random() - 0.5) * 50, volume: 0 },
        { symbol: 'XAGUSD', name: 'Silver', category: 'commodities', volatility: 2.0 + Math.random() * 1, change: (Math.random() - 0.5) * 3, price: 30.82 + (Math.random() - 0.5) * 2, volume: 0 },
      ];

      const allData = [...cryptoData, ...stockData, ...forexData, ...commoditiesData];
      
      // Sort by volatility (most volatile first)
      allData.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
      
      if (allData.length > 0) {
        setHeatmapData(allData);
        
        // Update tickers
        const newTickers: MarketTickerType[] = allData.slice(0, 10).map(item => ({
          symbol: item.symbol.replace('USDT', ''),
          price: item.price.toFixed(2),
          change: (item.price * item.change / 100).toFixed(2),
          changePercent: item.change.toFixed(2),
          volume: item.volume.toString(),
        }));
        setTickers(newTickers);
      }
      
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Filter data by category
  const filteredData = selectedCategory === 'all' 
    ? heatmapData 
    : heatmapData.filter(item => item.category === selectedCategory);

  // Calculate stats
  const bullishCount = heatmapData.filter(item => item.change > 0).length;
  const bearishCount = heatmapData.filter(item => item.change < 0).length;
  const avgVolatility = heatmapData.reduce((sum, item) => sum + item.volatility, 0) / heatmapData.length;

  return (
    <div className="min-h-screen bg-background">
      <Header showApiStatus finnhubConnected={hasStockData} binanceConnected={apiConnected} />
      <CurrencyBanner />
      <MarketTicker tickers={tickers} />
      
      {showApiNotice && !hasStockData && (
        <div className="border-b border-warning/20 bg-warning/5 px-4 py-2">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-warning">
              <AlertCircle className="h-3.5 w-3.5" />
              <span>
                Using simulated market data. Add FINNHUB_API_KEY in Vars for live stock data.
              </span>
            </div>
            <button
              onClick={() => setShowApiNotice(false)}
              className="text-[10px] text-warning/70 hover:text-warning"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-7xl px-4 py-6 lg:px-6">
        {/* Search Bar */}
        <div className="mb-6">
          <SearchBar />
        </div>

        {/* Header Section */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Market Heatmap</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Top volatile assets across Stocks, Forex, Crypto & Commodities
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Link 
              href="/indices"
              className="flex items-center gap-1.5 rounded border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              <BarChart3 className="h-3 w-3" />
              Indices
            </Link>
            <button
              onClick={fetchData}
              disabled={isLoading}
              className="flex items-center gap-1.5 rounded border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:opacity-50"
            >
              <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              {isLoading ? 'Updating...' : 'Refresh'}
            </button>
            <span className="text-[10px] text-muted-foreground">
              Updated: {lastUpdate.toLocaleTimeString()}
            </span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="mb-6">
          <StatsCards
            totalAssets={heatmapData.length}
            bullishCount={bullishCount}
            bearishCount={bearishCount}
            avgVolatility={avgVolatility}
          />
        </div>

        {/* Category Filter */}
        <div className="mb-4">
          <CategoryFilter selected={selectedCategory} onChange={setSelectedCategory} />
        </div>

        {/* Heatmap Grid */}
        <Heatmap items={filteredData} />

        {/* Trade Signals Panel */}
        <div className="mt-8">
          <TradeSignalsPanel assets={heatmapData} />
        </div>

        {/* Indices and News Section */}
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <IndicesWidget compact />
          <NewsFeed compact />
        </div>

        {/* Quick Links */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link 
            href="/explore/stocks" 
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-emerald-500/30 hover:bg-emerald-500/5"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/20">
              <TrendingUp className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <div className="font-medium">Stocks</div>
              <div className="text-xs text-muted-foreground">Indian & US Markets</div>
            </div>
          </Link>
          <Link 
            href="/explore/crypto" 
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-orange-500/30 hover:bg-orange-500/5"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-500/20">
              <BarChart3 className="h-5 w-5 text-orange-400" />
            </div>
            <div>
              <div className="font-medium">Crypto</div>
              <div className="text-xs text-muted-foreground">Bitcoin, ETH & Altcoins</div>
            </div>
          </Link>
          <Link 
            href="/explore/forex" 
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-blue-500/30 hover:bg-blue-500/5"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/20">
              <TrendingUp className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <div className="font-medium">Forex</div>
              <div className="text-xs text-muted-foreground">Currency Pairs</div>
            </div>
          </Link>
          <Link 
            href="/explore/commodities" 
            className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-amber-500/30 hover:bg-amber-500/5"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/20">
              <Newspaper className="h-5 w-5 text-amber-400" />
            </div>
            <div>
              <div className="font-medium">Commodities</div>
              <div className="text-xs text-muted-foreground">Gold, Oil & More</div>
            </div>
          </Link>
        </div>

        {/* Footer Info */}
        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-border pt-6 text-[10px] text-muted-foreground md:flex-row">
          <div className="flex items-center gap-4">
            <span>Data Sources: Binance (Crypto) + Finnhub (Stocks)</span>
            <span>|</span>
            <span>AI: XGBoost + LSTM Hybrid Model</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="h-3 w-3" />
            <span>AlphaPredict 2026</span>
          </div>
        </div>
      </main>
    </div>
  );
}
