'use client';

import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { Header } from '@/components/trading/header';
import { TradingViewChart } from '@/components/trading/tradingview-chart';
import { PriceDisplay } from '@/components/trading/price-display';
import { AISignalCard } from '@/components/trading/ai-signal-card';
import { OrderBook } from '@/components/trading/order-book';
import { TradesFeed } from '@/components/trading/trades-feed';
import { TimeframeSelector } from '@/components/trading/timeframe-selector';
import { TradingStrategySelector } from '@/components/trading/trading-strategy-selector';
import { TechnicalAnalysisPanel } from '@/components/trading/technical-analysis-panel';
import { TradeRecommendation } from '@/components/trading/trade-recommendation';
import { NewsFeed } from '@/components/trading/news-feed';
import type { Asset, AssetCategory, CandleData, AISignal, TradingStyle } from '@/lib/trading-types';
import { BinanceClient, calculateATR, generateAISignal } from '@/lib/api-client';
import { convertUSDToINR } from '@/lib/currency';
import { ArrowLeft, Loader2, RefreshCw } from 'lucide-react';
import Link from 'next/link';

// Convert timeframe to Binance interval
function getInterval(timeframe: string): string {
  const intervals: Record<string, string> = {
    '1m': '1m',
    '5m': '5m',
    '15m': '15m',
    '1h': '1h',
    '4h': '4h',
    '1d': '1d',
    '1w': '1w',
  };
  return intervals[timeframe] || '1h';
}

// Determine asset category from symbol
function getCategory(symbol: string): AssetCategory {
  if (symbol.includes('USDT') || symbol.includes('BTC') || symbol.includes('ETH')) {
    return 'crypto';
  }
  if (symbol.includes('USD') && (symbol.includes('EUR') || symbol.includes('GBP') || symbol.includes('JPY'))) {
    return 'forex';
  }
  if (symbol.includes('XAU') || symbol.includes('XAG') || symbol.includes('OIL')) {
    return 'commodities';
  }
  return 'stocks';
}

// Get asset name from symbol
function getAssetName(symbol: string): string {
  const names: Record<string, string> = {
    BTCUSDT: 'Bitcoin',
    ETHUSDT: 'Ethereum',
    SOLUSDT: 'Solana',
    BNBUSDT: 'Binance Coin',
    XRPUSDT: 'XRP',
    AAPL: 'Apple Inc',
    GOOGL: 'Alphabet Inc',
    TSLA: 'Tesla Inc',
    MSFT: 'Microsoft Corp',
    NVDA: 'NVIDIA Corp',
    EURUSD: 'Euro / US Dollar',
    GBPUSD: 'British Pound / US Dollar',
    XAUUSD: 'Gold / US Dollar',
  };
  return names[symbol] || symbol;
}

// Fetch stock data via secure server route
async function fetchStockQuote(symbol: string): Promise<{ quote: Record<string, number> | null; candles: CandleData[] }> {
  try {
    const [quoteRes, candlesRes] = await Promise.all([
      fetch(`/api/finnhub?type=quote&symbol=${symbol}`),
      fetch(`/api/finnhub?type=candles&symbol=${symbol}`)
    ]);
    
    const quoteData = await quoteRes.json();
    const candlesData = await candlesRes.json();
    
    let candles: CandleData[] = [];
    if (candlesData.data && candlesData.data.s === 'ok') {
      candles = candlesData.data.t.map((time: number, i: number) => ({
        time,
        open: candlesData.data.o[i],
        high: candlesData.data.h[i],
        low: candlesData.data.l[i],
        close: candlesData.data.c[i],
        volume: candlesData.data.v[i],
      }));
    }
    
    return {
      quote: quoteData.data && quoteData.data.c > 0 ? quoteData.data : null,
      candles
    };
  } catch (error) {
    console.error('Error fetching stock data:', error);
    return { quote: null, candles: [] };
  }
}

export default function AssetDetailPage() {
  const params = useParams();
  const symbol = (params.symbol as string).toUpperCase();
  
  const [timeframe, setTimeframe] = useState('1h');
  const [asset, setAsset] = useState<Asset | null>(null);
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [signal, setSignal] = useState<AISignal | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [binanceConnected, setBinanceConnected] = useState(false);
  const [finnhubConnected, setFinnhubConnected] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState<TradingStyle>('intraday');

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    const category = getCategory(symbol);
    
    try {
      if (category === 'crypto') {
        const client = new BinanceClient();
        const assetData = await client.getPrice(symbol);
        const candleData = await client.getKlines(symbol, getInterval(timeframe), 100);
        
        if (assetData && candleData.length > 0) {
          setAsset(assetData);
          setCandles(candleData);
          setBinanceConnected(true);
          
          // Generate AI signal
          const aiSignal = generateAISignal(assetData, candleData);
          setSignal({
            ...aiSignal,
            atr: calculateATR(candleData),
            tradingStyle: timeframe === '1m' || timeframe === '5m' ? 'scalping' : 
                          timeframe === '15m' || timeframe === '1h' ? 'intraday' : 'swing',
          });
        }
      } else if (category === 'stocks') {
        // Fetch from secure server route
        const { quote, candles: stockCandles } = await fetchStockQuote(symbol);
        
        if (quote) {
          const assetData: Asset = {
            symbol,
            name: getAssetName(symbol),
            category: 'stocks',
            price: quote.c,
            change: quote.d,
            changePercent: quote.dp,
            volume: 0,
            high24h: quote.h,
            low24h: quote.l,
            lastUpdated: new Date(),
          };
          setAsset(assetData);
          setFinnhubConnected(true);
          
          if (stockCandles.length > 0) {
            setCandles(stockCandles);
            
            // Generate AI signal
            const aiSignal = generateAISignal(assetData, stockCandles);
            setSignal({
              ...aiSignal,
              atr: calculateATR(stockCandles),
              tradingStyle: timeframe === '1m' || timeframe === '5m' ? 'scalping' : 
                            timeframe === '15m' || timeframe === '1h' ? 'intraday' : 'swing',
            });
          }
        } else {
          // Fall back to mock data if API not configured
          generateMockData();
        }
      } else {
        // Generate mock data for forex/commodities
        generateMockData();
      }
      
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Error fetching asset data:', error);
      generateMockData();
    } finally {
      setIsLoading(false);
    }
    
    function generateMockData() {
      // Generate base price in USD first, then convert to INR
      const mockPriceUSD = category === 'forex' ? 1 + Math.random() * 0.5 : 
                           category === 'commodities' ? 1500 + Math.random() * 1500 :
                           100 + Math.random() * 200;
      const mockChangeUSD = (Math.random() - 0.5) * (category === 'forex' ? 0.5 : 10);
      
      // Convert to INR for commodities/forex (stocks are already in appropriate currency)
      const shouldConvert = category === 'commodities' || (category === 'forex' && symbol.includes('USD'));
      const mockPrice = shouldConvert ? convertUSDToINR(mockPriceUSD) : mockPriceUSD;
      const mockChange = shouldConvert ? convertUSDToINR(mockChangeUSD) : mockChangeUSD;
      const volumeUSD = Math.random() * 1000000;
      
      const mockAsset: Asset = {
        symbol,
        name: getAssetName(symbol),
        category,
        price: mockPrice,
        change: mockChange,
        changePercent: (mockChange / mockPrice) * 100,
        volume: shouldConvert ? convertUSDToINR(volumeUSD) : volumeUSD,
        high24h: mockPrice * 1.02,
        low24h: mockPrice * 0.98,
        lastUpdated: new Date(),
      };
      setAsset(mockAsset);
      
      // Generate mock candles (already in INR from mockPrice)
      const mockCandles: CandleData[] = [];
      let currentPrice = mockPrice;
      const now = Math.floor(Date.now() / 1000);
      
      for (let i = 99; i >= 0; i--) {
        const variation = (Math.random() - 0.5) * (mockPrice * 0.01);
        const open = currentPrice;
        const close = currentPrice + variation;
        const high = Math.max(open, close) * (1 + Math.random() * 0.005);
        const low = Math.min(open, close) * (1 - Math.random() * 0.005);
        
        mockCandles.push({
          time: now - i * 3600,
          open,
          high,
          low,
          close,
          volume: Math.random() * 10000,
        });
        
        currentPrice = close;
      }
      setCandles(mockCandles);
      
      // Generate AI signal
      const aiSignal = generateAISignal(mockAsset, mockCandles);
      setSignal({
        ...aiSignal,
        atr: calculateATR(mockCandles),
        tradingStyle: 'intraday' as TradingStyle,
      });
    }
  }, [symbol, timeframe]);

  useEffect(() => {
    fetchData();
    
    // Auto-refresh every 10 seconds for crypto, 30 seconds for others
    const category = getCategory(symbol);
    const interval = setInterval(fetchData, category === 'crypto' ? 10000 : 30000);
    return () => clearInterval(interval);
  }, [fetchData, symbol]);

  if (isLoading && !asset) {
    return (
      <div className="min-h-screen bg-background">
        <Header showApiStatus finnhubConnected={finnhubConnected} binanceConnected={binanceConnected} />
        <div className="flex h-[calc(100vh-56px)] items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Loading {symbol} data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header showApiStatus finnhubConnected={finnhubConnected} binanceConnected={binanceConnected} />
      
      <main className="mx-auto max-w-7xl px-4 py-4 lg:px-6">
        {/* Navigation */}
        <div className="mb-4 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Heatmap
          </Link>
          
          <div className="flex items-center gap-3">
            <button
              onClick={fetchData}
              disabled={isLoading}
              className="flex items-center gap-1.5 rounded border border-border bg-card px-2 py-1 text-[10px] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:opacity-50"
            >
              <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <span className="text-[10px] text-muted-foreground">
              {lastUpdate.toLocaleTimeString()}
            </span>
          </div>
        </div>

        {asset && (
          <div className="grid gap-4 lg:grid-cols-4">
            {/* Main Content */}
            <div className="space-y-4 lg:col-span-3">
              {/* Price Display */}
              <PriceDisplay asset={asset} />

              {/* Trading Strategy Selector */}
              <TradingStrategySelector
                selected={selectedStrategy}
                onChange={setSelectedStrategy}
                assetCategory={asset.category}
              />

              {/* Trade Recommendation - Main Action Card */}
              {candles.length > 0 && (
                <TradeRecommendation
                  candles={candles}
                  currentPrice={asset.price}
                  symbol={symbol}
                  tradingStyle={selectedStrategy}
                  assetCategory={asset.category}
                />
              )}

              {/* Chart Section */}
              <div className="rounded-lg border border-border bg-card p-4">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-sm font-semibold">Price Chart</h2>
                  <TimeframeSelector selected={timeframe} onChange={setTimeframe} />
                </div>
                
                {candles.length > 0 && (
                  <TradingViewChart
                    candles={candles}
                    entryPrice={signal?.entry}
                    targetPrice={signal?.target}
                    stopLossPrice={signal?.stopLoss}
                    height={400}
                  />
                )}
              </div>

              {/* Technical Analysis Panel */}
              {candles.length > 0 && (
                <TechnicalAnalysisPanel
                  candles={candles}
                  currentPrice={asset.price}
                  tradingStyle={selectedStrategy}
                />
              )}

              {/* News Feed */}
              <NewsFeed symbol={symbol} compact />

              {/* Order Book and Trades (Mobile) */}
              <div className="grid gap-4 md:grid-cols-2 lg:hidden">
                <OrderBook symbol={symbol} currentPrice={asset.price} />
                <TradesFeed symbol={symbol} />
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-4">
              {/* AI Signal */}
              {signal && (
                <AISignalCard signal={signal} currentPrice={asset.price} />
              )}

              {/* Order Book (Desktop) */}
              <div className="hidden lg:block">
                <OrderBook symbol={symbol} currentPrice={asset.price} />
              </div>

              {/* Trades Feed (Desktop) */}
              <div className="hidden lg:block">
                <TradesFeed symbol={symbol} />
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-8 border-t border-border pt-4 text-center text-[10px] text-muted-foreground">
          AlphaPredict 2026 • AI-Powered Trading Analysis • Not Financial Advice
        </div>
      </main>
    </div>
  );
}
